# SPDX-FileCopyrightText: PyPSA Contributors
#
# SPDX-License-Identifier: MIT

"""Piecewise-constraint helpers for PyPSA optimization models."""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

import pandas as pd
import xarray as xr
from linopy import Model, Slopes, Variable, breakpoints
from linopy.constants import BREAKPOINT_DIM, PWL_METHOD, EvolvingAPIWarning

from pypsa._linopy_compat import (
    SUPPORTS_BREAKPOINT_MASK,
    suppress_semantics_warnings,
)
from pypsa.descriptors import nominal_attrs

if TYPE_CHECKING:
    from collections.abc import Iterable
logger = logging.getLogger(__name__)
SIGNS_T = Literal["=", "<=", ">="]


# TODO: update to pydantic once pydantic is a pypsa dependency.
@dataclass(eq=True, frozen=True)
class PiecewiseOptions:
    """Options for piecewise constraint formulation."""

    component: str
    """PyPSA component name."""
    attribute: str
    """Component attribute for which piecewise data is defined."""
    sign: SIGNS_T
    """Sign for the piecewise constraint, interpreted as y <sign> f(x)."""
    name: tuple[str, ...] = field(default_factory=tuple)
    """Optional filter for a component name to apply the piecewise constraint to, e.g. a specific generator."""
    method: str = "auto"
    """The method to use for the piecewise constraint formulation, passed to linopy's add_piecewise_formulation method."""
    cumulative_attr: bool = False
    """Whether the y-axis breakpoints represent marginal values which should be integrated to define y breakpoints.

    If True, the integral of the piecewise curve will be used to define y breakpoints.
    If False, the nominal values at each x breakpoint will be used to define y breakpoints."""

    def __post_init__(self) -> None:
        """Ensure that name is stored as a tuple for consistent processing later."""
        list_names = (
            ()
            if self.name is None
            else (self.name,)
            if isinstance(self.name, str)
            else tuple(self.name)
        )
        object.__setattr__(self, "name", list_names)


def define_piecewise(
    m: Model,
    c: Any,
    x_var: Variable,
    pw_attr: str,
    aux_var_name: str,
    active_names: pd.Index,
    sign: SIGNS_T,
    cumulative_attr: bool,
    extra_options: Iterable[PiecewiseOptions],
    status: Variable | None = None,
    invert_attr: bool = False,
    y_var: Any | None = None,
    method: PWL_METHOD = "auto",
) -> Variable | None:
    """Add variable(s) and constraint(s) necessary to define a constraint along a piecewise linear curve.

    Derives the piecewise DataFrame, x-axis attribute, component names with piecewise
    data, and the optional p_nom scale factor from the component ``c`` directly.

    Check out the [`linopy` piecewise documentation](
    https://linopy.readthedocs.io/en/stable/piecewise-linear-constraints.html) for more information.

    Parameters
    ----------
    m : linopy.Model
        Model
    c : pypsa.Components
        Component instance with a ``piecewise`` attribute containing the piecewise data for the specified pw_attr.
    x_var : linopy.Variable
        The optimisation variable for the x-axis of the piecewise constraint.
    pw_attr : str
        The piecewise attribute name, e.g. ``"marginal_cost"`` or ``"capital_cost"``.
    aux_var_name : str
        Name for the auxiliary linopy variable (if created) and the prefix for the constraint(s) defining the piecewise cost.
    active_names : pd.Index
        Active component names to consider (e.g. ``c.active_assets`` or ``c.extendables``).
    sign : SIGNS_T
        The sign for the piecewise constraint, interpreted as ``y <sign> f(x)``.
    cumulative_attr : bool
        Whether the y-axis breakpoints represent marginal values.
        If True, the integral of the piecewise curve will be used to define y breakpoints.
        If False, the nominal values at each x breakpoint will be used to define y breakpoints.
    status : linopy.Variable or None, optional
        The optimisation variable for the binary status of the component (e.g. generator on/off).
    y_var : linopy.Variable or None, optional
        The optimisation variable for the y-axis of the piecewise constraint.
        If None, a new auxiliary variable will be created and used instead.
    extra_options : Iterable[PiecewiseOptions]
        Extra options to pass to the piecewise constraint formulation.
        If multiple instance of piecewise options are provided for the same component and attribute,
        then multiple piecewise constraints will be created with each of the specified options.
        If empty, default settings will be used.
    invert_attr : bool, optional
        Whether to invert the piecewise attribute values before multiplying by the x-axis variable.
        If True, y_attr -> 1 / y_attr.
        Default is False.
    method : str, optional
        The method to use for the piecewise constraint formulation, passed to the `linopy.add_piecewise_formulation` method.
        Default is "auto" (also the linopy default).

    Returns
    -------
    linopy.Variable or None
        The variable representing the piecewise constraint, or None if no piecewise breakpoints were defined.

    """
    pw_names = get_piecewise_names(c, pw_attr, active_names)
    if pw_names.empty:
        logger.debug(
            "No piecewise breakpoints defined for '%s' on component '%s'. Skipping piecewise constraint.",
            pw_attr,
            c.name,
        )
        return None
    x_breakpoints, y_breakpoints, valid = _get_breakpoints(
        c, pw_attr, pw_names, cumulative_attr, invert_attr
    )

    if y_var is None:
        y_var = _create_y_var(m, x_var, pw_names, aux_var_name)
    y_var_sel = y_var.sel(name=pw_names)
    sorted_options = sorted(extra_options, key=lambda x: x.name, reverse=True)
    for option in [*sorted_options, None]:
        if option is None:
            names, aux, opt_method, opt_sign = (
                pw_names,
                aux_var_name,
                method,
                sign,
            )
        elif option.name:
            names = pd.Index(option.name, name="name").intersection(pw_names)
            aux_suffix = (
                "_".join(names) if len(names) <= 3 else f"{names[0]}_..._{names[-1]}"
            )
            aux = f"{aux_var_name}_{aux_suffix}"
            opt_method, opt_sign = option.method, option.sign
        else:
            names, aux = pw_names, aux_var_name
            opt_method, opt_sign = option.method, option.sign
        if names.empty:
            continue

        if status is None:
            active = None
        else:
            masked = status.isnull().reindex(name=names, fill_value=True)
            if masked.all():
                active = None
            else:
                # `.where(..., 1)` resolves the absent slots to always-active, so
                # legacy and v1 agree; silence linopy's notice about them.
                with suppress_semantics_warnings():
                    active = status.to_linexpr().reindex(name=names).where(~masked, 1)

        mask_kwargs = (
            {"mask": valid.sel(name=names)} if SUPPORTS_BREAKPOINT_MASK else {}
        )
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=EvolvingAPIWarning)
            m.add_piecewise_formulation(
                (y_var.sel(name=names), y_breakpoints.sel(name=names), opt_sign),
                (x_var.sel(name=names), x_breakpoints.sel(name=names)),
                **mask_kwargs,
                method=opt_method,
                name=aux,
                active=active,
            )
        pw_names = pw_names.difference(names)
    return y_var_sel


def get_piecewise_names(c: Any, pw_attr: str, active_names: pd.Index) -> pd.Index:
    """Get component names with a given piecewise attribute.

    Parameters
    ----------
    c : Any
        PyPSA component instance with a ``piecewise`` attribute.
    pw_attr : str
        The piecewise attribute to look for, e.g. ``"marginal_cost"`` or ``"capital_cost"``.
    active_names : pd.Index
        The active component names to consider, e.g. ``c.active_assets`` or ``c.extendables``.

    Returns
    -------
    pd.Index:
        If there are piecewise curves defined for the given attribute, returns a pd.Index of component
        names that have piecewise curves and are in ``active_names``.

    """
    piecewise_df = c.piecewise.get(pw_attr)
    if piecewise_df is None or piecewise_df.empty:
        return pd.Index([], name="name")

    return (
        piecewise_df.dropna(how="all", axis=1)
        .columns.unique("name")
        .intersection(active_names)
    )


def _get_breakpoints(
    c: Any,
    pw_attr: str,
    pw_names: pd.Index,
    cumulative_attr: bool,
    invert_attr: bool,
) -> tuple[xr.DataArray, xr.DataArray, xr.DataArray]:
    """Convert piecewise data to linopy breakpoints and their validity mask.

    Ragged curves are stored densely; the mask declares which slots hold a real
    breakpoint, which linopy requires rather than inferring it from NaN padding.
    """
    piecewise_df = c.piecewise[pw_attr][pw_names]
    piecewise_attrs = c._piecewise_schema(pw_attr)

    x_da = _to_da(piecewise_df, piecewise_attrs.x)
    y_da = _to_da(piecewise_df, pw_attr)
    valid_breakpoints = x_da.notnull() & y_da.notnull()

    if invert_attr:
        y_da = 1 / y_da

    # For per-unit x-axes (p_pu, e_pu), scale to absolute values and reject extendables.
    nom_attr = nominal_attrs.get(c.name)
    if not piecewise_attrs.allow_extendable:
        if not (bad := pw_names.intersection(c.extendables)).empty:
            msg = (
                f"Piecewise '{pw_attr}' breakpoints on a per-unit x-axis are not supported "
                f"for extendable components (fixed {nom_attr} required). "
                f"Extendable components: {bad.tolist()}."
            )
            raise ValueError(msg)
        nom_attr_da = xr.DataArray(c.static.loc[pw_names, nom_attr], dims="name")
        if (
            bad := (nom_attr_da == 0)
            | (nom_attr_da.isnull())
            | (nom_attr_da == float("inf"))
        ).any():
            bad_entries = nom_attr_da.to_series()[bad.to_series()].index.tolist()
            msg = (
                f"Piecewise '{pw_attr}' breakpoints on a per-unit x-axis cannot be scaled to "
                f"absolute values for components with non-positive, non-finite or missing {nom_attr}. "
                f"Problematic components: {bad_entries}."
            )
            raise ValueError(msg)
        x_da = x_da * nom_attr_da
    x_da = x_da.where(valid_breakpoints)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=EvolvingAPIWarning)
        x_breakpoints = breakpoints(x_da)
        if cumulative_attr:
            slopes = y_da.shift({BREAKPOINT_DIM: -1})
            y_breakpoints = Slopes(slopes, y0=0).to_breakpoints(x_da)
        else:
            y_breakpoints = breakpoints(
                (y_da * x_da).fillna(0).where(valid_breakpoints)
            )
    return x_breakpoints, y_breakpoints, valid_breakpoints


def _create_y_var(
    m: Model,
    x_var: Variable,
    pw_names: pd.Index,
    aux_var_name: str,
) -> Variable:
    """Create auxiliary y variable for piecewise constraint."""
    coords = x_var.coords.drop_dims("name", errors="ignore").assign(name=pw_names)
    y_var = m.add_variables(coords=coords, name=aux_var_name)
    return y_var


def _to_da(piecewise_df: pd.DataFrame, attr: str) -> xr.DataArray:
    """Convert input to DataArray with given coords and dims."""
    da = xr.DataArray(piecewise_df.xs(attr, level="attribute", axis=1)).rename(
        breakpoint=BREAKPOINT_DIM
    )
    return da
