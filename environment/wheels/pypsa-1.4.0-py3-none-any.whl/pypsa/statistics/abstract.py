# SPDX-FileCopyrightText: PyPSA Contributors
#
# SPDX-License-Identifier: MIT

"""Statistics Accessor."""

from __future__ import annotations

import logging
import warnings
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Literal, cast

import pandas as pd
from pandas.api.types import is_list_like

from pypsa._options import options
from pypsa.common import normalize_carrier_nice_names
from pypsa.statistics.grouping import groupers

if TYPE_CHECKING:
    from collections.abc import Callable, Collection, Sequence

    from pypsa import Network, NetworkCollection
    from pypsa.components.components import PortsLike

logger = logging.getLogger(__name__)


def resolve_at_port(
    at_port: PortsLike | None,
    bus_carrier: str | Sequence[str] | None = None,
) -> PortsLike:
    """Resolve `at_port` default: "all" when `bus_carrier` is set, otherwise 0."""
    if at_port is False:
        warnings.warn(
            f"Passing `at_port={at_port}` is deprecated. Use `at_port=0` instead. Deprecated in version 1.1. Will be removed in version 2.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        return 0
    if at_port is True:
        warnings.warn(
            'Passing `at_port=True` is deprecated. Use `at_port="all"` instead. Deprecated in version 1.1. Will be removed in version 2.0.',
            DeprecationWarning,
            stacklevel=2,
        )
        return "all"
    if at_port is None:
        return "all" if bus_carrier else [0]
    return at_port


class AbstractStatisticsAccessor(ABC):
    """Abstract accessor to calculate different statistical values."""

    def __init__(self, n: Network | NetworkCollection) -> None:
        """Initialize the statistics accessor."""
        self._n = n

    @property
    def n(self) -> Network | NetworkCollection:
        """Get the network instance."""
        warnings.warn(
            "Accessing the network instance via `n` is deprecated. Use the network instance directly.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._n

    def _get_grouping(
        self,
        n: Network | NetworkCollection,
        c: str,
        groupby: Callable | Sequence[str] | str | bool,
        port: str,
        nice_names: bool = False,
    ) -> dict:
        by = None
        level = None
        if callable(groupby):
            try:
                by = groupby(n, c, port=port, nice_names=nice_names)
            except TypeError:
                by = groupby(n, c, nice_names=nice_names)
        elif isinstance(groupby, str) or is_list_like(groupby):
            key = cast("str | Sequence[str]", groupby)
            by = groupers[key](n, c, port=port, nice_names=nice_names)
        elif groupby is not False:
            msg = f"Argument `groupby` must be a string, list-like, callable, or False, got {repr(groupby)}."
            raise ValueError(msg)
        return {"by": by, "level": level}

    @property
    def is_multi_indexed(self) -> bool:
        """Check if the snapshots are multi-indexed.

        Returns
        -------
        bool
            True if the snapshots are multi-indexed, False otherwise.

        """
        # TODO could be moved to Network
        return isinstance(self._n.snapshots, pd.MultiIndex)

    def _aggregate_timeseries(
        self, obj: Any, weights: pd.Series, agg: str | Callable | bool = "sum"
    ) -> Any:
        """Calculate the weighted sum or average of a DataFrame or Series."""
        if not agg:
            return obj.T if isinstance(obj, pd.DataFrame) else obj

        if agg is True:
            agg = "sum"

        if agg == "mean":
            if isinstance(weights.index, pd.MultiIndex):
                weights = weights.groupby(level=0).transform(lambda w: w / w.sum())
            else:
                weights = weights / weights.sum()
            agg = "sum"

        return self._aggregate_with_weights(obj, weights, agg)

    # The following methods are implemented in the concrete classes
    @abstractmethod
    def _aggregate_with_weights(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _aggregate_components_groupby(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _aggregate_components_concat_values(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _aggregate_components_concat_data(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _apply_option_kwargs(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _aggregate_across_components(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _get_component_index(self, *args: Any, **kwargs: Any) -> Any:
        pass

    @abstractmethod
    def _concat_periods(self, *args: Any, **kwargs: Any) -> Any:
        pass

    def _align_static(self, data: pd.Series | pd.DataFrame) -> pd.Series | pd.DataFrame:
        """Align static component data with the index of the aggregated objects."""
        return data

    def _select(self, obj: Any, idx: pd.Index) -> Any:
        """Select the assets `idx` of the aggregated object `obj`."""
        return obj.loc[idx]

    def _aggregate_components(
        self,
        func: Callable,
        agg: Callable | str = "sum",
        components: Collection[str] | str | None = None,
        groupby: str | Sequence[str] | Callable | Literal[False] = "carrier",
        aggregate_across_components: bool = False,
        at_port: PortsLike | None = None,
        bus_carrier: str | Sequence[str] | None = None,
        carrier: str | Sequence[str] | None = None,
        nice_names: bool | None = True,
        drop_zero: bool | None = None,
        round: int | None = None,
    ) -> pd.Series | pd.DataFrame:
        """Apply a function and group the result for a collection of components."""
        d = {}
        n = self._n

        if is_one_component := isinstance(components, str):
            components = [components]
        if components is None:
            components = sorted(n.branch_components | n.one_port_components)
        if nice_names is None:
            # TODO move to _apply_option_kwargs
            nice_names = options.params.statistics.nice_names
        if nice_names:
            nice_name_series = n.c.carriers.static.nice_name
            if isinstance(nice_name_series.index, pd.MultiIndex):
                nice_name_series = nice_name_series.groupby(level="name").first()
            bus_carrier = normalize_carrier_nice_names(nice_name_series, bus_carrier)
            carrier = normalize_carrier_nice_names(nice_name_series, carrier)

        at_port = resolve_at_port(at_port, bus_carrier)

        for cn in components:
            c = n.c[cn]
            if c.static.empty:
                continue

            values = []
            for port in c._as_ports(at_port):
                try:
                    port_suffix = c.ports[port]
                except IndexError:
                    continue
                vals = func(n, cn, port_suffix)
                if self._aggregate_components_skip_iteration(vals):
                    continue

                vals = self._filter_active_assets(n, cn, vals)  # for multiinvest
                vals = self._filter_bus_carrier(n, cn, port_suffix, bus_carrier, vals)
                vals = self._filter_carrier(n, cn, carrier, vals)

                if self._aggregate_components_skip_iteration(vals):
                    continue

                if groupby is not False:
                    grouping = self._get_grouping(
                        n, cn, groupby, port=port_suffix, nice_names=nice_names
                    )
                    vals = self._aggregate_components_groupby(vals, grouping, agg, cn)
                # Avoid having 'component' as index name in multiindex
                elif isinstance(vals, pd.DataFrame | pd.Series):
                    vals = vals.rename_axis([*vals.index.names[:-1], "name"])
                values.append(vals)

            if not values:
                continue

            df = self._aggregate_components_concat_values(values, agg)

            d[cn] = df
        df = self._aggregate_components_concat_data(d, is_one_component)
        if not df.empty:
            df = self._apply_option_kwargs(
                df,
                drop_zero=drop_zero,
                round=round,
                nice_names=nice_names,  # TODO: nice_names does not have effect here
            )

        if aggregate_across_components:
            df = self._aggregate_across_components(df, agg)

        if isinstance(df, pd.Series):
            df.name = None

        return df

    def _aggregate_components_skip_iteration(self, vals: Any) -> bool:
        return False

    def _filter_active_assets(
        self, n: Network | NetworkCollection, c: str, obj: Any
    ) -> Any:
        """For static values iterate over periods and concat values."""
        if isinstance(obj, pd.DataFrame):
            return obj
        if {"snapshot", "period"} & set(getattr(obj, "dims", ())):
            return obj
        idx = self._get_component_index(obj, c)

        if not self.is_multi_indexed:
            mask = self._align_static(n.c[c].get_active_assets())
            return self._select(obj, mask.index[mask].intersection(idx))

        per_period = {}
        for p in n.investment_periods:
            mask = self._align_static(n.c[c].get_active_assets(p))
            per_period[p] = self._select(obj, mask.index[mask].intersection(idx))
        return self._concat_periods(per_period, c)

    def _filter_bus_carrier(
        self,
        n: Network | NetworkCollection,
        c: str,
        port: str,
        bus_carrier: str | Sequence[str] | None,
        obj: Any,
    ) -> Any:
        """Filter for components which are connected to bus with `bus_carrier`."""
        if bus_carrier is None:
            return obj

        idx = self._get_component_index(obj, c)
        buses = self._align_static(n.c[c].static[f"bus{port}"]).loc[idx]

        # Handle MultiIndex (Collection and Stochastic Networks)
        bus_carriers = n.c.buses.static.carrier
        if isinstance(bus_carriers.index, pd.MultiIndex):
            bus_carriers = bus_carriers.groupby(level="name").first()

        port_carriers = buses.map(bus_carriers)
        if isinstance(bus_carrier, str):
            if bus_carrier in bus_carriers.unique():
                mask = port_carriers == bus_carrier
            else:
                mask = port_carriers.str.contains(bus_carrier, regex=True)
        elif is_list_like(bus_carrier):
            mask = port_carriers.isin(bus_carrier)
        else:
            msg = f"Argument `bus_carrier` must be a string or list-like, got {type(bus_carrier)}"
            raise TypeError(msg)
        # links may have empty ports which results in NaNs
        mask = mask.where(mask.notnull(), False)
        return self._select(obj, buses.index[mask])

    def _filter_carrier(
        self,
        n: Network | NetworkCollection,
        c: str,
        carrier: str | Sequence[str] | None,
        obj: Any,
    ) -> Any:
        """Filter the DataFrame for components which have the specified carrier."""
        if carrier is None or "carrier" not in n.c[c].static:
            return obj

        idx = self._get_component_index(obj, c)
        carriers = self._align_static(n.c[c].static["carrier"]).loc[idx]

        if isinstance(carrier, str):
            if carrier in carriers.unique():
                mask = carriers == carrier
            else:
                mask = carriers.str.contains(carrier)
        elif is_list_like(carrier):
            mask = carriers.isin(carrier)
        else:
            msg = (
                f"Argument `carrier` must be a string or list-like, got {type(carrier)}"
            )
            raise TypeError(msg)

        return self._select(obj, carriers.index[mask])
