#!/usr/bin/env python3
"""
Linopy expressions module.

This module contains definition related to affine expressions.
"""

from __future__ import annotations

import functools
import logging
import operator
from abc import ABC, abstractmethod
from collections.abc import (
    Callable,
    Hashable,
    ItemsView,
    Iterable,
    Iterator,
    Mapping,
    Sequence,
)
from dataclasses import dataclass, field, replace
from itertools import product, zip_longest
from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    Self,
    TypeAlias,
    TypeVar,
    cast,
    overload,
)
from warnings import warn

import numpy as np
import pandas as pd
import polars as pl
import scipy
import xarray as xr
import xarray.core.groupby
from numpy import array, nan
from pandas.core.frame import DataFrame
from pandas.core.series import Series
from scipy.sparse import csc_matrix
from xarray import Coordinates, DataArray, Dataset, IndexVariable
from xarray.core.coordinates import DataArrayCoordinates, DatasetCoordinates
from xarray.core.indexes import Indexes
from xarray.core.types import JoinOptions
from xarray.core.utils import Frozen, either_dict_or_kwargs

try:
    # resolve breaking change in xarray 2025.03.0
    import xarray.computation.rolling
    from xarray.computation.rolling import DatasetRolling
except ImportError:
    import xarray.core.rolling
    from xarray.core.rolling import DatasetRolling  # type: ignore[no-redef]

from types import EllipsisType, NotImplementedType

from linopy import constraints, variables
from linopy.alignment import (
    _matmul_operand_to_dataarray,
    _matmul_operand_to_matrix,
    as_constant,
    as_dataarray,
    broadcast_to_coords,
    fill_missing_coords,
)
from linopy.common import (
    EmptyDeprecationWrapper,
    LocIndexer,
    assign_coords_multiindex_safe,
    assign_multiindex_safe,
    check_common_keys_values,
    check_has_nulls,
    check_has_nulls_polars,
    filter_nulls_polars,
    format_coord,
    format_single_expression,
    format_string_as_variable_name,
    forward_as_properties,
    generate_indices_for_printout,
    get_dims_with_index_levels,
    get_printout_labels,
    group_terms_polars,
    has_optimized_model,
    is_constant,
    iterate_slices,
    maybe_group_terms_polars,
    save_join,
    to_dataframe,
    to_polars,
)
from linopy.config import (
    SPARSE_DEPRECATION,
    options,
)
from linopy.constants import (
    CV_DIM,
    EQUAL,
    FACTOR_DIM,
    GREATER_EQUAL,
    GROUP_DIM,
    GROUP_STACK_DIM,
    HELPER_DIMS,
    LESS_EQUAL,
    STACKED_TERM_DIM,
    TERM_DIM,
)
from linopy.csr import CSRLinearExpression, Grid, _aux_coords, _densify_notice
from linopy.semantics import (
    AbsentType,
    FillValueLike,
    _legacy_coord_mismatch_message,
    _legacy_group_multiindex_message,
    _legacy_join_divisor_fill_message,
    _legacy_nan_rhs_constraint_message,
    _shared_dim_mismatch_message,
    absorb_absence,
    check_join_fill_value,
    check_user_nan,
    enforce_aux_conflict,
    enforce_merge_dims,
    first_mismatched_dim,
    is_nan_scalar,
    is_v1,
    join_fill,
    legacy_warnings_muted,
    reindex_like_if_needed,
    warn_legacy,
    warn_legacy_absence,
    warn_outside_linopy,
)
from linopy.types import (
    CONSTANT_TYPES,
    ConstantLike,
    DimsLike,
    ExpressionLike,
    SideLike,
    SignLike,
    VariableLike,
)

if TYPE_CHECKING:
    from linopy.constraints import (
        AnonymousScalarConstraint,
        ConstraintBase,
    )
    from linopy.model import Model
    from linopy.variables import ScalarVariable, Variable


FILL_VALUE = {"vars": -1, "coeffs": np.nan, "const": np.nan}


def exprwrap(
    method: Callable, *default_args: Any, **new_default_kwargs: Any
) -> Callable:
    @functools.wraps(method)
    def _exprwrap(
        expr: LinearExpression | QuadraticExpression, *args: Any, **kwargs: Any
    ) -> LinearExpression | QuadraticExpression:
        for k, v in new_default_kwargs.items():
            kwargs.setdefault(k, v)
        return expr.__class__(
            method(_expr_unwrap(expr), *default_args, *args, **kwargs), expr.model
        )

    _exprwrap.__doc__ = (
        f"Wrapper for the xarray {method.__qualname__} function for linopy.Variable"
    )
    if new_default_kwargs:
        _exprwrap.__doc__ += f" with default arguments: {new_default_kwargs}"

    return _exprwrap


def _expr_unwrap(
    maybe_expr: Any | LinearExpression | QuadraticExpression,
) -> Any:
    if isinstance(maybe_expr, LinearExpression | QuadraticExpression):
        return maybe_expr.data

    return maybe_expr


logger = logging.getLogger(__name__)


def _stack_into_term_dim(ds: Dataset, dims: list[Hashable]) -> Dataset:
    """
    Stack ``dims`` into the term dimension.

    ``Dataset.stack`` reshapes with an inferred ``-1`` that numpy cannot
    resolve on zero-element data (https://github.com/PyPSA/linopy/issues/906),
    so an empty dataset is stacked onto a term dimension of size 0 instead.
    """
    if ds.vars.size:
        return ds.stack({TERM_DIM: dims}, create_index=False)

    for name, da in ds.data_vars.items():
        kept = [d for d in da.dims if d not in dims]
        shape = [da.sizes[d] for d in kept] + [0]
        ds[name] = DataArray(da.values.reshape(shape), dims=kept + [TERM_DIM])
    return ds


def _drop_coords_on_dims(ds: Dataset, dims: Iterable[Hashable]) -> Dataset:
    """
    Drop every coordinate touching the given dimensions.

    A coordinate on a dimension that is being reduced away must not survive
    the reduction: an auxiliary coordinate left in place would ride a
    subsequent stack onto the helper term dimension and break later
    alignment (https://github.com/PyPSA/linopy/issues/295).
    """
    dims = set(dims)
    return ds.drop_vars(k for k, c in ds.coords.items() if dims & set(c.dims))


def _check_override_sizes(left: DataArray, right: DataArray) -> None:
    """
    Reject ``join="override"`` when a shared dim has different sizes.

    ``override`` is the explicit form of positional alignment (§10), so pairing
    mismatched sizes would relabel one operand's data onto the other's labels —
    the silent-wrong-answer hazard the join is meant to make explicit.
    """
    shared = set(left.dims) & set(right.dims)
    bad = sorted((d for d in shared if left.sizes[d] != right.sizes[d]), key=str)
    if not bad:
        return
    sizes = ", ".join(
        f"{d!r}: left={left.sizes[d]}, right={right.sizes[d]}" for d in bad
    )
    raise ValueError(
        f"join='override' requires matching sizes on shared dimensions, but "
        f"sizes differ on {sizes}. Use join='inner' / 'outer' / 'left' / "
        f"'right' to combine by label, or reshape one side first."
    )


def _resolve_group(group: Any, data: Dataset) -> Any:
    """
    Normalize a groupby key.

    Unwrap a single-element key list to the scalar key, and resolve a string
    naming a coordinate to that coordinate -- so ``groupby("name")`` behaves
    like ``groupby(data["name"])``, mirroring xarray. Other inputs (Series,
    DataFrame, DataArray, multi-key lists) are returned unchanged.
    """
    if isinstance(group, (list, tuple)) and len(group) == 1:
        group = group[0]
    if isinstance(group, str) and group in data.coords:
        group = data[group]
    return group


def _multikey_value_frame(group: Any, data: Dataset) -> pd.DataFrame | None:
    """
    Gather a multi-key list of coordinate names into a value frame.

    Return a DataFrame of the named coordinates when all keys are 1-D
    coordinates sharing a single dimension -- so the list rides the fast
    reindex path -- otherwise None.
    """
    is_name_list = (
        isinstance(group, (list, tuple))
        and len(group) > 1
        and all(isinstance(g, str) and g in data.coords for g in group)
    )
    if not is_name_list:
        return None
    coord_dims = {data[g].dims for g in group}
    if len(coord_dims) != 1 or len(next(iter(coord_dims))) != 1:
        return None
    names = list(group)
    return data[names].to_dataframe()[names]


def _flatten_multidim_group(
    group: DataArray, data: Dataset
) -> tuple[pd.Series, Dataset]:
    """
    Flatten an N-D DataArray grouper into a 1-D key over a stacked dimension.

    A multi-dimensional grouper defines its groups jointly over all its dims, so
    the data is stacked over those dims and the grouper's values are raveled into
    a Series aligned with the stacked axis. This lets the fast path reduce over
    every grouper dim at once instead of leaking the extra dims into the result.
    """
    group_dims = list(group.dims)
    data = data.stack({GROUP_STACK_DIM: group_dims}, create_index=False)
    series = pd.Series(group.transpose(*group_dims).values.reshape(-1), name=group.name)
    series.index.name = GROUP_STACK_DIM
    return series, data


def _grouper_dims(group: Any) -> list[Hashable] | None:
    """
    The dims a grouper consumes when grouping, or None for grouper types whose
    dims are unknown here (exotic hashables, validated by xarray's groupby).
    """
    if isinstance(group, (DataArray, IndexVariable)):
        return list(group.dims)
    if isinstance(group, (pd.Series, pd.DataFrame)):
        return [group.index.name]
    return None


def _restore_group_dim_position(
    result: Dataset,
    original_dims: tuple[Hashable, ...],
    grouped_dims: Sequence[Hashable] | None = None,
) -> Dataset:
    """
    Move the new group dimension into the slot the grouped dimension occupied,
    matching xarray's groupby-reduce and linopy <= 0.8.0.

    Surviving dims keep their order; the group dim(s) are reinserted where the
    consumed dim(s) used to be. The coordinate variables are reordered too so the
    dataset's canonical dim order (which the constructor's ``broadcast`` re-derives
    from coordinate-insertion order) matches, instead of trailing the group dim.
    This covers the fallback, which appends the group dim, and normalises the
    scatter kernel's target-ordered output.

    ``grouped_dims`` names the dims the grouping consumed. It must be passed
    whenever the grouper's name can equal a grouped dim (the replacement dim then
    shadows the consumed one, so it cannot be inferred from the dims alone);
    when None, the consumed dims are inferred as those absent from the result.

    Numpy-backed terms are made C-contiguous so downstream flattening (LP/solver
    export) ravels a view instead of copying; a no-op when already contiguous, as
    the scatter kernel's output is. Dask arrays are left lazy.
    """
    if grouped_dims is None:
        consumed = [d for d in original_dims if d not in result.dims]
    else:
        consumed = [d for d in original_dims if d in set(grouped_dims)]
    if not consumed:
        return result
    new_dims = [str(d) for d in result.dims if d not in original_dims or d in consumed]
    order: list[Hashable] = []
    for d in original_dims:
        if d not in consumed:
            order.append(d)
        elif new_dims:
            order.extend(new_dims)
            new_dims = []
    result = result.transpose(*order, missing_dims="ignore")
    reordered_coords = {
        d: result[d]
        for d in order
        if d in result.coords and not isinstance(result.get_index(d), pd.MultiIndex)
    }
    result = result.assign_coords(reordered_coords)
    for name in ("coeffs", "vars"):
        term = result[name]
        if term.chunks is None:
            result[name] = (term.dims, np.ascontiguousarray(term.values))
    return result


def _warn_dense_grid(frame: pd.DataFrame) -> None:
    """
    Warn before materialising a multi-key cartesian grid when most cells
    would be absent, pointing to ``observed=True`` for a compact result.
    """
    observed = len(frame.drop_duplicates())
    grid = int(np.prod([frame[k].nunique() for k in frame.columns]))
    if grid > 2 * observed and grid - observed > 10_000:
        warn(
            f"Grouping a LinearExpression by {list(frame.columns)} produces a "
            f"dense {grid:,}-cell grid, but only {observed:,} of those "
            f"combinations occur -- the {grid - observed:,} absent ones are "
            f"carried as empty cells. Pass `observed=True` to keep the result "
            f"compact over only the observed combinations.",
            UserWarning,
            stacklevel=3,
        )


def _check_grouper_alignment(group: Any, data: Dataset) -> None:
    """
    Ensure an indexed grouper's labels match the data along each shared dim.

    The fast path matches a ``pd.Series``, ``pd.DataFrame`` or ``DataArray``
    grouper to the expression by position, so a grouper whose coordinates are
    reordered -- or a different set entirely -- relative to the expression would
    silently regroup. linopy does not reindex the grouper: it checks that the
    labels match and raises otherwise, leaving the caller to align the grouper
    explicitly. A grouper without an index along a dimension has nothing to align
    by and keeps the positional match.
    """
    shared: list[tuple[Hashable, pd.Index]]
    if isinstance(group, (pd.Series, pd.DataFrame)):
        shared = [(group.index.name, group.index)]
    elif isinstance(group, DataArray):
        shared = [
            (dim, group.get_index(dim)) for dim in group.dims if dim in group.indexes
        ]
    else:
        return
    for dim, index in shared:
        if dim not in data.indexes or index.equals(data.indexes[dim]):
            continue
        detail = (
            "the same labels in a different order"
            if set(index) == set(data.indexes[dim])
            else "a different set of labels"
        )
        raise ValueError(
            f"the grouper's labels along dimension {dim!r} do not match the "
            f"expression's coordinates ({detail}). linopy matches groupers by "
            f"position and does not reindex; reorder the grouper to the "
            f"expression's {dim!r} coordinates before grouping."
        )


def _encode_multikey_group(
    frame: pd.DataFrame,
) -> tuple[pd.Series, pd.MultiIndex]:
    """
    Encode a multi-key group frame as a single integer-coded Series.

    ``_grouped_sum`` groups by one key, so each row's tuple of key values is
    mapped to an integer. The codes are sorted by key tuple, so the group order
    of the result matches the single-key path, which sorts as well. The frame is
    already aligned to the data (see :func:`_check_grouper_alignment`), so no
    reindexing is needed. The returned uniques let
    :func:`_restore_multikey_index` rebuild the MultiIndex on the result.
    """
    codes, uniques = pd.factorize(pd.MultiIndex.from_frame(frame), sort=True)
    coded = pd.Series(codes, index=frame.index)
    return coded, uniques.set_names([str(col) for col in frame.columns])


def _restore_multikey_index(
    ds: Dataset,
    uniques: pd.MultiIndex,
    stacked_survives: bool,
) -> Dataset:
    """
    Rebuild the multi-key group labels encoded by _encode_multikey_group.

    Under v1 semantics a stacked result that survives (``stacked_survives``)
    keeps a flat group dimension with the key values as auxiliary coordinates.
    Otherwise the keys become a MultiIndex — either because the caller unstacks
    it right after (``stacked_survives`` is False), or under legacy semantics,
    where a *surviving* ``group`` MultiIndex additionally warns about the
    deprecated result, whichever grouper minted it.
    """
    index = uniques.take(ds.indexes[GROUP_DIM])
    level_names = list(index.names)
    index.name = GROUP_DIM
    if stacked_survives and is_v1():
        return ds.assign_coords(
            {n: (GROUP_DIM, index.get_level_values(n)) for n in level_names}
        )
    if stacked_survives:
        warn_legacy(_legacy_group_multiindex_message(level_names))
    return ds.assign_coords(Coordinates.from_pandas_multiindex(index, GROUP_DIM))


@dataclass
@forward_as_properties(groupby=["dims", "groups"])
class LinearExpressionGroupby:
    """
    GroupBy object specialized to grouping LinearExpression objects.

    ``obj`` is the grouped expression, or its dense dataset. A CSR-backed
    expression is only densified by operations without a sparse path.
    """

    obj: xr.Dataset | BaseExpression
    group: Hashable | DataArray | IndexVariable | pd.Series | pd.DataFrame
    model: Any
    kwargs: Mapping[str, Any] = field(default_factory=dict)

    @property
    def data(self) -> Dataset:
        return self.obj if isinstance(self.obj, Dataset) else self.obj.data

    @property
    def _csr(self) -> CSRLinearExpression | None:
        return self.obj._csr if isinstance(self.obj, LinearExpression) else None

    @property
    def _labels(self) -> Dataset:
        """The coordinates to resolve groupers against, without densifying."""
        csr = self._csr
        return self.data if csr is None else csr.grid.to_dataset()

    @property
    def groupby(self) -> xarray.core.groupby.DatasetGroupBy:
        """
        Groups the data using the specified group and kwargs.

        Returns
        -------
        xarray.core.groupby.DataArrayGroupBy
            The groupby object.
        """
        data = self.data
        group = _resolve_group(self.group, data)

        if isinstance(group, pd.DataFrame):
            raise ValueError(
                "Grouping by a DataFrame only supported for `sum` operation with `use_fallback=False`."
            )
        if isinstance(group, pd.Series):
            group = DataArray(group, name=group.name or "group")

        # detach an attached free coordinate (never an indexed/level coord)
        if (
            isinstance(group, DataArray)
            and group.name in set(data.coords) - set(data.dims)
            and group.name not in data.xindexes
        ):
            data = data.drop_vars([group.name])

        return data.groupby(group=group, **self.kwargs)

    def map(
        self,
        func: Callable[..., Dataset],
        shortcut: bool | None = None,
        args: tuple[()] = (),
        **kwargs: Any,
    ) -> LinearExpression:
        """
        Apply a specified function to the groupby object.

        Parameters
        ----------
        func : callable
            The function to apply.
        shortcut : bool, optional
            Deprecated and ignored. Will be removed in linopy v1.
        args : tuple, optional
            The arguments to pass to the function.
        **kwargs
            Arbitrary keyword arguments.

        Returns
        -------
        LinearExpression
            The result of applying the function to the groupby object.
        """
        if shortcut is not None:
            warn(
                "The `shortcut` argument is deprecated, no longer has any effect "
                "and will be removed in linopy v1.",
                FutureWarning,
            )
        return LinearExpression(self.groupby.map(func, args=args, **kwargs), self.model)

    def sum(
        self,
        use_fallback: bool = False,
        observed: bool = False,
        sparse: bool | None = None,
    ) -> LinearExpression:
        """
        Sum the expression over each group.

        Replaces the grouped dimension with one entry per group, each holding
        the sum of its members' terms.

        Parameters
        ----------
        use_fallback : bool
            Use the slower fallback groupby-sum implementation instead of the
            default one. Kept as an escape hatch. Leave at False unless the
            default misbehaves. Defaults to False.
        sparse : bool, optional
            Deprecated, build the model with ``Model(sparse=True)`` instead.
            Build the grouped sum in CSR form behind the ordinary
            LinearExpression type — no group-size padding; a still-sparse
            lhs reaching ``Model.add_constraints`` with ``freeze=True``
            becomes a CSRConstraint directly, other operations expand to
            the dense rectangle in canonical term layout. Supports pandas
            Series/DataFrame, 1-D DataArray and coordinate-name-list groupers
            over an existing dimension; with a name list and ``observed=True``
            the CSR result stays compact over the observed key combinations.
            Requires v1 semantics. Defaults to True for a sparse model, a
            CSR-backed expression or the deprecated
            ``linopy.options["sparse_groupby"]``. See :mod:`linopy.csr`.
        observed : bool
            Only applies when grouping by a list of coordinate names. If True,
            keep the result stacked over the observed key combinations (a
            ``group`` dimension: a ``MultiIndex`` under legacy semantics, a
            flat dimension with the key values as auxiliary coordinates under
            v1) instead of unstacking into one dimension per key, which
            materialises the dense cartesian grid.
            Defaults to False, mirroring xarray. Not supported together with
            `use_fallback`.

        Returns
        -------
        LinearExpression
            The summed expression, with one entry per group.
        """
        if observed and use_fallback:
            raise ValueError(
                "`observed=True` is not supported with `use_fallback=True`."
            )

        labels = self._labels
        group = _resolve_group(self.group, labels)
        _check_grouper_alignment(group, labels)

        multikey_frame = None if use_fallback else _multikey_value_frame(group, labels)

        self.model._check_sparse_semantics()
        csr = self._csr
        explicit_sparse = sparse is True
        if sparse is None:
            sparse = is_v1() and (
                self.model.sparse or options["sparse_groupby"] or csr is not None
            )
        else:
            warn_outside_linopy(
                f"groupby(...).sum(sparse=...) {SPARSE_DEPRECATION}.", FutureWarning
            )
            if sparse and not is_v1():
                raise ValueError(
                    "sparse groupby-sum requires v1 semantics; opt in with "
                    "linopy.options['semantics'] = 'v1'."
                )
        if multikey_frame is not None and not observed:
            _warn_dense_grid(multikey_frame)

        if sparse:
            grouper = multikey_frame
            if grouper is None:
                is_1d = isinstance(group, DataArray) and group.ndim == 1
                grouper = group.to_pandas() if is_1d else group
            if csr is None:
                source: Dataset | CSRLinearExpression = self.data
                coord_dims = tuple(
                    str(d) for d in self.data.coeffs.dims if d != TERM_DIM
                )
            else:
                source, coord_dims = csr, csr.grid.dims
            supported = (
                not use_fallback
                and isinstance(grouper, (pd.Series, pd.DataFrame))
                and grouper.index.name in coord_dims
            )
            if supported:
                stacked = observed or multikey_frame is None
                group_name = (
                    "group"
                    if isinstance(grouper, pd.DataFrame)
                    else str(grouper.name or "group")
                )
                res = CSRLinearExpression.from_grouper(
                    source, self.model, grouper, group_name, stacked, coord_dims
                )
                return LinearExpression._from_csr(res, self.model)
            if explicit_sparse:
                raise ValueError(
                    "sparse=True supports only a pandas Series or DataFrame, 1-D "
                    "DataArray or list of coordinate names as grouper over an "
                    "existing dimension, without use_fallback."
                )
            if csr is None:
                _densify_notice(
                    "groupby-sum with a grouper without a sparse path", self.model
                )

        if multikey_frame is not None:
            group = multikey_frame

        data = self.data
        original_dims = self.data.coeffs.dims
        grouped_dims = _grouper_dims(group)
        is_multidim_grouper = (
            isinstance(group, DataArray)
            and group.ndim > 1
            and set(group.dims) <= set(data.dims)
        )
        if is_multidim_grouper and not use_fallback:
            group, data = _flatten_multidim_group(group, data)

        fast_path_types = (pd.Series, pd.DataFrame, xr.DataArray)
        if isinstance(group, fast_path_types) and not use_fallback:
            final_group_name = (
                "group"
                if isinstance(group, pd.DataFrame)
                else getattr(group, "name", "group") or "group"
            )

            if isinstance(group, DataArray):
                group = group.to_pandas()

            multikey_decode = None
            if isinstance(group, pd.DataFrame):
                group, multikey_decode = _encode_multikey_group(group)

            assert isinstance(group, pd.Series)
            ds = self._grouped_sum(group, data)

            if multikey_decode is not None:
                ds = _restore_multikey_index(
                    ds,
                    multikey_decode,
                    stacked_survives=multikey_frame is None or observed,
                )

            ds = ds.rename({GROUP_DIM: final_group_name})
            if multikey_frame is not None and not observed:
                ds = ds.unstack(
                    final_group_name, fill_value=LinearExpression._fill_value
                )
        else:

            def func(ds: Dataset) -> Dataset:
                ds = LinearExpression._sum(ds, str(self.groupby._group_dim))
                ds = ds.assign_coords({TERM_DIM: np.arange(len(ds._term))})
                return ds

            ds = self.groupby.map(func)

        ds = _restore_group_dim_position(ds, original_dims, grouped_dims)
        return LinearExpression(ds, self.model)

    def _grouped_sum(self, group: pd.Series, data: Dataset | None = None) -> Dataset:
        """
        Sum groups by scattering all terms directly into the final padded arrays.

        Every group member keeps its block of ``nterm`` terms, so the resulting
        term dimension has size ``max_group_size * nterm`` and smaller groups are
        padded with fill values. The group dimension replaces the grouped one in
        place: all surviving dimensions are passed as core dims, so ``apply_ufunc``
        emits the target axis order and the padded arrays are allocated once,
        contiguous. The constant is reduced before the term scatters so its
        temporaries are freed before the padded arrays exist, keeping peak memory
        at input + result. Dask arrays are collapsed to a single chunk (no per-dim
        parallelism) since every dimension is now a core dim.
        """
        data = self.data if data is None else data
        group_dim = group.index.name
        fill_value = LinearExpression._fill_value

        if data.chunks:
            data = data.chunk(-1)

        codes, unique_groups = pd.factorize(group, sort=True)
        if (codes == -1).any():
            raise ValueError(
                "Cannot group by a pandas object containing NaN values. "
                "Drop or fill the corresponding entries before grouping."
            )

        n_groups = len(unique_groups)
        max_size = int(np.bincount(codes, minlength=n_groups).max()) if n_groups else 0
        position_in_group = pd.Series(codes).groupby(codes).cumcount().to_numpy()
        nterm = data.sizes[TERM_DIM]

        def scatter(da: DataArray, fill: Any) -> DataArray:
            """
            Scatter each member's terms into its group's padded slot, keeping
            the grouped dimension's position.
            """
            da = da.transpose(..., TERM_DIM)
            dims_in = list(da.dims)
            group_axis = dims_in.index(group_dim)
            target = [GROUP_DIM if d == group_dim else d for d in dims_in]

            def scatter_terms(values: np.ndarray) -> np.ndarray:
                surv_shape = [
                    n_groups if d == group_dim else s
                    for d, s in zip(dims_in, values.shape)
                    if d != TERM_DIM
                ]
                out = np.full((*surv_shape, nterm, max_size), fill, dtype=values.dtype)
                grouped = np.moveaxis(out, group_axis, 0)
                grouped[codes, ..., :, position_in_group] = np.moveaxis(
                    values, group_axis, 0
                )
                return out.reshape((*surv_shape, nterm * max_size))

            return xr.apply_ufunc(
                scatter_terms,
                da,
                input_core_dims=[dims_in],
                output_core_dims=[target],
                exclude_dims={group_dim, TERM_DIM},
                dask="parallelized",
                dask_gufunc_kwargs={
                    "output_sizes": {GROUP_DIM: n_groups, TERM_DIM: nterm * max_size}
                },
                output_dtypes=[da.dtype],
            )

        def group_sum(da: DataArray) -> DataArray:
            """
            Sum the constant term within each group, keeping the grouped
            dimension's position.
            """
            dims_in = list(da.dims)
            group_axis = dims_in.index(group_dim)
            target = [GROUP_DIM if d == group_dim else d for d in dims_in]

            def reduce(values: np.ndarray) -> np.ndarray:
                members = np.moveaxis(values, group_axis, 0)
                summed = np.zeros((n_groups, *members.shape[1:]), dtype=values.dtype)
                np.add.at(summed, codes, np.where(np.isnan(members), 0, members))
                return np.moveaxis(summed, 0, group_axis)

            return xr.apply_ufunc(
                reduce,
                da,
                input_core_dims=[dims_in],
                output_core_dims=[target],
                exclude_dims={group_dim},
                dask="parallelized",
                dask_gufunc_kwargs={"output_sizes": {GROUP_DIM: n_groups}},
                output_dtypes=[da.dtype],
            )

        const = group_sum(data.const)
        ds = Dataset(
            {
                "coeffs": scatter(data.coeffs, fill_value["coeffs"]),
                "vars": scatter(data.vars, fill_value["vars"]),
                "const": const,
            }
        )
        return ds.assign_coords({GROUP_DIM: unique_groups})

    def roll(self, **kwargs: Any) -> LinearExpression:
        """
        Roll the groupby object.

        **kwargs
            Arbitrary keyword arguments.

        Returns
        -------
        LinearExpression
            The result of rolling over the groups.
        """
        return self.map(Dataset.roll, **kwargs)


@dataclass
@forward_as_properties(rolling=["center", "dim", "obj", "rollings", "window"])
class LinearExpressionRolling:
    """
    GroupBy object specialized to grouping LinearExpression objects.
    """

    rolling: DatasetRolling
    model: Any

    def sum(self, **kwargs: Any) -> LinearExpression:
        data = self.rolling.construct("_rolling_term", keep_attrs=True)
        ds = (
            data[["coeffs", "vars"]]
            .rename({TERM_DIM: STACKED_TERM_DIM})
            .stack({TERM_DIM: [STACKED_TERM_DIM, "_rolling_term"]}, create_index=False)
        )
        ds = assign_multiindex_safe(ds, const=data.const.sum("_rolling_term"))
        return LinearExpression(ds, self.model)


class BaseExpression(ABC):
    __slots__ = ("_data", "_model")
    __array_ufunc__ = None
    __array_priority__ = 10000
    __pandas_priority__ = 10000

    _fill_value = FILL_VALUE
    _data: Dataset

    @property
    @abstractmethod
    def flat(self) -> pd.DataFrame: ...

    @abstractmethod
    def to_polars(self) -> pl.DataFrame: ...

    @abstractmethod
    def linear_terms(self) -> tuple[np.ndarray, np.ndarray]: ...

    def __init__(self, data: Dataset | Any | None, model: Model) -> None:
        from linopy.model import Model

        if not isinstance(model, Model):
            raise ValueError("model must be an instance of linopy.Model")

        if data is None:
            da = xr.DataArray([], dims=[TERM_DIM])
            data = Dataset({"coeffs": da, "vars": da, "const": 0.0})
        elif isinstance(data, CONSTANT_TYPES):
            const = as_dataarray(data)
            da = xr.DataArray([], dims=[TERM_DIM])
            data = Dataset({"coeffs": da, "vars": da, "const": const})
        elif not isinstance(data, Dataset):
            supported_types = ", ".join(
                map(lambda s: s.__qualname__, (*CONSTANT_TYPES, Dataset))
            )
            raise ValueError(
                f"data must be an instance of {supported_types}, got {type(data)}"
            )

        data = cast(Dataset, data)
        if not set(data).issuperset({"coeffs", "vars"}):
            raise ValueError(
                "data must contain the fields 'coeffs' and 'vars' or 'const'"
            )

        if np.issubdtype(data.vars, np.floating):
            data = assign_multiindex_safe(
                data, vars=data.vars.fillna(-1).astype(model._dtypes["labels"])
            )
        if not np.issubdtype(data.coeffs, np.floating):
            data["coeffs"].values = data.coeffs.values.astype(float)

        data = fill_missing_coords(data)

        if TERM_DIM not in data.dims:
            raise ValueError("data must contain one dimension ending with '_term'")

        if "const" not in data:
            data = data.assign(const=0.0)
        elif not np.issubdtype(data.const, np.floating):
            data = assign_multiindex_safe(data, const=data.const.astype(float))

        (data,) = xr.broadcast(data, exclude=HELPER_DIMS)
        data = cast(Dataset, data)
        (coeffs_vars,) = xr.broadcast(data[["coeffs", "vars"]], exclude=[FACTOR_DIM])
        coeffs_vars_dict = {str(k): v for k, v in coeffs_vars.items()}
        data = assign_multiindex_safe(data, **coeffs_vars_dict)

        data = data.transpose(..., TERM_DIM)

        # ensure helper dimensions are not set as coordinates
        if drop_dims := set(HELPER_DIMS).intersection(data.coords):
            # TODO: add a warning here, routines should be safe against this
            data = data.drop_vars(drop_dims)

        data = data.assign_attrs(name=None)
        self._model = model
        self._data = cast(Dataset, data)

    def __repr__(self) -> str:
        """
        Print the expression arrays.
        """
        max_lines = options["display_max_rows"]
        dims = list(self.coord_dims)
        dim_names = self.coord_names
        ndim = len(dims)
        dim_sizes = list(self.coord_sizes.values())
        size = np.prod(dim_sizes)  # that the number of theoretical printouts
        masked_entries = 0  # (~self.mask).sum().values.item() if self.mask
        lines = []

        header_string = f"{self.type} (sparse)" if self.is_sparse else self.type

        if size > 1 or ndim > 0:
            row_labels = get_printout_labels(self.coords.to_dataset(), dims)
            for indices in generate_indices_for_printout(dim_sizes, max_lines):
                if indices is None:
                    lines.append("\t\t...")
                else:
                    coord = [row_labels[i][ind] for i, ind in enumerate(indices)]
                    if self.mask is None or self.mask.values[indices]:
                        expr = format_single_expression(
                            *self._printout_cell(indices), self.model
                        )

                        line = format_coord(coord) + f": {expr}"
                    else:
                        line = format_coord(coord) + ": None"
                    lines.append(line)

            shape_str = ", ".join(f"{d}: {s}" for d, s in zip(dim_names, dim_sizes))
            mask_str = f" - {masked_entries} masked entries" if masked_entries else ""
            underscore = "-" * (len(shape_str) + len(mask_str) + len(header_string) + 4)
            lines.insert(0, f"{header_string} [{shape_str}]{mask_str}:\n{underscore}")
        elif size == 1:
            expr = format_single_expression(*self._printout_cell(()), self.model)
            lines.append(f"{header_string}\n{'-' * len(header_string)}\n{expr}")
        else:
            lines.append(f"{header_string}\n{'-' * len(header_string)}\n<empty>")

        return "\n".join(lines)

    def _printout_cell(
        self, indices: tuple[Any, ...]
    ) -> tuple[np.ndarray, np.ndarray, Any]:
        """Coefficients, variable labels and constant of one cell of the repr."""
        return (
            self.coeffs.values[indices],
            self.vars.values[indices],
            self.const.values[indices],
        )

    @property
    def is_sparse(self) -> bool:
        """Whether the expression is backed by a sparse CSR matrix (:mod:`linopy.csr`)."""
        return False

    @property
    def is_constant(self) -> bool:
        """True if the expression contains no variables."""
        return self.data.sizes[TERM_DIM] == 0

    def print(self, display_max_rows: int = 20, display_max_terms: int = 20) -> None:
        """
        Print the linear expression.

        Parameters
        ----------
        display_max_rows : int
            Maximum number of rows to be displayed.
        display_max_terms : int
            Maximum number of terms to be displayed.
        """
        with options as opts:
            opts.set_value(
                display_max_rows=display_max_rows, display_max_terms=display_max_terms
            )
            print(self)

    @abstractmethod
    def __add__(self, other: SideLike) -> Self | QuadraticExpression: ...

    @abstractmethod
    def __radd__(self, other: SideLike) -> Self: ...

    @abstractmethod
    def __sub__(self, other: SideLike) -> Self | QuadraticExpression: ...

    @abstractmethod
    def __rsub__(self, other: SideLike) -> Self: ...

    @abstractmethod
    def __mul__(self, other: SideLike) -> Self | QuadraticExpression: ...

    @abstractmethod
    def __rmul__(self, other: SideLike) -> Self | QuadraticExpression: ...

    @abstractmethod
    def __matmul__(self, other: SideLike) -> Self | QuadraticExpression: ...

    @abstractmethod
    def __pow__(self, other: int) -> QuadraticExpression: ...

    def __neg__(self) -> Self:
        """
        Get the negative of the expression.
        """
        return self.assign_multiindex_safe(coeffs=-self.coeffs, const=-self.const)

    def _multiply_by_linear_expression(
        self, other: LinearExpression | ScalarLinearExpression
    ) -> LinearExpression | QuadraticExpression:
        if isinstance(other, ScalarLinearExpression):
            other = other.to_linexpr()

        if other.nterm > 1:
            raise TypeError("Multiplication of multiple terms is not supported.")

        if other.is_constant:
            return cast(LinearExpression, self._multiply_by_constant(other.const))
        if self.is_constant:
            return cast(LinearExpression, other._multiply_by_constant(self.const))

        # multiplication: (v1 + c1) * (v2 + c2) = v1 * v2 + c1 * v2 + c2 * v1 + c1 * c2
        # with v being the variables and c the constants
        # merge on factor dimension only returns v1 * v2 + c1 * c2
        enforce_merge_dims(
            [self.data, other.data],
            concat_dim=FACTOR_DIM,
            context="quadratic product",
            alignment="by label, as an outer join",
            joinable=False,
        )
        warn_legacy_absence(self.const, other.const)
        ds = other.data[["coeffs", "vars"]].sel(_term=0).broadcast_like(self.data)
        ds = assign_multiindex_safe(ds, const=other.const)
        join: JoinOptions = (
            "override" if _coord_sizes_agree([self.data, ds]) else "outer"
        )
        res = merge([self, ds], dim=FACTOR_DIM, cls=QuadraticExpression, join=join)
        with legacy_warnings_muted():
            if self.has_constant:
                res = res + other.reset_const() * self.const.fillna(0)
            if other.has_constant:
                res = res + self.reset_const() * other.const.fillna(0)
        return cast(QuadraticExpression, res)

    def _absorb_join_absence(self, fill_value: FillValueLike) -> Self:
        """A position the join left absent (§10 ``ABSENT``) carries no term."""
        if not isinstance(fill_value, AbsentType):
            return self
        return self.__class__(absorb_absence(self.data), self.model)

    def _align_constant(
        self,
        other: DataArray,
        fill_value: FillValueLike = 0,
        join: JoinOptions | None = None,
    ) -> tuple[DataArray, DataArray, bool]:
        """
        Align a constant DataArray with self.const.

        Parameters
        ----------
        other : DataArray
            The constant to align.
        fill_value : float or ABSENT, default: 0
            Value the constant takes at the positions the join creates.
            ``ABSENT`` fills both sides with NaN, so the created position
            comes out absent instead of carrying either operand's value.
        join : str, optional
            Alignment method. When None, follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally
            (size-aware).

        Returns
        -------
        self_const : DataArray
            The expression's const, potentially reindexed.
        aligned : DataArray
            The aligned constant.
        needs_data_reindex : bool
            Whether the expression's data needs reindexing. ``False`` whenever
            the shared-dim indexes already agree (``override`` / ``left`` /
            ``exact``), so the caller skips a full-dataset ``reindex_like``
            deepcopy on the hot multiply/add path; only the label-changing
            joins (inner / outer / right) return ``True``.

        Notes
        -----
        The §11 aux-coord check runs on every join path — gating it behind
        ``join is None`` would let ``join="override"`` silently drop a
        conflicting coord (#295). The ``exact`` mismatch is detected here
        rather than by ``xr.align(join="exact")``, whose wording is not
        API-stable across xarray releases.
        """
        enforce_aux_conflict([self.const, other])
        other_fill = {other.name: join_fill(fill_value, 0)}
        if join is None:
            if is_v1():
                join = "exact"
            else:  # LEGACY: remove at 1.0
                mismatch = first_mismatched_dim(self.const, other)
                if mismatch is not None:
                    warn_legacy(
                        _legacy_coord_mismatch_message(
                            "this operator's constant operand", *mismatch
                        )
                    )
                if other.sizes == self.const.sizes:
                    return self.const, other.assign_coords(coords=self.coords), False
                aligned = other.reindex_like(self.const, fill_value=other_fill)
                return self.const, aligned, False

        if join == "override":
            _check_override_sizes(self.const, other)
            return self.const, other.assign_coords(coords=self.coords), False
        if join == "left":
            aligned = other.reindex_like(self.const, fill_value=other_fill)
            return self.const, aligned, False
        if join == "exact":
            mismatch = first_mismatched_dim(self.const, other)
            if mismatch is not None:
                raise ValueError(_shared_dim_mismatch_message(*mismatch))
            return self.const, other, False
        self_const, aligned = xr.align(
            self.const, other, join=join, fill_value=other_fill
        )
        self_fill = np.nan if isinstance(fill_value, AbsentType) else 0
        self_const = reindex_like_if_needed(self.const, self_const, self_fill)
        return self_const, aligned, True

    def _broadcast_and_align(
        self,
        other: ConstantLike,
        fill_value: FillValueLike,
        join: JoinOptions | None,
        op_kind: str = "add",
    ) -> tuple[DataArray, DataArray, bool]:
        """
        Broadcast a constant operand, enforce §5 on its NaN, and align it.

        The scalar check is not covered by the array check below: an expression
        with an empty dimension has no position for a NaN scalar to show up in.
        """
        if is_nan_scalar(other):
            check_user_nan(op_kind=op_kind)
        da = broadcast_to_coords(
            other, coords=self.coords, strict=False, warn_reorder=True
        )
        if da.isnull().any():
            check_user_nan(op_kind=op_kind)
        return self._align_constant(da, fill_value=fill_value, join=join)

    def _reindexed_to(self, const: DataArray, needs_data_reindex: bool) -> Self:
        """Reindex the terms onto ``const`` when the join moved labels."""
        if not needs_data_reindex:
            return self
        data = self.data.reindex_like(const, fill_value=self._fill_value)
        return self.__class__(data, self.model)

    def _combined_with_constant(
        self,
        self_const: DataArray,
        operand: Any,
        op: Callable[[Any, Any], Any],
        *,
        needs_data_reindex: bool,
        scale: bool,
    ) -> Self:
        """
        Combine the aligned constant ``operand`` into ``const`` with ``op``,
        and into the coefficients too if ``scale``.
        """
        expr = self._reindexed_to(self_const, needs_data_reindex)
        const = op(self_const, operand)
        if not scale:
            return expr.assign(const=const)
        return expr.assign(coeffs=op(expr.coeffs, operand), const=const)

    def _add_constant(
        self,
        other: ConstantLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self:
        fill_value = 0 if fill_value is None else fill_value
        if is_v1():
            return self._add_constant_v1(other, join, fill_value)
        return self._add_constant_legacy(other, join, fill_value)

    def _add_constant_v1(
        self,
        other: ConstantLike,
        join: JoinOptions | None,
        fill_value: FillValueLike = 0,
    ) -> Self:
        if np.isscalar(other) and join is None:
            if is_nan_scalar(other):
                check_user_nan()
            return self._combined_with_constant(
                self.const, other, operator.add, needs_data_reindex=False, scale=False
            )
        self_const, da, needs_reindex = self._broadcast_and_align(
            other, fill_value, join
        )
        expr = self._combined_with_constant(
            self_const, da, operator.add, needs_data_reindex=needs_reindex, scale=False
        )
        return expr._absorb_join_absence(fill_value)

    # LEGACY: remove at 1.0 — see doc/design/legacy-removal.rst.
    def _add_constant_legacy(
        self,
        other: ConstantLike,
        join: JoinOptions | None,
        fill_value: FillValueLike = 0,
    ) -> Self:
        if np.isscalar(other) and join is None:
            if is_nan_scalar(other):
                check_user_nan()
            warn_legacy_absence(self.const)
            return self._combined_with_constant(
                self.const.fillna(0),
                other,
                operator.add,
                needs_data_reindex=False,
                scale=False,
            )
        self_const, da, needs_reindex = self._broadcast_and_align(
            other, fill_value, join
        )
        warn_legacy_absence(self_const)
        expr = self._reindexed_to(self_const, needs_reindex)
        return expr.assign(const=self_const.fillna(0) + da.fillna(0))

    def _apply_constant_op(
        self,
        other: ConstantLike,
        op: Callable[[DataArray, DataArray], DataArray],
        nan_fill: float,
        factor_fill: FillValueLike,
        op_kind: str,
        join: JoinOptions | None = None,
    ) -> Self:
        """
        Apply a constant operation (mul, div) to this expression.

        ``factor_fill`` is what the factor takes at join-created positions;
        ``nan_fill`` is legacy's silent fill for a NaN the factor carried in.
        """
        if is_v1():
            return self._apply_constant_op_v1(other, op, factor_fill, op_kind, join)
        return self._apply_constant_op_legacy(
            other, op, nan_fill, factor_fill, op_kind, join
        )

    def _apply_constant_op_v1(
        self,
        other: ConstantLike,
        op: Callable[[DataArray, DataArray], DataArray],
        fill_value: FillValueLike,
        op_kind: str,
        join: JoinOptions | None,
    ) -> Self:
        self_const, factor, needs_reindex = self._broadcast_and_align(
            other, fill_value, join, op_kind
        )
        expr = self._combined_with_constant(
            self_const, factor, op, needs_data_reindex=needs_reindex, scale=True
        )
        return expr._absorb_join_absence(fill_value)

    # LEGACY: remove at 1.0 — see doc/design/legacy-removal.rst.
    def _apply_constant_op_legacy(
        self,
        other: ConstantLike,
        op: Callable[[DataArray, DataArray], DataArray],
        nan_fill: float,
        factor_fill: FillValueLike,
        op_kind: str,
        join: JoinOptions | None,
    ) -> Self:
        self_const, factor, needs_reindex = self._broadcast_and_align(
            other, factor_fill, join, op_kind
        )
        warn_legacy_absence(self_const)
        factor = factor.fillna(nan_fill)
        self_const = self_const.fillna(0)
        expr = self._reindexed_to(self_const, needs_reindex)
        return expr.assign(
            coeffs=op(expr.coeffs.fillna(0), factor), const=op(self_const, factor)
        )

    def _multiply_by_constant(
        self,
        other: ConstantLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self:
        return self._apply_constant_op(
            other,
            operator.mul,
            nan_fill=0,
            factor_fill=0 if fill_value is None else fill_value,
            op_kind="mul",
            join=join,
        )

    def _divide_by_constant(
        self,
        other: ConstantLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self:
        if fill_value is None and is_v1():
            fill_value = np.inf
        elif fill_value is None:  # LEGACY: remove at 1.0
            if join in ("left", "outer") and not _labels_within(
                self.const, as_dataarray(other)
            ):
                warn_legacy(_legacy_join_divisor_fill_message())
            fill_value = 1
        return self._apply_constant_op(
            other,
            operator.truediv,
            nan_fill=1,
            factor_fill=fill_value,
            op_kind="div",
            join=join,
        )

    def __div__(self, other: SideLike) -> Self:
        other = as_constant(other)
        try:
            if isinstance(other, SUPPORTED_EXPRESSION_TYPES):
                raise TypeError(
                    "unsupported operand type(s) for /: "
                    f"{type(self)} and {type(other)}"
                    "Non-linear expressions are not yet supported."
                )
            return self._divide_by_constant(other)
        except TypeError:
            return NotImplemented

    def __truediv__(self, other: SideLike) -> Self:
        return self.__div__(other)

    def __le__(self, rhs: SideLike) -> ConstraintBase:
        return self.to_constraint(LESS_EQUAL, rhs)

    def __ge__(self, rhs: SideLike) -> ConstraintBase:
        return self.to_constraint(GREATER_EQUAL, rhs)

    def __eq__(self, rhs: SideLike) -> ConstraintBase:  # type: ignore[override]
        return self.to_constraint(EQUAL, rhs)

    def __gt__(self, other: Any) -> NotImplementedType:
        raise NotImplementedError(
            "Inequalities only ever defined for >= rather than >."
        )

    def __lt__(self, other: Any) -> NotImplementedType:
        raise NotImplementedError(
            "Inequalities only ever defined for >= rather than >."
        )

    def add(
        self,
        other: SideLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self | QuadraticExpression:
        """
        Add an expression to others.

        Parameters
        ----------
        other : expression-like
            The expression to add.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        fill_value : float or ABSENT, optional
            Value the constant operand takes at the positions the join creates.
            Defaults to 0, the additive identity. ``linopy.ABSENT`` keeps those
            positions absent instead of filling them, for a constant or an
            expression ``other`` alike. Requires an explicit ``join``.
        """
        check_join_fill_value(fill_value, join)
        if join is None:
            return self.__add__(other)
        if isinstance(other, CONSTANT_TYPES):
            return self._add_constant(other, join=join, fill_value=fill_value)
        if fill_value is not None and not isinstance(fill_value, AbsentType):
            raise ValueError(
                "A numeric fill_value= applies to constant operands only. An "
                "expression that is missing at a label contributes the zero "
                "expression, or nothing at all with fill_value=linopy.ABSENT."
            )
        other = as_expression(other, model=self.model, dims=self.coord_dims)
        if isinstance(other, LinearExpression) and isinstance(
            self, QuadraticExpression
        ):
            other = other.to_quadexpr()
        return merge(
            [self, other], cls=self.__class__, join=join, fill_value=fill_value
        )

    def sub(
        self,
        other: SideLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self | QuadraticExpression:
        """
        Subtract others from expression.

        Parameters
        ----------
        other : expression-like
            The expression to subtract.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        fill_value : float or ABSENT, optional
            Value the subtrahend takes at the positions the join creates.
            Defaults to 0; ``linopy.ABSENT`` keeps them absent, for a constant
            or an expression ``other`` alike. Requires an explicit ``join``.
        """
        return self.add(
            -other, join=join, fill_value=None if fill_value is None else -fill_value
        )

    def mul(
        self,
        other: SideLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self | QuadraticExpression:
        """
        Multiply the expr by a factor.

        Parameters
        ----------
        other : expression-like
            The factor to multiply by.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        fill_value : float or ABSENT, optional
            Value the factor takes at the positions the join creates. Defaults
            to 0, so a term without a factor evaluates to zero;
            ``linopy.ABSENT`` keeps them absent instead. Requires an explicit
            ``join``.
        """
        check_join_fill_value(fill_value, join)
        if join is None:
            return self.__mul__(other)
        if isinstance(other, SUPPORTED_EXPRESSION_TYPES):
            raise TypeError(
                "join parameter is not supported for expression-expression multiplication"
            )
        return self._multiply_by_constant(other, join=join, fill_value=fill_value)

    def div(
        self,
        other: VariableLike | ConstantLike,
        join: JoinOptions | None = None,
        fill_value: FillValueLike = None,
    ) -> Self | QuadraticExpression:
        """
        Divide the expr by a factor.

        Parameters
        ----------
        other : constant-like
            The divisor.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        fill_value : float or ABSENT, optional
            Value the divisor takes at the positions the join creates. By
            default that term evaluates to zero; pass ``1`` to keep it
            unscaled, or ``linopy.ABSENT`` to keep it absent. Requires an
            explicit ``join``.
        """
        check_join_fill_value(fill_value, join)
        if join is None:
            return self.__div__(other)
        if isinstance(other, SUPPORTED_EXPRESSION_TYPES):
            raise TypeError(
                "unsupported operand type(s) for /: "
                f"{type(self)} and {type(other)}. "
                "Non-linear expressions are not yet supported."
            )
        return self._divide_by_constant(other, join=join, fill_value=fill_value)

    def le(
        self,
        rhs: SideLike,
        join: JoinOptions | None = None,
    ) -> ConstraintBase:
        """
        Less than or equal constraint.

        Parameters
        ----------
        rhs : expression-like
            Right-hand side of the constraint.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        """
        return self.to_constraint(LESS_EQUAL, rhs, join=join)

    def ge(
        self,
        rhs: SideLike,
        join: JoinOptions | None = None,
    ) -> ConstraintBase:
        """
        Greater than or equal constraint.

        Parameters
        ----------
        rhs : expression-like
            Right-hand side of the constraint.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        """
        return self.to_constraint(GREATER_EQUAL, rhs, join=join)

    def eq(
        self,
        rhs: SideLike,
        join: JoinOptions | None = None,
    ) -> ConstraintBase:
        """
        Equality constraint.

        Parameters
        ----------
        rhs : expression-like
            Right-hand side of the constraint.
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.
        """
        return self.to_constraint(EQUAL, rhs, join=join)

    def pow(self, other: int) -> QuadraticExpression:
        """
        Power of the expression with a coefficient.
        """
        return self.__pow__(other)

    def dot(self, other: SideLike) -> Self | QuadraticExpression:
        """
        Matrix multiplication with other, similar to xarray dot.

        Identical to ``@``. For a :class:`LinearExpression` that includes the
        sparse contraction under v1; :class:`QuadraticExpression` always takes
        the dense path. The result is CSR-backed for a sparse model
        (``Model(sparse=True)``) or a CSR-backed input.
        """
        return self.__matmul__(other)

    def __getitem__(self, selector: int | tuple[slice, list[int]] | slice) -> Self:
        """
        Get selection from the expression.
        This is a wrapper around the xarray __getitem__ method. It returns a
        new LinearExpression object with the selected data.
        """
        data = Dataset({k: self.data[k][selector] for k in self.data}, attrs=self.attrs)
        return self.__class__(data, self.model)

    @property
    def attrs(self) -> dict[Any, Any]:
        """
        Get the attributes of the expression
        """
        return self.data.attrs

    @property
    def coords(self) -> DatasetCoordinates:
        """
        Get the coordinates of the expression
        """
        return self.data.coords

    @property
    def indexes(self) -> Indexes:
        """
        Get the indexes of the expression
        """
        return self.data.indexes

    @property
    def sizes(self) -> Frozen:
        """
        Get the sizes of the expression
        """
        return self.data.sizes

    @property
    def ndim(self) -> int:
        """
        Get the number of dimensions.
        """
        return self.const.ndim

    @property
    def loc(self) -> LocIndexer:
        return LocIndexer(self)

    @property
    def type(self) -> str:
        return "LinearExpression"

    @property
    def name(self) -> str:
        """
        Return the name of the variable.
        """
        return str(self.attrs["name"])

    @property
    def data(self) -> Dataset:
        return self._data

    @property
    def model(self) -> Model:
        return self._model

    @property
    def dims(self) -> tuple[Hashable, ...]:
        # do explicitly sort as in vars (same as in coeffs)
        return self.vars.dims

    @property
    def coord_dims(self) -> tuple[Hashable, ...]:
        return tuple(k for k in self.dims if k not in HELPER_DIMS)

    @property
    def coord_sizes(self) -> dict[Hashable, int]:
        return {k: self.sizes[k] for k in self.coord_dims}

    @property
    def coord_names(self) -> list[str]:
        return get_dims_with_index_levels(self.coords.to_dataset(), self.coord_dims)

    @property
    def vars(self) -> DataArray:
        """Variable labels referenced by each term of the expression."""
        return self.data.vars

    @vars.setter
    def vars(self, value: DataArray) -> None:
        self._data = assign_multiindex_safe(self.data, vars=value)

    @property
    def coeffs(self) -> DataArray:
        """Coefficient applied to each term of the expression."""
        return self.data.coeffs

    @coeffs.setter
    def coeffs(self, value: DataArray) -> None:
        self._data = assign_multiindex_safe(self.data, coeffs=value)

    @property
    def const(self) -> DataArray:
        """Constant offset added to the expression."""
        return self.data.const

    @const.setter
    def const(self, value: DataArray) -> None:
        self._data = assign_multiindex_safe(self.data, const=value)

    def _assign_coords(self, **coords: Any) -> Self:
        """
        Reassign coordinate values on the expression, keeping the shape.

        Internal: values-only replacement of existing dimension coordinates,
        used by :meth:`linopy.Model.assign_coords`. No relabeling, no
        reindexing, no shape change, and the order of the underlying data is
        preserved.
        """
        self._data = assign_coords_multiindex_safe(self.data, **coords)
        return self

    @property
    def has_constant(self) -> DataArray:
        return self.const.any()

    # create a dummy for a mask, which can be implemented later
    @property
    def mask(self) -> None:
        return None

    @has_optimized_model
    def _label_solution(self, labels: np.ndarray) -> np.ndarray:
        """
        Solution values indexed by variable label, with a trailing NaN that
        label ``-1`` reads.

        Raises if ``labels`` reference variables missing from the model.
        """
        m = self.model
        known = np.append(m.variables.label_index.label_to_pos != -1, True)
        if not known[labels].all():
            raise KeyError("Expression references variables missing from the model.")
        sol = np.full(m._xCounter + 1, np.nan)
        for var in m.variables.data.values():
            sol[var.labels.values] = var.solution.values
        sol[-1] = np.nan
        return sol

    def _map_solution(self) -> DataArray:
        """
        Replace variable labels by solution values.
        """
        labels = self.vars
        values = self._label_solution(labels.values)[labels.values]
        return xr.DataArray(values, dims=labels.dims, coords=labels.coords)

    @property
    def solution(self) -> DataArray:
        """
        Get the optimal values of the expression.

        The function raises an error in case no model is set as a
        reference or the model is not optimized.
        """
        vals = self._map_solution()
        sol = (self.coeffs * vals).sum(TERM_DIM) + self.const
        return sol.rename("solution")

    def sum(
        self,
        dim: DimsLike | None = None,
        drop_zeros: bool = False,
        **kwargs: Any,
    ) -> Self:
        """
        Sum the expression over all or a subset of dimensions.

        This stack all terms of the dimensions, that are summed over, together.

        Parameters
        ----------
        dim : str/list, optional
            Dimension(s) to sum over. The default is None which results in all
            dimensions.
        dims : str/list, optional
            Deprecated. Use ``dim`` instead.

        Returns
        -------
        linopy.LinearExpression
            Summed expression.
        """
        if dim is None and "dims" in kwargs:
            dim = kwargs.pop("dims")
            warn(
                "The `dims` argument in `.sum` is deprecated. Use `dim` instead.",
                DeprecationWarning,
            )
        if kwargs:
            raise ValueError(f"Unknown keyword argument(s): {kwargs}")

        res = self.__class__(self._sum(self, dim=dim), self.model)

        if drop_zeros:
            res = res.densify_terms()

        return res

    def cumsum(
        self,
        dim: DimsLike | None = None,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        **kwargs: Any,
    ) -> LinearExpression:
        """
        Cumulated sum along a given axis.

        Docstring and arguments are borrowed from `xarray.Dataset.cumsum`

        Parameters
        ----------
        dim : str, Iterable of Hashable, "..." or None, default: None
            Name of dimension[s] along which to apply ``cumsum``. For e.g. ``dim="x"``
            or ``dim=["x", "y"]``. If "..." or None, will reduce over all dimensions.
        skipna : bool or None, optional
            If True, skip missing values (as marked by NaN). By default, only
            skips missing values for float dtypes; other dtypes either do not
            have a sentinel missing value (int) or ``skipna=True`` has not been
            implemented (object, datetime64 or timedelta64).
        keep_attrs : bool or None, optional
            If True, ``attrs`` will be copied from the original
            object to the new one.  If False, the new object will be
            returned without attributes.
        **kwargs : Any
            Additional keyword arguments passed on to the appropriate array
            function for calculating ``cumsum`` on this object's data.
            These could include dask-specific kwargs like ``split_every``.

        Returns
        -------
        linopy.expression.LinearExpression
        """
        # Along every dimensions, we want to perform cumsum along, get the size of the
        # dimension to pass that to self.rolling.
        if not dim:
            # If user did not specify a dimension to sum over, use all relevant
            # dimensions
            dim = self.coord_dims
        if isinstance(dim, str):
            dim = [dim]
        elif isinstance(dim, EllipsisType) or dim is None:
            dim = self.coord_dims
        dim_dict = {dim_name: self.data.sizes[dim_name] for dim_name in dim}
        return self.rolling(dim=dim_dict).sum(keep_attrs=keep_attrs, skipna=skipna)

    def to_constraint(
        self, sign: SignLike, rhs: SideLike, join: JoinOptions | None = None
    ) -> ConstraintBase:
        """
        Convert a linear expression to a constraint.

        Parameters
        ----------
        sign : str, array-like
            Sign(s) of the constraints.
        rhs : constant, Variable, LinearExpression
            Right-hand side of the constraint. If a DataArray, it is
            reindexed to match expression coordinates (fill_value=np.nan).
            Extra dimensions in the RHS not present in the expression
            raise a ValueError. NaN entries in the RHS mean "no constraint".
        join : str, optional
            How to align coordinates. One of "outer", "inner", "left",
            "right", "exact", "override". When None (default), follows
            ``linopy.options["semantics"]``: v1 requires identical labels in
            identical order on shared dims, legacy aligns positionally.

        Returns
        -------
        Constraint with strict separation of the linear expressions of variables
        which are moved to the left-hand-side and constant values which are moved
        to the right-hand side.

        Notes
        -----
        Under v1 the RHS is a user-supplied constant like any other operand: its
        NaN raises (§5) and ``sub`` does the §8 alignment, rather than a silent
        ``reindex_like``-pad that would mask a coordinate mismatch. An absent
        slot propagated into the RHS reads as "no constraint at this row" (§12).
        Legacy instead keeps a NaN RHS as that auto-mask, restoring the mask
        after the subtraction filled it with 0.
        """
        rhs = as_constant(rhs)
        if self.is_constant and is_constant(rhs):
            raise ValueError(
                f"Both sides of the constraint are constant. At least one side must contain variables. {self} {rhs}"
            )

        rhs_nan_mask = None
        if is_v1():
            if isinstance(rhs, CONSTANT_TYPES):
                rhs = self._broadcast_rhs(rhs)
                if rhs.isnull().any():
                    check_user_nan()
        elif isinstance(rhs, CONSTANT_TYPES):  # LEGACY: remove at 1.0
            rhs = self._broadcast_rhs(rhs)
            self._warn_legacy_rhs_alignment(rhs, join)
            rhs_nan = rhs.isnull()
            if bool(rhs_nan.any()):
                warn_legacy(_legacy_nan_rhs_constraint_message())
            rhs_nan_mask = rhs_nan.reindex_like(self.const, fill_value=True)
            rhs = rhs.fillna(0).reindex_like(self.const, fill_value=0)

        all_to_lhs = self.sub(rhs, join=join).data
        computed_rhs = -all_to_lhs.const
        if rhs_nan_mask is not None and rhs_nan_mask.any():
            computed_rhs = xr.where(rhs_nan_mask, np.nan, computed_rhs)
        data = assign_multiindex_safe(
            all_to_lhs[["coeffs", "vars"]], sign=sign, rhs=computed_rhs
        )
        return constraints.Constraint(data, model=self.model)

    # LEGACY: remove at 1.0
    def _warn_legacy_rhs_alignment(
        self, rhs: DataArray, join: JoinOptions | None
    ) -> None:
        """
        Legacy reindexes a constant RHS onto the expression by label, whatever
        ``join``; warn unless the RHS covers every label and ``join`` would not
        add, drop or reorder any.
        """
        mismatch = first_mismatched_dim(self.const, rhs)
        if mismatch is None:
            return
        alignment = (
            "by label onto the expression, no constraint where the RHS lacks a label"
        )
        if join is None:
            warn_legacy(
                _legacy_coord_mismatch_message(
                    "constraint RHS", *mismatch, alignment=alignment
                )
            )
            return
        covered = join in ("left", "inner", "outer") and _labels_within(self.const, rhs)
        if covered and (join != "outer" or _labels_within(rhs, self.const)):
            return
        warn_legacy(
            _legacy_coord_mismatch_message(
                "constraint RHS",
                *mismatch,
                alignment=f"{alignment}, ignoring `join={join!r}`",
                v1=f"Under v1 `join={join!r}` is applied instead.",
            )
        )

    def _broadcast_rhs(self, rhs: ConstantLike) -> DataArray:
        """Broadcast a constant RHS onto the expression's coordinates."""
        rhs = broadcast_to_coords(
            rhs, coords=self.coords, strict=False, warn_reorder=True
        )
        extra_dims = set(rhs.dims) - set(self.coord_dims)
        if extra_dims:
            logger.warning(
                f"Constant RHS contains dimensions {extra_dims} not present "
                f"in the expression, which might lead to inefficiencies. "
                f"Consider collapsing the dimensions by taking min/max."
            )
        return rhs

    def reset_const(self) -> Self:
        """
        Reset the constant of the linear expression to zero.
        """
        return self.__class__(self.data[["coeffs", "vars"]], self.model)

    def isnull(self) -> DataArray:
        """
        Get a boolean mask reporting which slots are absent.

        Under v1 (§3) a slot is absent iff ``const`` is NaN — every operator
        propagates const NaN from an absent operand, so this is the universal
        signal. A term with ``vars == -1`` is a *dead term* (contributes
        nothing), not a slot-level absence: ``fillna(value)`` revives an absent
        slot to a present constant while leaving the sentinel term in place.
        Legacy has no absence concept (``const`` is always filled with 0), so
        its historical "all vars sentinel and const NaN" is kept verbatim.
        """
        if is_v1():
            return self.const.isnull()
        # LEGACY: remove at 1.0 — see doc/design/legacy-removal.rst.
        helper_dims = set(self.vars.dims).intersection(HELPER_DIMS)
        return (self.vars == -1).all(helper_dims) & self.const.isnull()

    def where(
        self,
        cond: DataArray | Callable[[Any], DataArray],
        other: LinearExpression
        | int
        | float
        | DataArray
        | dict[str, float | int | DataArray]
        | None = None,
        **kwargs: Any,
    ) -> Self:
        """
        Filter variables based on a condition.

        This operation call ``xarray.Dataset.where`` but sets the default
        fill value to -1 for variables and ensures preserving the linopy.LinearExpression type.

        Parameters
        ----------
        cond : DataArray or callable
            Locations at which to preserve this object's values. dtype must be `bool`.
            If a callable, it must expect this object as its only parameter.
        other : expression-like, DataArray or scalar, optional
            Data to use in place of values where cond is False.
            If a DataArray or a scalar is provided, it is only used to fill
            the missing values of constant values (`const`).
            If a DataArray, its coordinates must match this object's.
        **kwargs :
            Keyword arguments passed to ``xarray.Dataset.where``

        Returns
        -------
        linopy.LinearExpression or linopy.QuadraticExpression
        """
        # Cannot set `other` if drop=True
        _other: dict[str, float] | dict[str, int | float | DataArray] | DataArray | None
        if other is None or other is np.nan:
            if not kwargs.get("drop", False):
                _other = FILL_VALUE
            else:
                _other = None
        elif isinstance(other, int | float | DataArray):
            _other = {**self._fill_value, "const": other}
        else:
            _other = _expr_unwrap(other)
        cond = _expr_unwrap(cond)
        if isinstance(cond, DataArray):
            if helper_dims := set(HELPER_DIMS).intersection(cond.dims):
                raise ValueError(
                    f"Filtering by a DataArray with a helper dimension(s) ({helper_dims!r}) is not supported."
                )
        return self.__class__(self.data.where(cond, other=_other, **kwargs), self.model)

    def fillna(
        self,
        value: int
        | float
        | DataArray
        | Dataset
        | LinearExpression
        | dict[str, float | int | DataArray],
    ) -> Self:
        """
        Fill missing values with a given value.

        This method fills missing values in the data with a given value. It calls the `fillna` method of the underlying
        `xarray.Dataset` object, but sets the default fill value to -1 for variables and ensures that the output is of
        type `linopy.LinearExpression`.

        Parameters
        ----------
        value : scalar or array_like
            Value(s) to use to fill missing values. If a scalar is provided, it will be used to fill all missing values as a constant.
            If an array-like object is provided, it should have the same shape as the data and will be used to fill missing values element-wise as a constant.

        Returns
        -------
        linopy.LinearExpression or linopy.QuadraticExpression
            A new object with missing values filled with the given value.

        Notes
        -----
        This fills ``NaN`` entries only. Under legacy semantics an absent slot
        of a variable is already materialised as ``const = 0`` by the time it
        reaches an expression, so there is no ``NaN`` here to fill and the value
        is a no-op (under v1 absence is carried as ``NaN`` and is filled). To
        resolve a variable's absent slots to a constant on both conventions, use
        :meth:`Variable.fillna` (or resolve on the variable before
        ``to_linexpr``), which still holds the absence labels.
        """
        value = _expr_unwrap(value)
        if isinstance(value, DataArray | np.floating | np.integer | int | float):
            value = {"const": value}
        return self.__class__(self.data.fillna(value), self.model)

    def diff(self, dim: str, n: int = 1) -> Self:
        """
        Calculate the n-th order discrete difference along given axis.

        This operation call ``xarray.Dataset.diff`` but ensures preserving the
        linopy.LinearExpression type.

        Parameters
        ----------
        dim : str
            Dimension over which to calculate the finite difference.
        n : int, optional
            The number of times values are differenced.

        Returns
        -------
        linopy.LinearExpression or linopy.QuadraticExpression
        """
        return self - self.shift({dim: n})

    def groupby(
        self,
        group: DataFrame | Series | DataArray,
        restore_coord_dims: bool | None = None,
        **kwargs: Any,
    ) -> LinearExpressionGroupby:
        """
        Returns a LinearExpressionGroupBy object for performing grouped
        operations.

        Docstring and arguments are borrowed from `xarray.Dataset.groupby`

        Parameters
        ----------
        group : str, DataArray or IndexVariable
            Array whose unique values should be used to group this array. If a
            string, must be the name of a variable contained in this dataset.
        restore_coord_dims : bool, optional
            If True, also restore the dimension order of multi-dimensional
            coordinates.

        Returns
        -------
        grouped
            A `LinearExpressionGroupBy` containing the xarray groups and ensuring
            the correct return type.
        """
        kwargs = dict(restore_coord_dims=restore_coord_dims, **kwargs)
        return LinearExpressionGroupby(self, group, model=self.model, kwargs=kwargs)

    def rolling(
        self,
        dim: Mapping[Any, int] | None = None,
        min_periods: int | None = None,
        center: bool | Mapping[Any, bool] = False,
        **window_kwargs: int,
    ) -> LinearExpressionRolling:
        """
        Rolling window object.

        Docstring and arguments are borrowed from `xarray.Dataset.rolling`

        Parameters
        ----------
        dim : dict, optional
            Mapping from the dimension name to create the rolling iterator
            along (e.g. `time`) to its moving window size.
        min_periods : int, default: None
            Minimum number of observations in window required to have a value
            (otherwise result is NA). The default, None, is equivalent to
            setting min_periods equal to the size of the window.
        center : bool or mapping, default: False
            Set the labels at the center of the window.
        **window_kwargs : optional
            The keyword arguments form of ``dim``.
            One of dim or window_kwargs must be provided.

        Returns
        -------
        linopy.expression.LinearExpressionRolling
        """
        ds = self.data
        rolling = ds.rolling(
            dim=dim, min_periods=min_periods, center=center, **window_kwargs
        )
        return LinearExpressionRolling(rolling, model=self.model)

    @property
    def nterm(self) -> int:
        """
        Get the number of terms in the linear expression.
        """
        return len(self.data._term)

    @property
    def has_terms(self) -> DataArray:
        """
        Get a boolean array which is true at slots with at least one live term.

        A term is live when it references a variable (``vars != -1``). Slots
        without any live term arise from outer joins in
        :func:`merge <linopy.expressions.merge>`, from reindexing past the
        original coordinates, or from masking. In contrast to
        :meth:`isnull`, the constant is ignored: a slot carrying only a
        constant has no terms.

        Returns
        -------
        xr.DataArray

        Examples
        --------
        Mask out constraint rows whose left-hand side has no terms:

        >>> import linopy
        >>> import pandas as pd
        >>> m = linopy.Model()
        >>> x = m.add_variables(coords=[pd.RangeIndex(3, name="i")], name="x")
        >>> lhs = (1 * x).reindex(i=pd.RangeIndex(5, name="i"))
        >>> lhs.has_terms.values
        array([ True,  True,  True, False, False])
        """
        helper_dims = set(self.vars.dims).intersection(HELPER_DIMS)
        return (self.vars != -1).any(helper_dims).rename("has_terms")

    @property
    def variable_names(self) -> set[str]:
        """
        Get the names of the unique variables present in the expression.
        """
        if self.nterm == 0:
            return set()

        # Collect all unique labels from the expression (excluding -1)
        all_labels = self.vars.values.ravel()
        unique_labels = np.unique(all_labels[all_labels != -1])

        if len(unique_labels) == 0:
            return set()

        # Batch lookup variable names for all labels
        positions = self.model.variables.get_label_position(unique_labels)

        return {p[0] for p in positions if p[0] is not None}

    @property
    def shape(self) -> tuple[int, ...]:
        """
        Get the total shape of the linear expression.
        """
        assert self.vars.shape == self.coeffs.shape
        return self.vars.shape

    @property
    def size(self) -> int:
        """
        Get the total size of the linear expression.
        """
        return self.vars.size

    @property
    def empty(self) -> EmptyDeprecationWrapper:
        """
        Get whether the linear expression is empty.

        .. versionchanged:: 0.5.1
           Returns a EmptyDeprecationWrapper which behaves like a bool and emits
           a DeprecationWarning when called.
        """
        return EmptyDeprecationWrapper(not self.size)

    def densify_terms(self) -> Self:
        """
        Move all non-zero term entries to the front and cut off all-zero
        entries in the term-axis.
        """
        coeffs = self.data.coeffs.transpose(..., TERM_DIM)
        vars = self.data.vars.transpose(*coeffs.dims, ...)
        cdata = coeffs.data
        mask = cdata != 0
        if mask.all():
            return self

        lead = cdata.shape[:-1]
        old_nterm = cdata.shape[-1]
        trailing = vars.shape[cdata.ndim :]
        mask = mask.reshape(-1, old_nterm)
        nrows = mask.shape[0]
        counts = mask.sum(1)
        nterm = int(counts.max()) if nrows else 0
        rows = np.repeat(np.arange(nrows), counts)
        pos = np.arange(rows.size) - np.repeat(np.cumsum(counts) - counts, counts)

        new_coeffs = np.zeros((nrows, nterm), dtype=cdata.dtype)
        new_coeffs[rows, pos] = cdata.reshape(nrows, old_nterm)[mask]
        new_vars = np.full((nrows, nterm, *trailing), -1, dtype=vars.dtype)
        new_vars[rows, pos] = vars.data.reshape(nrows, old_nterm, *trailing)[mask]

        new: dict[Hashable, Any] = {
            "coeffs": (coeffs.dims, new_coeffs.reshape(*lead, nterm)),
            "vars": (vars.dims, new_vars.reshape(*lead, nterm, *trailing)),
        }
        data_vars = {k: new.get(k, self.data[k]) for k in self.data.data_vars}
        data = Dataset(data_vars, coords=self.data.coords, attrs=self.data.attrs)
        return self.__class__(data, self.model)

    def sanitize(self) -> Self:
        """
        Sanitize LinearExpression by ensuring int dtype for variables.

        Returns
        -------
        linopy.LinearExpression
        """
        if not np.issubdtype(self.vars.dtype, np.integer):
            return self.assign(
                vars=self.vars.fillna(-1).astype(self.model._dtypes["labels"])
            )

        return self

    def equals(self, other: BaseExpression) -> bool:
        return self.data.equals(_expr_unwrap(other))

    def __iter__(self) -> Iterator[Hashable]:
        return self.data.__iter__()

    @classmethod
    def _sum(
        cls,
        expr: BaseExpression | Dataset,
        dim: DimsLike | None = None,
    ) -> Dataset:
        data = _expr_unwrap(expr)
        if cls is QuadraticExpression:
            dim = dim or list(set(data.dims) - set(HELPER_DIMS))

        if isinstance(dim, str):
            dim = [dim]
        elif isinstance(dim, EllipsisType):
            dim = None

        if dim is None:
            vars = DataArray(data.vars.data.ravel(), dims=TERM_DIM)
            coeffs = DataArray(data.coeffs.data.ravel(), dims=TERM_DIM)
            const = data.const.sum()
            ds = xr.Dataset({"vars": vars, "coeffs": coeffs, "const": const})
        else:
            dim = [d for d in dim if d != TERM_DIM]
            ds = _drop_coords_on_dims(data[["coeffs", "vars"]], dim).rename(
                {TERM_DIM: STACKED_TERM_DIM}
            )
            ds = _stack_into_term_dim(ds, [STACKED_TERM_DIM] + dim)
            ds = assign_multiindex_safe(ds, const=data.const.sum(dim))

        return ds

    # Wrapped function which would convert variable to dataarray
    assign = exprwrap(assign_multiindex_safe)

    assign_multiindex_safe = exprwrap(assign_multiindex_safe)

    assign_attrs = exprwrap(Dataset.assign_attrs)

    assign_coords = exprwrap(Dataset.assign_coords)

    astype = exprwrap(Dataset.astype)

    bfill = exprwrap(Dataset.bfill)

    broadcast_like = exprwrap(Dataset.broadcast_like)

    chunk = exprwrap(Dataset.chunk)

    drop = exprwrap(Dataset.drop)

    drop_vars = exprwrap(Dataset.drop_vars)

    drop_sel = exprwrap(Dataset.drop_sel)

    drop_isel = exprwrap(Dataset.drop_isel)

    expand_dims = exprwrap(Dataset.expand_dims)

    ffill = exprwrap(Dataset.ffill)

    sel = exprwrap(Dataset.sel)

    isel = exprwrap(Dataset.isel)

    shift = exprwrap(Dataset.shift)

    swap_dims = exprwrap(Dataset.swap_dims)

    set_index = exprwrap(Dataset.set_index)

    reindex = exprwrap(Dataset.reindex, fill_value=_fill_value)

    reindex_like = exprwrap(Dataset.reindex_like, fill_value=_fill_value)

    rename = exprwrap(Dataset.rename)

    reset_index = exprwrap(Dataset.reset_index)

    rename_dims = exprwrap(Dataset.rename_dims)

    roll = exprwrap(Dataset.roll)

    stack = exprwrap(Dataset.stack)

    unstack = exprwrap(Dataset.unstack)

    iterate_slices = iterate_slices


GenericExpression = TypeVar("GenericExpression", bound=BaseExpression)


class LinearExpression(BaseExpression):
    """
    A linear expression consisting of terms of coefficients and variables.

    The LinearExpression class is a subclass of xarray.Dataset which allows to
    apply most xarray functions on it. However most arithmetic operations are
    overwritten. Like this you can easily expand and modify the linear
    expression.

    Examples
    --------
    >>> from linopy import Model
    >>> import pandas as pd
    >>> m = Model()
    >>> x = m.add_variables(pd.Series([0, 0]), 1, name="x")
    >>> y = m.add_variables(4, pd.Series([8, 10]), name="y")

    Combining expressions:

    >>> expr = 3 * x
    >>> type(expr)
    <class 'linopy.expressions.LinearExpression'>

    >>> other = 4 * y
    >>> type(expr + other)
    <class 'linopy.expressions.LinearExpression'>

    Multiplying:

    >>> type(3 * expr)
    <class 'linopy.expressions.LinearExpression'>

    Summation over dimensions

    >>> type(expr.sum(dim="dim_0"))
    <class 'linopy.expressions.LinearExpression'>
    """

    __slots__ = ("_csr",)

    def __init__(self, data: Dataset | Any | None, model: Model) -> None:
        super().__init__(data, model)
        self._csr: CSRLinearExpression | None = None

    @classmethod
    def _from_csr(cls, csr: CSRLinearExpression, model: Model) -> Self:
        """Construct an expression backed by a CSRLinearExpression."""
        obj = cls.__new__(cls)
        obj._model = model
        obj._data = None  # type: ignore[assignment]
        obj._csr = csr
        return obj

    @property
    def data(self) -> Dataset:
        self._densify("`.data` read, e.g. by an operation without a sparse path")
        return self._data

    def _densify(self, reason: str) -> None:
        """Convert the CSR backing to dense for good, with a notice naming ``reason``."""
        _densify_all([self], reason)

    @property
    def is_sparse(self) -> bool:
        """
        Whether the expression is backed by a sparse CSR matrix
        (:mod:`linopy.csr`) instead of a dense Dataset. Reading ``.data``, or
        an operation without a sparse path, converts it to dense for good.
        """
        return self._csr is not None

    @property
    def coord_dims(self) -> tuple[Hashable, ...]:
        if self._csr is not None:
            return self._csr.grid.dims
        return super().coord_dims

    @property
    def dims(self) -> tuple[Hashable, ...]:
        if self._csr is not None:
            return (*self._csr.grid.dims, TERM_DIM)
        return super().dims

    @property
    def shape(self) -> tuple[int, ...]:
        if self._csr is not None:
            return (*self._csr.grid.shape, self._csr.nterm)
        return super().shape

    @property
    def size(self) -> int:
        if self._csr is not None:
            return int(np.prod(self.shape, dtype=np.int64))
        return super().size

    @property
    def sizes(self) -> Frozen:
        if self._csr is not None:
            return Frozen(dict(zip(self.dims, self.shape)))
        return super().sizes

    @property
    def coords(self) -> DatasetCoordinates:
        if self._csr is not None:
            return self._csr.grid.to_dataset().coords
        return super().coords

    @property
    def indexes(self) -> Indexes:
        if self._csr is not None:
            return self._csr.grid.to_dataset().indexes
        return super().indexes

    @property
    def const(self) -> DataArray:
        csr = self._csr
        if csr is None:
            return super().const
        return csr.grid.dataarray(csr.const, name="const")

    @const.setter
    def const(self, value: DataArray) -> None:
        self._data = assign_multiindex_safe(self.data, const=value)

    @property
    def has_terms(self) -> DataArray:
        """Check live variable terms directly from sparse rows."""
        csr = self._csr
        if csr is None:
            return super().has_terms
        present = ~np.isnan(csr.const)
        return csr.grid.dataarray(
            present & (np.diff(csr.csr.indptr) > 0), name="has_terms"
        )

    @property
    def solution(self) -> DataArray:
        """
        Get the optimal values of the expression.

        The function raises an error in case no model is set as a
        reference or the model is not optimized.
        """
        csr = self._csr
        if csr is None:
            return super().solution
        sol = self._label_solution(csr.csr.indices)[: csr.csr.shape[1]]
        sol = np.nan_to_num(sol)
        return csr.grid.dataarray(csr.csr @ sol + csr.const, name="solution")

    def _combined_with_constant(
        self,
        self_const: DataArray,
        operand: Any,
        op: Callable[[Any, Any], Any],
        *,
        needs_data_reindex: bool,
        scale: bool,
    ) -> Self:
        csr = self._csr
        flags = {"needs_data_reindex": needs_data_reindex, "scale": scale}
        if csr is None:
            return super()._combined_with_constant(self_const, operand, op, **flags)
        dims = csr.grid.dims
        const = op(self_const, operand)
        if set(const.dims) != set(dims) or _has_multiindex(const.indexes.values()):
            self._densify(
                "elementwise operation with a constant over new dimensions or "
                "MultiIndex labels"
            )
            return super()._combined_with_constant(self_const, operand, op, **flags)
        const = const.transpose(*dims)
        grid = Grid.from_dataset(const, dims)
        if needs_data_reindex:
            csr = csr.reindexed(grid)
        if scale:
            factor = operand.broadcast_like(const).transpose(*dims)
            csr = csr.scaled(factor.to_numpy().reshape(-1), op)
        csr = replace(csr.with_const(const.to_numpy().reshape(-1)), grid=grid)
        return type(self)._from_csr(csr, self._model)

    def _absorb_join_absence(self, fill_value: FillValueLike) -> Self:
        if self._csr is not None:
            return self
        return super()._absorb_join_absence(fill_value)

    def _printout_cell(
        self, indices: tuple[Any, ...]
    ) -> tuple[np.ndarray, np.ndarray, Any]:
        if self._csr is not None:
            return self._csr.cell(indices)
        return super()._printout_cell(indices)

    def _selected(
        self, select: Callable[[DataArray], DataArray], name: str
    ) -> CSRLinearExpression | None:
        """
        Apply the dense selection ``select`` to the grid's row numbers and
        gather the selected rows, a row number of ``-1`` or NaN leaving the
        cell absent. None, after a densify notice, where the selection leaves
        the grid: new or unlabelled dimensions, MultiIndex labels, or
        coordinates that are no auxiliary coordinates of the grid.
        """
        csr = self._csr
        if csr is None:
            return None
        reason = f"`{name}` over MultiIndex labels, or introducing dimensions"
        if _has_multiindex(csr.grid.indexes.values()):
            self._densify(reason)
            return None
        rows = select(csr.grid.dataarray(np.arange(csr.n_cells)))
        dims = tuple(str(d) for d in rows.dims)
        leaves_grid = not set(dims) <= set(csr.grid.dims) & set(rows.indexes)
        if leaves_grid or _has_multiindex(rows.indexes.values()):
            self._densify(reason)
            return None
        grid = Grid.from_dataset(rows, dims)
        if set(rows.coords) != set(dims) | set(grid.aux):
            self._densify(reason)
            return None
        flat = rows.fillna(-1).to_numpy().reshape(-1).astype(np.int64)
        return csr.taken(flat, grid)

    def _gathered(
        self, name: str, dense: Callable[..., Self], /, *args: Any, **kwargs: Any
    ) -> Self:
        """
        Apply the dense method ``name`` to the grid's row numbers via
        :meth:`_selected`, falling back to ``dense`` off the grid.
        """
        csr = self._selected(operator.methodcaller(name, *args, **kwargs), name)
        if csr is None:
            return dense(*args, **kwargs)
        return type(self)._from_csr(csr, self._model)

    def sel(self, *args: Any, **kwargs: Any) -> Self:
        """
        Select by label as ``Dataset.sel``. For a CSR-backed expression,
        returns a CSR-backed result when the selection stays on the grid.
        """
        return self._gathered("sel", super().sel, *args, **kwargs)

    def isel(self, *args: Any, **kwargs: Any) -> Self:
        """
        Select by position as ``Dataset.isel``. For a CSR-backed expression,
        returns a CSR-backed result when the selection stays on the grid.
        """
        return self._gathered("isel", super().isel, *args, **kwargs)

    def __getitem__(self, selector: int | tuple[slice, list[int]] | slice) -> Self:
        return self._gathered("__getitem__", super().__getitem__, selector)

    def shift(self, *args: Any, **kwargs: Any) -> Self:
        """
        Shift along dimensions as ``Dataset.shift``. For a CSR-backed
        expression, returns a CSR-backed result with the shifted-in cells
        absent, unless a ``fill_value`` is passed.
        """
        if len(args) > 1 or "fill_value" in kwargs:
            self._densify("`shift` with a fill_value")
        return self._gathered("shift", super().shift, *args, **kwargs)

    def roll(self, *args: Any, **kwargs: Any) -> Self:
        """
        Roll along dimensions as ``Dataset.roll``. For a CSR-backed
        expression, returns a CSR-backed result.
        """
        return self._gathered("roll", super().roll, *args, **kwargs)

    def where(
        self,
        cond: DataArray | Callable[[Any], DataArray],
        other: LinearExpression
        | int
        | float
        | DataArray
        | dict[str, float | int | DataArray]
        | None = None,
        **kwargs: Any,
    ) -> Self:
        cond_da = _expr_unwrap(cond)
        drop = kwargs.get("drop", False)
        absent = other is None or other is np.nan
        supported = (
            isinstance(cond_da, DataArray)
            and set(kwargs) <= {"drop"}
            and (absent or (isinstance(other, int | float) and not drop))
        )
        if not supported:
            self._densify(
                "`where` with a condition that is no DataArray, an `other` that "
                "is no scalar, or extra arguments"
            )
            return super().where(cond, other, **kwargs)
        csr = self._selected(
            lambda rows: (
                rows.where(cond_da, drop=True) if drop else rows.where(cond_da, -1)
            ),
            "where",
        )
        if csr is None:
            return super().where(cond, other, **kwargs)
        if not absent:
            const = self.const.where(cond_da, other).transpose(*csr.grid.dims)
            csr = csr.with_const(const.to_numpy().reshape(-1))
        return type(self)._from_csr(csr, self._model)

    def sum(
        self,
        dim: DimsLike | None = None,
        drop_zeros: bool = False,
        **kwargs: Any,
    ) -> Self:
        csr = self._csr
        if csr is None or kwargs:
            return super().sum(dim, drop_zeros, **kwargs)
        if dim is None or isinstance(dim, EllipsisType):
            dims: list[Hashable] = list(csr.grid.dims)
        else:
            dims = [dim] if isinstance(dim, str) else list(dim)
        summed = [str(d) for d in dims if d != TERM_DIM]
        if not set(summed) <= set(csr.grid.dims):
            return super().sum(dim, drop_zeros)
        res = csr.summed(summed) if summed else csr
        return type(self)._from_csr(res.pruned() if drop_zeros else res, self._model)

    @property
    def nterm(self) -> int:
        """
        Get the number of terms in the linear expression.
        """
        if self._csr is not None:
            return self._csr.nterm
        return super().nterm

    def __neg__(self) -> Self:
        """
        Get the negative of the expression.
        """
        if self._csr is not None:
            return self._from_csr(self._csr.scaled(-1.0), self._model)
        return super().__neg__()

    def fillna(
        self,
        value: int
        | float
        | DataArray
        | Dataset
        | LinearExpression
        | dict[str, float | int | DataArray],
    ) -> Self:
        csr = self._csr
        unwrapped = _expr_unwrap(value)
        if (
            csr is not None
            and isinstance(unwrapped, np.floating | np.integer | int | float)
            and not isinstance(unwrapped, bool)
        ):
            return type(self)._from_csr(csr.filled(float(unwrapped)), self._model)
        return super().fillna(value)

    def to_constraint(
        self, sign: SignLike, rhs: SideLike, join: JoinOptions | None = None
    ) -> ConstraintBase:
        if self._csr is not None and isinstance(sign, str):
            rhs = as_constant(rhs)
            if join is not None or not isinstance(rhs, CONSTANT_TYPES):
                return self.sub(rhs, join=join).to_constraint(sign, 0)
            rhs_da = constraints.csr_rhs(self._csr, rhs)
            if isinstance(rhs_da, DataArray):
                return constraints.CSRConstraint.from_csr(self._csr, sign, rhs_da)
            self._densify(rhs_da)
        return super().to_constraint(sign, rhs, join)

    @overload
    def __add__(
        self,
        other: ConstantLike | VariableLike | ScalarLinearExpression | LinearExpression,
    ) -> LinearExpression: ...

    @overload
    def __add__(self, other: QuadraticExpression) -> QuadraticExpression: ...

    def __add__(
        self,
        other: ConstantLike
        | VariableLike
        | ScalarLinearExpression
        | LinearExpression
        | QuadraticExpression,
    ) -> LinearExpression | QuadraticExpression:
        """
        Add an expression to others.

        Note: If other is a numpy array or pandas object without axes names,
        dimension names of self will be filled in other
        """
        other = as_constant(other)
        if isinstance(other, QuadraticExpression):
            return other.__add__(self)

        try:
            if isinstance(other, CONSTANT_TYPES):
                return self._add_constant(other)
            else:
                other = as_expression(other, model=self.model, dims=self.coord_dims)
                return merge([self, other], cls=self.__class__)
        except TypeError:
            return NotImplemented

    def __radd__(self, other: ConstantLike) -> LinearExpression:
        try:
            return self + other
        except TypeError:
            return NotImplemented

    @overload
    def __sub__(
        self,
        other: ConstantLike | VariableLike | ScalarLinearExpression | LinearExpression,
    ) -> LinearExpression: ...

    @overload
    def __sub__(self, other: QuadraticExpression) -> QuadraticExpression: ...

    def __sub__(
        self,
        other: ConstantLike
        | VariableLike
        | ScalarLinearExpression
        | LinearExpression
        | QuadraticExpression,
    ) -> LinearExpression | QuadraticExpression:
        other = as_constant(other)
        try:
            return self.__add__(-other)
        except TypeError:
            return NotImplemented

    def __rsub__(self, other: ConstantLike | Variable) -> LinearExpression:
        try:
            return (self * -1) + other
        except TypeError:
            return NotImplemented

    @overload
    def __mul__(self, other: ConstantLike) -> LinearExpression: ...

    @overload
    def __mul__(self, other: VariableLike | ExpressionLike) -> QuadraticExpression: ...

    def __mul__(
        self,
        other: SideLike,
    ) -> LinearExpression | QuadraticExpression:
        """
        Multiply the expr by a factor.
        """
        if (
            self._csr is not None
            and isinstance(other, int | float | np.number)
            and not is_nan_scalar(other)
        ):
            return type(self)._from_csr(self._csr.scaled(float(other)), self._model)
        other = as_constant(other)
        if isinstance(other, QuadraticExpression):
            return other.__rmul__(self)

        try:
            if isinstance(other, variables.Variable | variables.ScalarVariable):
                other = other.to_linexpr()

            if isinstance(other, LinearExpression | ScalarLinearExpression):
                return self._multiply_by_linear_expression(other)
            else:
                return self._multiply_by_constant(other)
        except TypeError:
            return NotImplemented

    def __pow__(self, other: int) -> QuadraticExpression:
        """
        Power of the expression with a coefficient. The only coefficient allowed is 2.
        """
        if not other == 2:
            raise ValueError("Power must be 2.")
        return self * self  # type: ignore

    def __rmul__(self, other: ConstantLike) -> LinearExpression:
        """
        Right-multiply the expr by a factor.
        """
        try:
            return self * other
        except TypeError:
            return NotImplemented

    @overload
    def __matmul__(self, other: ConstantLike) -> LinearExpression: ...

    @overload
    def __matmul__(
        self, other: VariableLike | ExpressionLike
    ) -> QuadraticExpression: ...

    def __matmul__(
        self, other: ConstantLike | VariableLike | ExpressionLike
    ) -> LinearExpression | QuadraticExpression:
        """
        Matrix multiplication with other, similar to xarray dot.

        Under v1, a constant ``other`` is contracted as one sparse matrix
        product (:meth:`_sparse_matmul`) instead of the dense broadcast
        ``(self * other).sum(dim)``. The result is then the compact canonical
        form -- duplicate variables summed, terms label-ordered, explicit
        zeros pruned -- so its term count may differ from the dense path's
        while the values agree. Returns a CSR-backed result when ``self`` is
        CSR-backed or the model is sparse.
        """
        self.model._check_sparse_semantics()
        other = as_constant(other)
        other_is_const = not isinstance(other, LinearExpression | variables.Variable)
        if other_is_const and is_v1() and type(self) is LinearExpression:
            sparse = self._sparse_matmul(other)
            if sparse is not None:
                return sparse
        if other_is_const:
            other = _matmul_operand_to_dataarray(other, self.coords, self.coord_dims)

        common_dims = list(set(self.coord_dims).intersection(other.dims))
        res = (self * other).sum(dim=common_dims)
        if other_is_const and common_dims and bool((other == 0).any()):
            res = res.densify_terms()
        return res

    def _sparse_matmul(self, other: ConstantLike) -> LinearExpression | None:
        """
        Contract against a constant as one sparse matrix product, skipping the
        dense broadcast intermediate of ``(self * other).sum(dim)``.

        Returns None where the dense path owns the semantics: a MultiIndex on
        the expression or on the operand, non-unique or MultiIndex grid
        labels, a zero-size grid, an operand sharing no dimension with the
        grid, and an unlabelled output dimension. The result is the compact
        canonical form of :meth:`CSRLinearExpression.contracted`, so its term
        count may differ from the dense path's while the values agree; the
        result is CSR-backed when the input was or the model is sparse.
        """
        if is_nan_scalar(other):
            check_user_nan(op_kind="mul")
        if self._csr is None and _has_multiindex(self.data.indexes.values()):
            return None
        if not self.coord_dims:
            self._densify("`@` on a zero-dimensional expression")
            return None
        csr = self._csr or CSRLinearExpression.from_dense(self.data, self.model)
        if not csr.grid.is_unique or _has_multiindex(csr.grid.indexes.values()):
            self._densify("`@` over non-unique or MultiIndex labels")
            return None
        if csr.grid.size == 0:
            self._densify("`@` over a zero-size grid")
            return None
        coords = csr.grid.to_dataset().coords
        da = _matmul_operand_to_dataarray(other, coords, csr.grid.dims)
        if _has_multiindex(da.indexes.values()):
            self._densify("`@` with a MultiIndex operand")
            return None
        contracted = [d for d in csr.grid.dims if d in da.dims]
        new_dims = [str(d) for d in da.dims if d not in csr.grid.dims]
        if not contracted or any(d not in da.indexes for d in new_dims):
            self._densify(
                "`@` with an operand sharing no dimension or with an unlabelled one"
            )
            return None
        matrix = _matmul_operand_to_matrix(
            da, contracted, new_dims, csr.grid.indexes, csr.grid.aux
        )
        new_indexes = [da.indexes[d].rename(d) for d in new_dims]
        res = csr.contracted(matrix, contracted, new_indexes)
        if self._csr is not None or self.model.sparse:
            return type(self)._from_csr(res, self.model)
        return res.to_dense()

    @property
    def flat(self) -> pd.DataFrame:
        """
        Convert the expression to a pandas DataFrame.

        The resulting DataFrame represents a long table format of the all
        expressions with non-zero coefficients. It contains the
        columns `coeffs` and `vars`.

        Returns
        -------
        df : pandas.DataFrame
        """
        if self._csr is not None:
            df = pd.DataFrame(self._csr_terms(self._csr))
        else:

            def mask_func(data: dict) -> pd.Series:
                mask = (data["vars"] != -1) & (data["coeffs"] != 0)
                return mask

            df = to_dataframe(self.data, mask_func=mask_func)
        df = df.groupby("vars", as_index=False).sum()
        check_has_nulls(df, name=self.type)
        return df

    def reindex(
        self,
        indexers: Mapping[Any, Any] | None = None,
        *,
        method: str | None = None,
        tolerance: Any = None,
        copy: bool = True,
        fill_value: Any = FILL_VALUE,
        **indexers_kwargs: Any,
    ) -> LinearExpression:
        """
        Conform to new coordinates as ``Dataset.reindex``. For a CSR-backed
        expression, returns a CSR-backed result when only grid labels change
        and no other keyword argument is given.
        """
        indexers = either_dict_or_kwargs(indexers, indexers_kwargs, "reindex")
        csr = self._csr
        if (
            csr is not None
            and set(indexers) <= set(csr.grid.dims)
            and method is None
            and tolerance is None
            and copy
            and fill_value is self._fill_value
        ):
            grid = csr.grid.with_indexes(indexers)
            return type(self)._from_csr(csr.reindexed(grid), self._model)
        return super().reindex(
            indexers,
            method=method,
            tolerance=tolerance,
            copy=copy,
            fill_value=fill_value,
        )

    def rename(
        self,
        name_dict: Mapping[Any, Any] | None = None,
        **names: Any,
    ) -> LinearExpression:
        """
        Rename dimensions as ``Dataset.rename``. For a CSR-backed expression,
        returns a CSR-backed result when only grid dims are relabelled.
        """
        name_dict = either_dict_or_kwargs(name_dict, names, "rename")
        csr = self._csr
        if csr is not None and set(name_dict) <= set(csr.grid.dims):
            relabel = {str(k): str(v) for k, v in name_dict.items()}
            return type(self)._from_csr(csr.renamed(relabel), self._model)
        return super().rename(name_dict)

    def drop_vars(
        self,
        names: str | Iterable[Hashable] | Callable[[Dataset], str | Iterable[Hashable]],
        *,
        errors: Literal["raise", "ignore"] = "raise",
    ) -> Self:
        """Drop auxiliary coordinates without materializing sparse terms."""
        csr = self._csr
        if csr is None or callable(names):
            return super().drop_vars(names, errors=errors)
        names = [names] if isinstance(names, str) else list(names)
        if set(names) & (set(csr.grid.dims) | {"coeffs", "vars", "const"}):
            return super().drop_vars(names, errors=errors)
        coords = csr.grid.to_dataset().drop_vars(names, errors=errors)
        grid = Grid.from_dataset(coords, csr.grid.dims)
        return type(self)._from_csr(replace(csr, grid=grid), self._model)

    def to_quadexpr(self) -> QuadraticExpression:
        """Convert LinearExpression to QuadraticExpression."""
        vars = self.data.vars.expand_dims(FACTOR_DIM)
        fill_value = self._fill_value["vars"]
        vars = xr.concat([vars, xr.full_like(vars, fill_value)], dim=FACTOR_DIM)
        data = self.data.assign(vars=vars)
        return QuadraticExpression(data, self.model)

    def to_polars(self) -> pl.DataFrame:
        """
        Convert the expression to a polars DataFrame.

        The resulting DataFrame represents a long table format of the all
        non-masked expressions with non-zero coefficients. It contains the
        columns `coeffs`, `vars`, `const`. The coeffs and vars columns will be null if the expression is constant.

        Returns
        -------
        df : polars.DataFrame
        """
        if self._csr is not None:
            df = pl.DataFrame(self._csr_terms(self._csr))
        elif self.is_constant:
            df = pl.DataFrame(
                {"const": self.data["const"].values.reshape(-1)}
            ).with_columns(pl.lit(None).alias("coeffs"), pl.lit(None).alias("vars"))
            return df.select(["vars", "coeffs", "const"])
        else:
            df = filter_nulls_polars(to_polars(self.data))
        df = maybe_group_terms_polars(df)
        check_has_nulls_polars(df, name=self.type)
        return df

    def _csr_terms(self, csr: CSRLinearExpression) -> dict[str, np.ndarray]:
        """
        Stored terms of a CSR backing as ``const``, ``coeffs`` and ``vars``
        columns, dropping absent cells and zero coefficients like the dense
        long format.
        """
        keep = csr.live_terms()
        const = np.repeat(csr.const, np.diff(csr.csr.indptr))
        return {
            "const": const[keep],
            "coeffs": csr.csr.data[keep].astype(float),
            "vars": csr.csr.indices[keep].astype(self.model._dtypes["labels"]),
        }

    def linear_terms(self) -> tuple[np.ndarray, np.ndarray]:
        """
        Variable labels and coefficients of the stored terms. For a CSR-backed
        expression, reads the CSR arrays directly; otherwise reads the dense
        term arrays. Absent terms and zero coefficients are dropped, duplicate
        labels are not summed.
        """
        if self._csr is not None:
            csr = self._csr.csr
            keep = self._csr.live_terms()
            if keep.all():
                return csr.indices, csr.data
            return csr.indices[keep], csr.data[keep]
        labels = self.data.vars.values.ravel()
        coeffs = self.data.coeffs.values.ravel()
        keep = (labels != -1) & (coeffs != 0)
        return labels[keep], coeffs[keep]

    def simplify(self) -> LinearExpression:
        """
        Simplify the linear expression by combining terms with the same variable.

        This method finds all terms that reference the same variable and adds
        their coefficients together, reducing the number of terms in the expression.

        Returns
        -------
        LinearExpression
            A new LinearExpression with combined terms.

        Examples
        --------
        >>> from linopy import Model
        >>> m = Model()
        >>> x = m.add_variables(name="x")
        >>> expr = 2 * x + 3 * x  # Creates two terms
        >>> simplified = expr.simplify()  # Combines into one term: 5 * x
        """

        def _simplify_row(vars_row: np.ndarray, coeffs_row: np.ndarray) -> np.ndarray:
            """
            For a given combination of expression coordinates, try to simplify by reducing duplicate variables
            """
            input_len = len(vars_row)

            # Filter out invalid entries
            mask = (vars_row != -1) & (coeffs_row != 0) & ~np.isnan(coeffs_row)
            valid_vars = vars_row[mask]
            valid_coeffs = coeffs_row[mask]

            if len(valid_vars) == 0:
                # Return arrays filled with -1 and 0.0, same length as input
                return np.vstack(
                    [
                        np.full(input_len, -1, dtype=float),
                        np.zeros(input_len, dtype=float),
                    ]
                )

            # Use bincount to sum coefficients for each variable ID efficiently
            max_var = int(valid_vars.max())
            summed = np.bincount(
                valid_vars, weights=valid_coeffs, minlength=max_var + 1
            )

            # Get non-zero entries
            unique_vars = np.where(summed != 0)[0]
            unique_coeffs = summed[unique_vars]

            # Pad to match input length
            result_vars = np.full(input_len, -1, dtype=float)
            result_coeffs = np.zeros(input_len, dtype=float)

            n_unique = len(unique_vars)
            result_vars[:n_unique] = unique_vars
            result_coeffs[:n_unique] = unique_coeffs

            return np.vstack([result_vars, result_coeffs])

        # Coeffs and vars have dimensions (.., TERM_DIM) where .. are the coordinate dimensions of the expression
        # An operation is applied over the coordinate dimensions on both coeffs and vars, which are stacked together over a new "CV_DIM" dimension
        combined: xr.DataArray = xr.apply_ufunc(
            _simplify_row,
            self.vars,
            self.coeffs,
            input_core_dims=[[TERM_DIM], [TERM_DIM]],
            output_core_dims=[[CV_DIM, TERM_DIM]],
            vectorize=True,
        )
        # Combined has dimensions (.., CV_DIM, TERM_DIM)

        # Drop terms where all vars are -1 (i.e., empty terms across all coordinates)
        vars = combined.isel({CV_DIM: 0}).astype(self.model._dtypes["labels"])
        non_empty_terms = (vars != -1).any(dim=[d for d in vars.dims if d != TERM_DIM])
        combined = combined.isel({TERM_DIM: non_empty_terms})

        # Extract vars and coeffs from the combined result
        vars = combined.isel({CV_DIM: 0}).astype(self.model._dtypes["labels"])
        coeffs = combined.isel({CV_DIM: 1})

        # Create new dataset with simplified data
        new_data = self.data.copy()
        new_data = assign_multiindex_safe(new_data, vars=vars, coeffs=coeffs)

        return LinearExpression(new_data, self.model)

    @classmethod
    def _from_scalarexpression_list(
        cls,
        exprs: list[ScalarLinearExpression],
        coords: Mapping,
        model: Model,
    ) -> LinearExpression:
        """
        Create a LinearExpression from a list of lists with different lengths.
        """
        shape = list(map(len, coords.values()))

        coeffs = array(tuple(zip_longest(*(e.coeffs for e in exprs), fillvalue=nan)))
        vars = array(tuple(zip_longest(*(e.vars for e in exprs), fillvalue=-1)))

        nterm = vars.shape[0]
        coeffs = coeffs.reshape((nterm, *shape))
        vars = vars.reshape((nterm, *shape))

        coeffdata = DataArray(coeffs, coords, dims=(TERM_DIM, *coords))
        vardata = DataArray(vars, coords, dims=(TERM_DIM, *coords))
        ds = Dataset({"coeffs": coeffdata, "vars": vardata}).transpose(..., TERM_DIM)

        return cls(ds, model)

    @classmethod
    def from_rule(
        cls,
        model: Model,
        rule: Callable,
        coords: Sequence[Sequence | pd.Index] | Mapping | None = None,
    ) -> LinearExpression:
        """
        Create a linear expression from a rule and a set of coordinates.

        This functionality mirrors the assignment of linear expression as done by
        Pyomo.


        Parameters
        ----------
        model : linopy.Model
            Passed to function `rule` as a first argument.
        rule : callable
            Function to be called for each combinations in `coords`.
            The first argument of the function is the underlying `linopy.Model`.
            The following arguments are given by the coordinates for accessing
            the variables. The function has to return a
            `ScalarLinearExpression`. Therefore use the `.at` accessor when
            indexing variables.
        coords : coordinate-like
            Coordinates to processed by `xarray.DataArray`.
            For each combination of coordinates, the function
            given by `rule` is called. The order and size of coords has
            to be same as the argument list followed by `model` in
            function `rule`.


        Returns
        -------
        linopy.LinearExpression

        Examples
        --------
        >>> from linopy import Model, LinearExpression
        >>> m = Model()
        >>> coords = pd.RangeIndex(10), ["a", "b"]
        >>> x = m.add_variables(0, 100, coords)
        >>> def bound(m, i, j):
        ...     if i % 2:
        ...         return (i - 1) * x.at[i - 1, j]
        ...     else:
        ...         return i * x.at[i, j]
        ...
        >>> expr = LinearExpression.from_rule(m, bound, coords)
        >>> con = m.add_constraints(expr <= 10)
        """
        if not isinstance(coords, DataArrayCoordinates):
            coords = DataArray(coords=coords).coords

        # test output type
        output = rule(model, *[c.values[0] for c in coords.values()])
        if not isinstance(output, ScalarLinearExpression) and output is not None:
            msg = f"`rule` has to return ScalarLinearExpression not {type(output)}."
            raise TypeError(msg)

        combinations = product(*[c.values for c in coords.values()])

        placeholder = ScalarLinearExpression((np.nan,), (-1,), model)
        exprs = [rule(model, *coord) or placeholder for coord in combinations]
        return cls._from_scalarexpression_list(exprs, coords, model)

    @classmethod
    def from_tuples(
        cls,
        *tuples: tuple[ConstantLike, str | Variable | ScalarVariable] | ConstantLike,
        model: Model | None = None,
    ) -> LinearExpression:
        """
        Create a linear expression by using tuples of coefficients and
        variables.

        The function internally checks that all variables in the tuples belong to the same
        reference model.

        Parameters
        ----------
        tuples : A list of elements. Each element is either:
            * (coefficients, variables)
            * constant

            Each (coefficients, variables) tuple represents one term in the resulting linear expression,
            which can possibly span over multiple dimensions:

            * coefficients : int/float/array_like
                The coefficient(s) in the term, if the coefficients array
                contains dimensions which do not appear in
                the variables, the variables are broadcasted.
            * variables : str/array_like/linopy.Variable
                The variable(s) going into the term. These may be referenced
                by name.
            * constant: int/float/array_like
                The constant value to add to the expression
        model : The linopy.Model. If None this can be inferred from the provided variables

        Returns
        -------
        linopy.LinearExpression

        Examples
        --------
        >>> from linopy import Model
        >>> import pandas as pd
        >>> m = Model()
        >>> x = m.add_variables(pd.Series([0, 0]), 1)
        >>> y = m.add_variables(4, pd.Series([8, 10]))
        >>> expr = LinearExpression.from_tuples((10, x), (1, y), 1)

        This is the same as calling ``10*x + y`` + 1 but a bit more performant.
        """

        def process_one(
            t: tuple[ConstantLike, str | Variable | ScalarVariable]
            | tuple[ConstantLike]
            | ConstantLike,
        ) -> LinearExpression:
            nonlocal model

            if isinstance(t, CONSTANT_TYPES):
                if model is None:
                    raise ValueError("Model must be provided when using constants.")
                expr = LinearExpression(t, model)
                return expr

            if not isinstance(t, tuple):
                raise ValueError("Expected tuple or constant.")

            if len(t) == 2:
                # assume first element is coefficient and second is variable
                c, v = t
                if isinstance(v, variables.ScalarVariable):
                    if not isinstance(c, int | float):
                        raise TypeError(
                            "Expected int or float as coefficient of scalar variable (first element of tuple)."
                        )
                    expr = v.to_linexpr(c)
                elif isinstance(v, variables.Variable):
                    if not isinstance(c, CONSTANT_TYPES):
                        raise TypeError(
                            "Expected constant as coefficient of variable (first element of tuple)."
                        )
                    expr = v.to_linexpr(c)
                else:
                    raise TypeError("Expected variable as second element of tuple.")

                if model is None:
                    model = expr.model  # TODO: Ensure equality of models
                return expr

            if len(t) == 1:
                warn(
                    "Passing a single value tuple to LinearExpression.from_tuples is deprecated",
                    DeprecationWarning,
                )
                # assume that the element is a constant
                const = as_dataarray(t[0])
                if model is None:
                    raise ValueError("Model must be provided when using constants.")
                return LinearExpression(const, model)
            else:
                raise ValueError("Expected tuples of length 2")

        exprs = [process_one(t) for t in tuples]

        return merge(exprs, cls=cls) if len(exprs) > 1 else exprs[0]

    @classmethod
    def from_constant(cls, model: Model, constant: ConstantLike) -> LinearExpression:
        """
        Create a linear expression from a constant value or series

        Parameters
        ----------
        model : linopy.Model
            The model to which the constant expression will belong.
        constant : int/float/array_like
            The constant value for the linear expression.

        Returns
        -------
        linopy.LinearExpression
            A linear expression representing the constant value.
        """
        const_da = as_dataarray(constant)
        return LinearExpression(const_da, model)


class QuadraticExpression(BaseExpression):
    """
    A quadratic expression consisting of terms of coefficients and variables.

    The QuadraticExpression class is a subclass of LinearExpression which allows to
    apply most xarray functions on it.
    """

    __slots__ = ("_data", "_model")
    __array_ufunc__ = None
    __array_priority__ = 10000
    __pandas_priority__ = 10000

    _fill_value = {"vars": -1, "coeffs": np.nan, "const": np.nan}

    def __init__(self, data: Dataset | None, model: Model) -> None:
        if data is None:
            da = xr.DataArray([[], []], dims=[FACTOR_DIM, TERM_DIM])
            data = Dataset({"coeffs": da, "vars": da, "const": 0.0})
        super().__init__(data, model)
        data = self._data
        if FACTOR_DIM not in data.vars.dims:
            raise ValueError(f"Data does not include dimension {FACTOR_DIM}")
        elif data.sizes[FACTOR_DIM] != 2:
            raise ValueError(f"Size of dimension {FACTOR_DIM} must be 2.")

        # transpose data to have _term as last dimension and _factor as second last
        data = data.transpose(..., FACTOR_DIM, TERM_DIM)
        self._data = data

    @property
    def type(self) -> str:
        return "QuadraticExpression"

    @property
    def shape(self) -> tuple[int, ...]:
        # TODO Implement this
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support shape property"
        )

    def __mul__(self, other: SideLike) -> QuadraticExpression:
        """
        Multiply the expr by a factor.
        """
        other = as_constant(other)
        if isinstance(other, SUPPORTED_EXPRESSION_TYPES):
            raise TypeError(
                "unsupported operand type(s) for *: "
                f"{type(self)} and {type(other)}. "
                "Higher order non-linear expressions are not yet supported."
            )
        try:
            return self._multiply_by_constant(other)
        except TypeError:
            return NotImplemented

    def __rmul__(self, other: SideLike) -> QuadraticExpression:
        return self * other

    def __add__(self, other: SideLike) -> QuadraticExpression:
        """
        Add an expression to others.

        Note: If other is a numpy array or pandas object without axes names,
        dimension names of self will be filled in other
        """
        other = as_constant(other)
        try:
            if isinstance(other, CONSTANT_TYPES):
                return self._add_constant(other)
            else:
                other = as_expression(other, model=self.model, dims=self.coord_dims)

                if isinstance(other, LinearExpression):
                    other = other.to_quadexpr()

                return merge([self, other], cls=self.__class__)
        except TypeError:
            return NotImplemented

    def __radd__(self, other: ConstantLike) -> QuadraticExpression:
        """
        Add others to expression.
        """
        return self.__add__(other)

    def __sub__(self, other: SideLike) -> QuadraticExpression:
        """
        Subtract others from expression.

        Note: If other is a numpy array or pandas object without axes names,
        dimension names of self will be filled in other
        """
        other = as_constant(other)
        try:
            return self.__add__(-other)
        except TypeError:
            return NotImplemented

    def __rsub__(self, other: SideLike) -> QuadraticExpression:
        """
        Subtract expression from others.
        """
        try:
            return (self * -1) + other
        except TypeError:
            return NotImplemented

    def __pow__(self, other: SideLike) -> QuadraticExpression:
        raise TypeError("Higher order non-linear expressions are not yet supported.")

    def __matmul__(
        self, other: ConstantLike | VariableLike | ExpressionLike
    ) -> QuadraticExpression:
        """
        Matrix multiplication with other, similar to xarray dot.
        """
        other = as_constant(other)
        if isinstance(other, SUPPORTED_EXPRESSION_TYPES):
            raise TypeError(
                "Higher order non-linear expressions are not yet supported."
            )

        other = _matmul_operand_to_dataarray(other, self.coords, self.coord_dims)
        common_dims = list(set(self.coord_dims).intersection(other.dims))
        return (self * other).sum(dim=common_dims)

    @property
    def solution(self) -> DataArray:
        """
        Get the optimal values of the expression.

        The function raises an error in case no model is set as a
        reference or the model is not optimized.
        """
        vals = self._map_solution()
        sol = (self.coeffs * vals.prod(FACTOR_DIM)).sum(TERM_DIM) + self.const
        return sol.rename("solution")

    def to_constraint(
        self, sign: SignLike, rhs: SideLike, join: JoinOptions | None = None
    ) -> NotImplementedType:
        raise NotImplementedError(
            "Quadratic expressions cannot be used in constraints."
        )

    @property
    def flat(self) -> DataFrame:
        """
        Return a flattened expression.
        """
        vars = self.data.vars.assign_coords(
            {FACTOR_DIM: ["vars1", "vars2"]}
        ).to_dataset(FACTOR_DIM)
        ds = self.data.drop_vars("vars").assign(vars)

        def mask_func(data: dict) -> pd.Series:
            mask = ((data["vars1"] != -1) | (data["vars2"] != -1)) & (
                data["coeffs"] != 0
            )
            return mask

        df = to_dataframe(ds, mask_func=mask_func)
        # Group repeated variables in the same constraint
        df = df.groupby(["vars1", "vars2"], as_index=False).sum()
        check_has_nulls(df, name=self.type)
        return df

    def linear_terms(self) -> tuple[np.ndarray, np.ndarray]:
        """
        Variable labels and coefficients of the terms with a single variable;
        zero coefficients are dropped, duplicate labels are not summed.
        """
        coeffs = self.data.coeffs
        factors = self.data.vars.transpose(FACTOR_DIM, *coeffs.dims).values
        vars1, vars2 = factors[0].ravel(), factors[1].ravel()
        labels = np.where(vars1 != -1, vars1, vars2)
        values = coeffs.values.ravel()
        keep = ((vars1 == -1) | (vars2 == -1)) & (labels != -1) & (values != 0)
        return labels[keep], values[keep]

    def to_polars(self, **kwargs: Any) -> pl.DataFrame:
        """
        Convert the expression to a polars DataFrame.

        The resulting DataFrame represents a long table format of the all
        non-masked expressions with non-zero coefficients. It contains the
        columns `vars1`, `vars2`, `coeffs`, `const`. If the expression is constant, the `vars1` and `vars2` and `coeffs` columns will be null.

        Returns
        -------
        df : polars.DataFrame
        """
        if self.is_constant:
            df = pl.DataFrame(
                {"const": self.data["const"].values.reshape(-1)}
            ).with_columns(
                pl.lit(None).alias("coeffs"),
                pl.lit(None).alias("vars1"),
                pl.lit(None).alias("vars2"),
            )
            return df.select(["vars1", "vars2", "coeffs", "const"])

        vars = self.data.vars.assign_coords(
            {FACTOR_DIM: ["vars1", "vars2"]}
        ).to_dataset(FACTOR_DIM)
        ds = self.data.drop_vars("vars").assign(vars)
        df = to_polars(ds, **kwargs)
        df = filter_nulls_polars(df)
        df = group_terms_polars(df)
        check_has_nulls_polars(df, name=self.type)
        return df

    def to_matrix(self) -> scipy.sparse._csc.csc_matrix:
        """
        Return a sparse matrix representation of the expression only including
        quadratic terms.

        Note that the matrix is formulated following the convention of the
        optimization problem, i.e. the quadratic term is 0.5 x^T Q x.
        The matrix Q is therefore symmetric and the diagonal terms are doubled.

        """
        df = self.flat
        # drop linear terms
        df = df[(df.vars1 != -1) & (df.vars2 != -1)]

        # symmetrize cross terms and double diagonal terms
        cross_terms = df.vars1 != df.vars2
        df.loc[~cross_terms, "coeffs"] *= 2
        vals = dict(vars1=df.vars2[cross_terms], vars2=df.vars1[cross_terms])
        df = pd.concat([df, df[cross_terms].assign(**vals)])

        # assign matrix
        data = df.coeffs
        row = df.vars1
        col = df.vars2
        nvars = self.model.shape[1]
        return csc_matrix((data, (row, col)), shape=(nvars, nvars))


def as_expression(
    obj: Any, model: Model, **kwargs: Any
) -> LinearExpression | QuadraticExpression:
    """
    Convert an object to a LinearExpression or QuadraticExpression.

    Parameters
    ----------
    obj : Variable, ScalarVariable, LinearExpression, array_like
        Object to convert to LinearExpression.
    model : linopy.Model, optional
        Assigned model, by default None
    **kwargs :
        Keyword arguments passed to `linopy.alignment.broadcast_to_coords`.

    Returns
    -------
    expr : LinearExpression

    Raises
    ------
    ValueError
        If object cannot be converted to LinearExpression.
    """
    if isinstance(obj, LinearExpression | QuadraticExpression):
        return obj
    elif isinstance(obj, variables.Variable | variables.ScalarVariable):
        return obj.to_linexpr()
    else:
        try:
            obj = broadcast_to_coords(obj, strict=False, **kwargs)
        except ValueError as e:
            raise ValueError(f"Cannot convert to LinearExpression: {e}") from e
        return LinearExpression(obj, model)


def _has_multiindex(indexes: Iterable[pd.Index]) -> bool:
    return any(isinstance(i, pd.MultiIndex) for i in indexes)


def _densify_all(exprs: Iterable[Any], reason: str) -> None:
    """Convert the CSR-backed LinearExpressions among ``exprs`` to dense, with one notice."""
    sparse = [
        (e, csr)
        for e in exprs
        if isinstance(e, LinearExpression) and (csr := e._csr) is not None
    ]
    if sparse:
        _densify_notice(reason, sparse[0][0].model)
    for e, csr in sparse:
        e._data = csr.to_dense()._data
        e._csr = None


def _coord_sizes_agree(objs: Sequence[Any]) -> bool:
    """Whether all ``objs`` carry the same non-helper dimension sizes."""
    sizes = [{k: v for k, v in o.sizes.items() if k not in HELPER_DIMS} for o in objs]
    return check_common_keys_values(sizes)


def _labels_within(a: DataArray, b: DataArray) -> bool:
    """Whether every label of ``a`` on a dim shared with ``b`` is also in ``b``."""
    shared = set(a.indexes) & set(b.indexes)
    return all(a.indexes[d].isin(b.indexes[d]).all() for d in shared)


def _aligned(
    csrs: list[CSRLinearExpression], join: JoinOptions | None, fill: float
) -> list[CSRLinearExpression] | str:
    """
    Conform the CSR expressions to the grid an explicit join produces, the
    cells the join creates carrying ``fill`` as constant. Returns the reason
    as a string where the dense path owns the semantics instead: ``exact``
    and the auto-detected join raise there on differing grids, ``override``
    on differing shapes, any join on non-unique labels.
    """
    template = csrs[0].grid
    dims = template.dims
    if any(not p.grid.is_unique for p in csrs):
        return "merge over non-unique labels"
    if join == "override":
        if any(p.grid.dims != dims or p.grid.shape != template.shape for p in csrs):
            return '`join="override"` merge of differently shaped grids'
        return [replace(p, grid=template) for p in csrs]
    if join in ("left", "right"):
        source = csrs[0] if join == "left" else csrs[-1]
        grid = source.grid.reordered(dims)
    elif join in ("outer", "inner"):
        grid = template.combined([p.grid for p in csrs[1:]], join)
    else:
        return f"merge of differing grids with join={join!r}"
    return [p.reindexed(grid, fill) for p in csrs]


def _concatenated(
    csrs: list[CSRLinearExpression], dim: str, join: JoinOptions | None
) -> CSRLinearExpression | str:
    """
    Stack CSR expressions sharing one dim order along the grid dim ``dim``,
    in order. The result's coordinates are what the dense path's
    ``xr.concat`` yields on the grids alone: labels and auxiliary
    coordinates concatenated along ``dim``, the other dims joined as
    ``join`` says (``outer`` by default, after the v1 label check for the
    auto-detected join), with the cells the join creates absent. Returns the
    reason as a string where the dense path owns the semantics instead: a
    join over non-unique labels.
    """
    dims = csrs[0].grid.dims
    metadata = [p.grid.to_dataset() for p in csrs]
    if join is None:
        enforce_merge_dims(metadata, concat_dim=dim, context=f"merge along dim {dim!r}")
    enforce_aux_conflict(metadata, concat_dim=dim)
    combined = xr.concat(
        metadata, dim, join=join or "outer", coords="minimal", compat="override"
    )
    grid = Grid.from_dataset(combined, dims)
    aligned = []
    for p in csrs:
        target = grid.with_indexes({dim: p.grid.indexes[dim]})
        if join == "override" or p.grid.same_layout(target):
            aligned.append(replace(p, grid=target))
        elif p.grid.is_unique:
            aligned.append(p.reindexed(target))
        else:
            return "merge over non-unique labels"
    return aligned[0].concatenated(aligned[1:], dim, grid)


def _try_csr_merge(
    exprs: Any,
    dim: str,
    join: JoinOptions | None,
    fill_value: FillValueLike,
    kwargs: dict[str, Any],
) -> LinearExpression | None:
    """
    Sparse branch of :func:`merge`: combine plain LinearExpressions over one
    set of grid dimensions (CSR-backed or dense-convertible) as sparse matrix
    addition along the term dimension, or as a row stack along one of the
    grid dimensions (:func:`_concatenated`). Grids that share dims in a
    different order are transposed onto the template order first. Grids that
    differ in their labels are aligned row-wise onto the joined grid, the
    cells the join creates carrying the fill of the dense path (zero, or NaN
    for ``fill_value=ABSENT``). Auxiliary coordinates are checked for
    conflicts on the operands as given and follow their rows onto the joined
    grid. Returns None to fall through to the dense path.
    """
    if not any(type(e) is LinearExpression and e._csr is not None for e in exprs):
        return None
    if kwargs:
        _densify_all(exprs, "merge with extra arguments")
        return None
    if not all(type(e) is LinearExpression for e in exprs):
        _densify_all(exprs, "merge with an operand that is not a LinearExpression")
        return None
    dims = set(exprs[0].coord_dims)
    if any(set(e.coord_dims) != dims for e in exprs[1:]):
        _densify_all(exprs, "merge of operands over different dimensions")
        return None
    if dim != TERM_DIM and dim not in dims:
        _densify_all(exprs, "merge along a new dimension")
        return None
    for e in exprs:
        if e._csr is None and set(e.data.coords) - dims != set(
            _aux_coords(e.data, dims)
        ):
            _densify_all(
                exprs, "merge with a dense operand carrying non-grid coordinates"
            )
            return None

    csrs = [e._csr or CSRLinearExpression.from_dense(e.data, e.model) for e in exprs]
    template = csrs[0]
    order = template.grid.dims
    csrs = [
        p.reindexed(p.grid.reordered(order)) if p.grid.dims != order else p
        for p in csrs
    ]
    if dim != TERM_DIM:
        stacked = _concatenated(csrs, dim, join)
        if isinstance(stacked, str):
            _densify_all(exprs, stacked)
            return None
        return LinearExpression._from_csr(stacked, exprs[0].model)
    if not all(template.same_grid(p) for p in csrs[1:]):
        enforce_aux_conflict([Dataset(coords=p.grid.aux) for p in csrs])
        aligned = _aligned(csrs, join, join_fill(fill_value, 0.0))
        if isinstance(aligned, str):
            _densify_all(exprs, aligned)
            return None
        csrs = aligned

    combined = csrs[0].added(*csrs[1:])
    return LinearExpression._from_csr(combined, exprs[0].model)


Mergeable: TypeAlias = BaseExpression | variables.Variable | Dataset


@overload
def merge(
    exprs: Sequence[Mergeable] | Mergeable,
    *add_exprs: Mergeable,
    dim: str = ...,
    cls: type[GenericExpression],
    join: JoinOptions | None = None,
    fill_value: FillValueLike = None,
    **kwargs: Any,
) -> GenericExpression: ...


@overload
def merge(
    exprs: Sequence[Mergeable] | Mergeable,
    *add_exprs: Mergeable,
    dim: str = ...,
    cls: None = ...,
    join: JoinOptions | None = None,
    fill_value: FillValueLike = None,
    **kwargs: Any,
) -> BaseExpression: ...


def merge(
    exprs: Sequence[Mergeable] | Mergeable,
    *add_exprs: Mergeable,
    dim: str = TERM_DIM,
    cls: type[BaseExpression] | None = None,
    join: JoinOptions | None = None,
    fill_value: FillValueLike = None,
    **kwargs: Any,
) -> BaseExpression:
    """
    Merge multiple expression together.

    This function is a bit faster than summing over multiple linear expressions.
    In case a list of LinearExpression with exactly the same shape is passed
    and the dimension to concatenate on is TERM_DIM, the concatenation uses
    the coordinates of the first object as a basis which overrides the
    coordinates of the consecutive objects.

    Parameters
    ----------
    *exprs : tuple/list
        List of linear expressions to merge.
    dim : str
        Dimension along which the expressions should be concatenated.
    cls : type
        Explicitly set the type of the resulting expression (So that the type checker will know the return type)
    join : str, optional
        How to align coordinates. One of "outer", "inner", "left", "right",
        "exact", "override". When None (default), auto-detects based on
        expression shapes.
    fill_value : ABSENT, optional
        Pass ``linopy.ABSENT`` to leave the positions the join creates absent
        instead of contributing the zero expression there. Requires an
        explicit ``join`` and the v1 semantics.
    **kwargs
        Additional keyword arguments passed to xarray.concat. Defaults to
        {coords: "minimal", compat: "override"} or, in the special case described
        above, to {coords: "minimal", compat: "override", "join": "override"}.

    Returns
    -------
    res : linopy.LinearExpression or linopy.QuadraticExpression

    Notes
    -----
    Under v1 an absent slot of any operand stays absent in the result (§6), so
    the term reduction runs with ``skipna=False`` instead of collapsing NaN to
    the additive (or, for the quadratic build, multiplicative) identity.
    """
    check_join_fill_value(fill_value, join)
    if fill_value is not None and not isinstance(fill_value, AbsentType):
        raise ValueError(
            "merge only accepts fill_value=linopy.ABSENT — an expression that "
            "is missing at a label contributes the zero expression or nothing."
        )
    if isinstance(fill_value, AbsentType) and dim != TERM_DIM:
        raise ValueError(
            f"fill_value=ABSENT is only defined for a merge along {TERM_DIM!r}."
        )
    if not isinstance(exprs, Sequence):
        warn(
            "Passing a tuple to the merge function is deprecated. Please pass a list of objects to be merged",
            DeprecationWarning,
        )
        exprs = [exprs] + list(add_exprs)

    has_quad_expression = any(isinstance(e, QuadraticExpression) for e in exprs)
    has_linear_expression = any(isinstance(e, LinearExpression) for e in exprs)
    if cls is None:
        cls = QuadraticExpression if has_quad_expression else LinearExpression

    if (
        issubclass(cls, QuadraticExpression)
        and dim == TERM_DIM
        and has_linear_expression
    ):
        raise ValueError(
            "Cannot merge linear and quadratic expressions along term dimension."
            "Convert to QuadraticExpression first."
        )

    if has_quad_expression and not issubclass(cls, QuadraticExpression):
        raise ValueError("Cannot merge linear expressions to QuadraticExpression")

    linopy_types = (variables.Variable, BaseExpression)

    model = exprs[0].model

    if issubclass(cls, LinearExpression) and not has_quad_expression:
        csr_result = _try_csr_merge(
            exprs, dim=dim, join=join, fill_value=fill_value, kwargs=kwargs
        )
        if csr_result is not None:
            return csr_result

    data = [e.data if isinstance(e, linopy_types) else e for e in exprs]
    data = [fill_missing_coords(ds, fill_helper_dims=True) for ds in data]

    if join is None:
        enforce_merge_dims(data, concat_dim=dim, context=f"merge along dim {dim!r}")
    enforce_aux_conflict(data, concat_dim=dim)

    if join is not None:
        override = join == "override"
    elif issubclass(cls, linopy_types) and dim in HELPER_DIMS:
        override = _coord_sizes_agree(exprs)
    else:
        override = False

    if not kwargs:
        kwargs = {
            "coords": "minimal",
            "compat": "override",
        }
        if issubclass(cls, LinearExpression):
            kwargs["fill_value"] = FILL_VALUE
        elif issubclass(cls, variables.Variable):
            kwargs["fill_value"] = variables.FILL_VALUE

        if join is not None:
            kwargs["join"] = join
        elif override:
            kwargs["join"] = "override"
        else:
            kwargs.setdefault("join", "outer")

    skipna = not is_v1()
    if dim == TERM_DIM:
        warn_legacy_absence(*(d["const"] for d in data))
        ds = xr.concat([d[["coeffs", "vars"]] for d in data], dim, **kwargs)
        subkwargs = {**kwargs, "fill_value": {"const": join_fill(fill_value, 0)}}
        const = xr.concat([d[["const"]] for d in data], dim, **subkwargs)["const"]
        const = const.sum(TERM_DIM, skipna=skipna)
        ds = assign_multiindex_safe(ds, const=const)
    elif dim == FACTOR_DIM:
        ds = xr.concat([d[["vars"]] for d in data], dim, **kwargs)
        coeffs = xr.concat([d["coeffs"] for d in data], dim, **kwargs).prod(
            FACTOR_DIM, skipna=skipna
        )
        const = xr.concat([d["const"] for d in data], dim, **kwargs).prod(
            FACTOR_DIM, skipna=skipna
        )
        ds = assign_multiindex_safe(ds, coeffs=coeffs, const=const)
    else:
        ds = xr.concat(data, dim, **kwargs)

    for d in set(HELPER_DIMS) & set(ds.coords):
        ds = ds.reset_index(d, drop=True)

    if is_v1():
        ds = absorb_absence(ds)

    return cls(ds, model)


@dataclass(repr=False)
class Expressions:
    """
    An expressions container used for storing multiple expression arrays.
    """

    data: dict[str, LinearExpression | QuadraticExpression]
    model: Model

    dataset_attrs = ["coeffs", "vars", "const"]

    def _formatted_names(self) -> dict[str, str]:
        """
        Get a dictionary of formatted names to the proper variable names.
        This map enables a attribute like accession of variable names which
        are not valid python variable names.
        """
        return {format_string_as_variable_name(n): n for n in self}

    @overload
    def __getitem__(self, names: str) -> LinearExpression | QuadraticExpression: ...

    @overload
    def __getitem__(self, names: list[str]) -> Expressions: ...

    def __getitem__(
        self, names: str | list[str]
    ) -> LinearExpression | QuadraticExpression | Expressions:
        if isinstance(names, str):
            return self.data[names]
        return Expressions({name: self.data[name] for name in names}, self.model)

    def __getattr__(self, name: str) -> LinearExpression | QuadraticExpression:
        # If name is an attribute of self (including methods and properties), return that
        if name in self.data:
            return self.data[name]
        else:
            if name in (formatted_names := self._formatted_names()):
                return self.data[formatted_names[name]]
        raise AttributeError(
            f"Expressions has no attribute `{name}` or the attribute is not accessible / raises an error."
        )

    def __getstate__(self) -> dict:
        return self.__dict__

    def __setstate__(self, d: dict) -> None:
        self.__dict__.update(d)

    def __dir__(self) -> list[str]:
        base_attributes = list(super().__dir__())
        formatted_names = [
            n for n in self._formatted_names() if n not in base_attributes
        ]
        return base_attributes + formatted_names

    def _format_items(self, exclude: set[str] | None = None) -> str:
        """Format expression items, optionally excluding names in a group."""
        r = ""
        count = 0
        for name, ds in self.items():
            if exclude and name in exclude:
                continue
            count += 1
            coords = (
                " (" + ", ".join(str(coord) for coord in ds.coords) + ")"
                if ds.coords
                else ""
            )
            r += f" * {name}{coords}\n"
        if count == 0:
            r += "<empty>\n"
        return r

    def __repr__(self) -> str:
        """
        Return a string representation of the expressions container.
        """
        r = "linopy.model.Expressions"
        line = "-" * len(r)
        r += f"\n{line}\n"
        r += self._format_items()
        return r

    def __len__(self) -> int:
        return self.data.__len__()

    def __iter__(self) -> Iterator[str]:
        return self.data.__iter__()

    def items(self) -> ItemsView[str, LinearExpression | QuadraticExpression]:
        return self.data.items()

    def _ipython_key_completions_(self) -> list[str]:
        """
        Provide method for the key-autocompletions in IPython.

        See
        http://ipython.readthedocs.io/en/stable/config/integrating.html#tab-completion
        For the details.
        """
        return list(self)

    def add(self, expression: LinearExpression | QuadraticExpression) -> None:
        """
        Add an expression to the expressions container.
        """
        self.data[expression.name] = expression

    def remove(self, name: str) -> None:
        """
        Remove variable `name` from the variables.
        """
        self.data.pop(name)

    @property
    def solution(self) -> Dataset:
        """
        Get the solution of variables.
        """
        return save_join(*[v.solution.rename(k) for k, v in self.items()])


class ScalarLinearExpression:
    """
    A scalar linear expression container.

    In contrast to the LinearExpression class, a ScalarLinearExpression
    only contains one label. Use this class to create a constraint
    in a rule.
    """

    __slots__ = ("_coeffs", "_vars", "_model")

    def __init__(
        self,
        coeffs: tuple[int | float, ...],
        vars: tuple[int, ...],
        model: Model,
    ) -> None:
        self._coeffs = coeffs
        self._vars = vars
        self._model = model

    def __repr__(self) -> str:
        expr_string = format_single_expression(
            np.array(self.coeffs), np.array(self.vars), 0, self.model
        )
        return f"ScalarLinearExpression: {expr_string}"

    @property
    def coeffs(
        self,
    ) -> tuple[int | float, ...]:
        return self._coeffs

    @property
    def vars(
        self,
    ) -> tuple[int, ...] | tuple[int, ...]:
        return self._vars

    @property
    def model(self) -> Model:
        return self._model

    def __add__(
        self, other: ScalarLinearExpression | ScalarVariable
    ) -> ScalarLinearExpression:
        if isinstance(other, variables.ScalarVariable):
            coeffs = self.coeffs + (1,)
            vars = self.vars + (other.label,)
            return ScalarLinearExpression(coeffs, vars, self.model)
        elif not isinstance(other, ScalarLinearExpression):
            raise TypeError(
                f"unsupported operand type(s) for +: {type(self)} and {type(other)}"
            )

        coeffs = self.coeffs + other.coeffs
        vars = self.vars + other.vars
        return ScalarLinearExpression(coeffs, vars, self.model)

    def __radd__(
        self, other: int | float
    ) -> ScalarLinearExpression | NotImplementedType:
        # This is needed for using python's sum function
        if other == 0:
            return self
        return NotImplemented

    @property
    def nterm(self) -> int:
        return len(self.vars)

    def __sub__(
        self, other: ScalarVariable | ScalarLinearExpression
    ) -> ScalarLinearExpression:
        if isinstance(other, variables.ScalarVariable):
            other = other.to_scalar_linexpr(1)
        elif not isinstance(other, ScalarLinearExpression):
            raise TypeError(
                f"unsupported operand type(s) for -: {type(self)} and {type(other)}"
            )

        return ScalarLinearExpression(
            self.coeffs + tuple(-c for c in other.coeffs),
            self.vars + other.vars,
            self.model,
        )

    def __neg__(self) -> ScalarLinearExpression:
        return ScalarLinearExpression(
            tuple(-c for c in self.coeffs), self.vars, self.model
        )

    def __mul__(self, other: float | int) -> ScalarLinearExpression:
        if not isinstance(other, int | float | np.number):
            raise TypeError(
                f"unsupported operand type(s) for *: {type(self)} and {type(other)}"
            )

        return ScalarLinearExpression(
            tuple(other * c for c in self.coeffs), self.vars, self.model
        )

    def __rmul__(self, other: int) -> ScalarLinearExpression:
        return self.__mul__(other)

    def __div__(self, other: float | int) -> ScalarLinearExpression:
        if not isinstance(other, int | float | np.number):
            raise TypeError(
                f"unsupported operand type(s) for /: {type(self)} and {type(other)}"
            )
        return self.__mul__(1 / other)

    def __truediv__(self, other: float | int) -> ScalarLinearExpression:
        return self.__div__(other)

    def __le__(self, other: int | float) -> AnonymousScalarConstraint:
        if not isinstance(other, int | float | np.number):
            raise TypeError(
                f"unsupported operand type(s) for <=: {type(self)} and {type(other)}"
            )

        return constraints.AnonymousScalarConstraint(self, LESS_EQUAL, other)

    def __ge__(self, other: int | float) -> AnonymousScalarConstraint:
        if not isinstance(other, int | float | np.number):
            raise TypeError(
                f"unsupported operand type(s) for >=: {type(self)} and {type(other)}"
            )

        return constraints.AnonymousScalarConstraint(self, GREATER_EQUAL, other)

    def __eq__(  # type: ignore[override]
        self, other: int | float
    ) -> AnonymousScalarConstraint:
        if not isinstance(other, int | float | np.number):
            raise TypeError(
                f"unsupported operand type(s) for ==: {type(self)} and {type(other)}"
            )

        return constraints.AnonymousScalarConstraint(self, EQUAL, other)

    def __gt__(self, other: int | float) -> AnonymousScalarConstraint:
        raise NotImplementedError(
            "Inequalities only ever defined for >= rather than >."
        )

    def __lt__(self, other: int | float) -> AnonymousScalarConstraint:
        raise NotImplementedError(
            "Inequalities only ever defined for >= rather than >."
        )

    def to_linexpr(self) -> LinearExpression:
        coeffs = xr.DataArray(list(self.coeffs), dims=TERM_DIM)
        vars = xr.DataArray(list(self.vars), dims=TERM_DIM)
        ds = xr.Dataset({"coeffs": coeffs, "vars": vars})
        return LinearExpression(ds, self.model)


SUPPORTED_EXPRESSION_TYPES = (
    BaseExpression,
    ScalarLinearExpression,
    variables.Variable,
    variables.ScalarVariable,
)
