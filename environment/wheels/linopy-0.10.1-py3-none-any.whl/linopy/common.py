#!/usr/bin/env python3
"""
Linopy common module.

This module contains commonly used functions.
"""

from __future__ import annotations

import json
import operator
from collections.abc import Callable, Generator, Hashable, Iterable, Mapping, Sequence
from functools import cached_property, reduce, wraps
from pathlib import Path
from typing import TYPE_CHECKING, Any, Generic, TypeVar, overload
from warnings import warn

import numpy as np
import pandas as pd
import polars as pl
from numpy import nan, signedinteger
from numpy.typing import DTypeLike
from polars.datatypes import DataTypeClass
from xarray import DataArray, Dataset, apply_ufunc, broadcast
from xarray import align as xr_align
from xarray.core import indexing
from xarray.namedarray.utils import is_dict_like

from linopy.alignment import _as_index
from linopy.config import options
from linopy.constants import (
    SIGNS,
    SIGNS_alternative,
    SIGNS_pretty,
    sign_replace_dict,
)
from linopy.types import (
    CONSTANT_TYPES,
    SideLike,
)

if TYPE_CHECKING:
    from linopy.constraints import ConstraintBase
    from linopy.expressions import LinearExpression, QuadraticExpression
    from linopy.variables import Variable


def set_int_index(series: pd.Series) -> pd.Series:
    """
    Convert string index to int index.
    """

    if not series.empty and not pd.api.types.is_integer_dtype(series.index):
        cutoff = count_initial_letters(str(series.index[0]))
        try:
            series.index = series.index.str[cutoff:].astype(int)
        except ValueError:
            series.index = series.index.str.replace(".*#", "", regex=True).astype(int)
    return series


def maybe_replace_sign(sign: str) -> str:
    """
    Replace the sign with an alternative sign if available.

    Parameters
    ----------
        sign (str): The sign to be replaced.

    Returns
    -------
        str: The replaced sign.

    Raises
    ------
        ValueError: If the sign is not in the available signs.
    """
    if sign in SIGNS_alternative:
        return sign_replace_dict[sign]
    elif sign in SIGNS:
        return sign
    else:
        raise ValueError(f"Sign {sign} not in {SIGNS} or {SIGNS_alternative}")


def maybe_replace_signs(sign: DataArray) -> DataArray:
    """
    Replace signs with alternative signs if available.

    Parameters
    ----------
        sign (np.ndarray): The signs to be replaced.

    Returns
    -------
        np.ndarray: The replaced signs.
    """
    func = np.vectorize(maybe_replace_sign)
    return apply_ufunc(func, sign, dask="parallelized", output_dtypes=[sign.dtype])


def format_string_as_variable_name(name: Hashable) -> str:
    """
    Format a string to a valid python variable name.

    Parameters
    ----------
        name (str): The name to be converted.

    Returns
    -------
        str: The formatted name.
    """
    return str(name).replace(" ", "_").replace("-", "_")


# TODO: rename to to_pandas_dataframe
def to_dataframe(
    ds: Dataset,
    mask_func: Callable[[dict[Hashable, np.ndarray]], pd.Series] | None = None,
) -> pd.DataFrame:
    """
    Convert an xarray Dataset to a pandas DataFrame.

    This is an memory efficient alternative implementation to the built-in `to_dataframe` method, which
    does not create a multi-indexed DataFrame.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset to convert to a DataFrame.
    """
    data = broadcast(ds)[0]
    datadict = {k: v.values.reshape(-1) for k, v in data.items()}

    if mask_func is not None:
        mask = mask_func(datadict)
        for k, v in datadict.items():
            datadict[k] = v[mask]

    return pd.DataFrame(datadict, copy=False)


def check_has_nulls(df: pd.DataFrame, name: str) -> None:
    any_nan = df.isna().any()
    if any_nan.any():
        fields = ", ".join(df.columns[any_nan].to_list())
        raise ValueError(f"Fields {name} contains nan's in field(s) {fields}")


def infer_schema_polars(ds: Dataset) -> dict[str, DataTypeClass]:
    """
    Infer the polars data schema from a xarray dataset.

    Args:
    ----
        ds (polars.DataFrame): The Polars DataFrame for which to infer the schema.

    Returns:
    -------
        dict: A dictionary mapping column names to their corresponding Polars data types.
    """
    schema: dict[str, DataTypeClass] = {}
    for name, array in ds.items():
        name = str(name)
        if np.issubdtype(array.dtype, np.integer):
            schema[name] = pl.Int32 if array.dtype.itemsize <= 4 else pl.Int64
        elif np.issubdtype(array.dtype, np.floating):
            schema[name] = pl.Float64
        elif np.issubdtype(array.dtype, np.bool_):
            schema[name] = pl.Boolean
        elif np.issubdtype(array.dtype, np.object_):
            schema[name] = pl.Object
        else:
            schema[name] = pl.Utf8
    return schema


def to_polars(ds: Dataset, **kwargs: Any) -> pl.DataFrame:
    """
    Convert an xarray Dataset to a polars DataFrame.

    This is an memory efficient alternative implementation
    of `to_dataframe`.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset to convert to a DataFrame.
    kwargs : dict
        Additional keyword arguments to be passed to the
        DataFrame constructor.
    """
    data = broadcast(ds)[0]
    return pl.DataFrame({k: v.values.reshape(-1) for k, v in data.items()}, **kwargs)


def check_has_nulls_polars(df: pl.DataFrame, name: str = "") -> None:
    """
    Checks if the given DataFrame contains any null or NaN values and raises a ValueError if it does.

    Args:
    ----
        df (pl.DataFrame): The DataFrame to check for null or NaN values.
        name (str): The name of the data container being checked.

    Raises:
    ------
        ValueError: If the DataFrame contains null or NaN values,
        a ValueError is raised with a message indicating the name of the constraint and the fields containing null/NaN values.
    """
    # Check for null values in all columns
    has_nulls = df.select(pl.col("*").is_null().any())
    null_columns = [col for col in has_nulls.columns if has_nulls[col][0]]

    # Check for NaN values only in numeric columns (avoid enum/categorical columns)
    numeric_cols = [
        col for col, dtype in zip(df.columns, df.dtypes) if dtype.is_numeric()
    ]

    nan_columns = []
    if numeric_cols:
        has_nans = df.select(pl.col(numeric_cols).is_nan().any())
        nan_columns = [col for col in has_nans.columns if has_nans[col][0]]

    invalid_columns = list(set(null_columns + nan_columns))
    if invalid_columns:
        raise ValueError(f"{name} contains nan's in field(s) {invalid_columns}")


def filter_nulls_polars(df: pl.DataFrame) -> pl.DataFrame:
    """
    Filter out rows containing "empty" values from a polars DataFrame.

    Args:
    ----
        df (pl.DataFrame): The DataFrame to filter.

    Returns:
    -------
        pl.DataFrame: The filtered DataFrame.
    """
    cond = []
    varcols = [c for c in df.columns if c.startswith("vars")]
    if varcols:
        cond.append(reduce(operator.or_, [pl.col(c).ne(-1) for c in varcols]))
    if "coeffs" in df.columns:
        cond.append(pl.col("coeffs").ne(0))
    if "labels" in df.columns:
        cond.append(pl.col("labels").ne(-1))

    cond = reduce(operator.and_, cond)  # type: ignore[arg-type]
    return df.filter(cond)


def group_terms_polars(df: pl.DataFrame) -> pl.DataFrame:
    """
    Groups terms in a polars DataFrame.

    Args:
    ----
        df (pl.DataFrame): The input DataFrame containing the terms.

    Returns:
    -------
        pl.DataFrame: The DataFrame with grouped terms.

    """
    varcols = [c for c in df.columns if c.startswith("vars")]
    agg_list = [pl.col("coeffs").sum().alias("coeffs")]
    for col in set(df.columns) - set(["coeffs", "labels", *varcols]):
        agg_list.append(pl.col(col).first().alias(col))

    by = [c for c in ["labels"] + varcols if c in df.columns]
    df = df.group_by(by, maintain_order=True).agg(agg_list)
    return df


def maybe_group_terms_polars(df: pl.DataFrame) -> pl.DataFrame:
    """
    Group terms only if there are duplicate (labels, vars) pairs.

    This avoids the expensive group_by operation when terms already
    reference distinct variables (e.g. ``x - y`` has ``_term=2`` but
    no duplicates). When skipping, columns are reordered to match the
    output of ``group_terms_polars``.
    """
    varcols = [c for c in df.columns if c.startswith("vars")]
    keys = [c for c in ["labels"] + varcols if c in df.columns]
    key_count = df.select(pl.struct(keys).n_unique()).item()
    if key_count < df.height:
        return group_terms_polars(df)
    # Match column order of group_terms (group-by keys, coeffs, rest)
    rest = [c for c in df.columns if c not in keys and c != "coeffs"]
    return df.select(keys + ["coeffs"] + rest)


def save_join(*dataarrays: DataArray, fill_dtype: DTypeLike | None = None) -> Dataset:
    """
    Join multiple xarray Dataarray's to a Dataset and warn if coordinates are not equal.

    If ``fill_dtype`` is given, values filled in by an outer join are set to -1
    and the arrays are cast to that dtype (used for integer label arrays).
    """
    try:
        arrs = xr_align(*dataarrays, join="exact")
    except ValueError:
        warn(
            "Coordinates across variables not equal. Perform outer join.",
            UserWarning,
        )
        arrs = xr_align(*dataarrays, join="outer")
        if fill_dtype is not None:
            arrs = tuple([ds.fillna(-1).astype(fill_dtype) for ds in arrs])
    return Dataset({ds.name: ds for ds in arrs})


def assign_multiindex_safe(ds: Dataset, **fields: Any) -> Dataset:
    """
    Assign a field to a xarray Dataset while being safe against warnings about multiindex corruption.

    See https://github.com/PyPSA/linopy/issues/303 for more information

    Parameters
    ----------
    ds : Dataset
        Dataset to assign the field to
    keys : Union[str, List[str]]
        Keys of the fields
    to_assign : Union[List[DataArray], DataArray, Dataset]
        New values added to the dataset

    Returns
    -------
    Dataset
        Merged dataset with the new field added
    """
    remainders = list(set(ds) - set(fields))
    return Dataset({**ds[remainders], **fields}, attrs=ds.attrs)


def _as_renamed_index(values: Any, name: Hashable, context: str) -> pd.Index:
    """
    Convert coordinate-like values to a pandas Index named ``name``.

    The dimension name is authoritative: a passed Index or DataArray with a
    different (or missing) name is renamed to ``name``, like
    :meth:`xarray.Dataset.assign_coords` does for keyword-assigned coords.
    """
    try:
        index = _as_index(values)
        if index.name != name:
            index = index.rename(name)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"New coordinates for dimension '{name}' on {context} must be "
            f"index-like, got {type(values).__name__}: {values!r}."
        ) from e
    return index


def validate_coords_reassignment(
    sizes: Mapping[str, int], coords: Mapping[str, Any], context: str
) -> dict[str, pd.Index]:
    """
    Validate values-only coordinate reassignment and convert the new values.

    Single-sourced per-item invariants for coordinate reassignment, used by
    the Dataset-backed (:func:`assign_coords_multiindex_safe`) and the
    CSR-backed (``CSRConstraint``) paths alike, so every entry point is safe
    on its own. Model-level aggregate checks (dimension exists somewhere in
    the model, consistent lengths across containers) live on top of this.

    The keyword key is authoritative: values converted to an Index with a
    different (or missing) name are renamed to the target dimension, like
    :meth:`xarray.Dataset.assign_coords` does.

    Parameters
    ----------
    sizes : Mapping
        Existing dimension name to length, defining which coordinates may be
        reassigned.
    coords : Mapping
        New coordinate values, keyed by existing dimension name.
    context : str
        Name of the object being reassigned, used in error messages.

    Returns
    -------
    dict
        New coordinate values converted to named pandas Index objects, ready
        for assignment.

    Raises
    ------
    ValueError
        If a named coordinate does not exist in ``sizes``, the new values are
        not index-like, or their length differs from the existing dimension.
    """
    missing = [name for name in coords if name not in sizes]
    if missing:
        raise ValueError(f"Cannot assign missing coordinates {missing} to {context}.")
    new_indexes: dict[str, pd.Index] = {}
    for name, values in coords.items():
        index = _as_renamed_index(values, name, context)
        if len(index) != sizes[name]:
            raise ValueError(
                f"Cannot assign coordinates to dimension '{name}' on {context} "
                f"with a different length: expected {sizes[name]}, got "
                f"{len(index)}."
            )
        new_indexes[name] = index
    return new_indexes


def assign_coords_multiindex_safe(ds: Dataset, **coords: Any) -> Dataset:
    """
    Reassign coordinate values on an existing Dataset, keeping the shape.

    Values-only replacement of existing dimension coordinates: each new value
    must match the length of the dimension it replaces. Neither the order of
    the dataset's variables nor the order of its coordinates is altered —
    plain :meth:`xarray.Dataset.assign_coords` moves every reassigned
    coordinate to the end, which breaks downstream dimension inference.

    Parameters
    ----------
    ds : Dataset
        Dataset to reassign the coordinates on.
    **coords : Any
        New coordinate values, keyed by existing dimension name. Accepted
        like in :meth:`xarray.Dataset.assign_coords`: index-likes such as
        numpy arrays, pandas Index objects, DataArrays or lists.

    Returns
    -------
    Dataset
        Dataset with reassigned coordinate values.
    """
    sizes = {str(name): coord.size for name, coord in ds.coords.items()}
    new_indexes = validate_coords_reassignment(sizes, coords, "dataset")
    new = ds.assign_coords(new_indexes)
    ordered = {name: new[name] for name in ds.coords}
    data_vars = {name: new[name].variable for name in new.data_vars}
    return Dataset(data_vars, coords=ordered, attrs=new.attrs)


T = TypeVar("T", Dataset, "Variable", "LinearExpression", "ConstraintBase")


@overload
def iterate_slices(
    ds: Dataset,
    slice_size: int | None = 10_000,
    slice_dims: list | None = None,
) -> Generator[Dataset, None, None]: ...


@overload
def iterate_slices(
    ds: Variable,
    slice_size: int | None = 10_000,
    slice_dims: list | None = None,
) -> Generator[Variable, None, None]: ...


@overload
def iterate_slices(
    ds: LinearExpression,
    slice_size: int | None = 10_000,
    slice_dims: list | None = None,
) -> Generator[LinearExpression, None, None]: ...


@overload
def iterate_slices(
    ds: ConstraintBase,
    slice_size: int | None = 10_000,
    slice_dims: list | None = None,
) -> Generator[ConstraintBase, None, None]: ...


def iterate_slices(
    ds: T,
    slice_size: int | None = 10_000,
    slice_dims: list | None = None,
) -> Generator[T, None, None]:
    """
    Generate slices of an xarray Dataset or DataArray with a specified soft maximum size.

    The slicing is performed on the largest dimension of the input object.
    If the maximum size is larger than the total size of the object, the function yields
    the original object.

    Parameters
    ----------
    ds : xarray.Dataset or xarray.DataArray
        The input xarray Dataset or DataArray to be sliced.
    slice_size : int
        The maximum number of elements in each slice. If the maximum size is too small to accommodate any slice,
        the function splits the largest dimension.
    slice_dims : list, optional
        The dimensions to slice along. If None, all dimensions in `coord_dims` are used if
        `coord_dims` is an attribute of the input object. Otherwise, all dimensions are used.

    Yields
    ------
    xarray.Dataset or xarray.DataArray
        A slice of the input Dataset or DataArray.

    """
    if slice_dims is None:
        slice_dims = list(getattr(ds, "coord_dims", ds.dims))

    if not set(slice_dims).issubset(ds.dims):
        raise ValueError(
            "Invalid slice dimensions. Must be a subset of the dataset dimensions."
        )

    # Calculate the total number of elements in the dataset
    size = np.prod([ds.sizes[dim] for dim in ds.dims], dtype=int)

    if slice_size is None or size <= slice_size:
        yield ds
        return

    # number of slices
    n_slices = max((size + slice_size - 1) // slice_size, 1)

    # leading dimension (the dimension with the largest size)
    sizes = {dim: ds.sizes[dim] for dim in slice_dims}
    if not sizes:
        yield ds
        return

    leading_dim = max(sizes, key=sizes.get)  # type: ignore
    size_of_leading_dim = ds.sizes[leading_dim]

    if size_of_leading_dim < n_slices:
        n_slices = size_of_leading_dim

    chunk_size = (ds.sizes[leading_dim] + n_slices - 1) // n_slices

    # Iterate over the Cartesian product of slice indices
    for i in range(n_slices):
        start = i * chunk_size
        end = min(start + chunk_size, size_of_leading_dim)
        slice_dict = {leading_dim: slice(start, end)}
        yield ds.isel(slice_dict)  # type: ignore[attr-defined]


def _remap(array: np.ndarray, mapping: np.ndarray) -> np.ndarray:
    return mapping[array.ravel()].reshape(array.shape)


def count_initial_letters(word: str) -> int:
    """
    Count the number of initial letters in a word.
    """
    count = 0
    for char in word:
        if char.isalpha():
            count += 1
        else:
            break
    return count


def replace_by_map(ds: DataArray, mapping: np.ndarray) -> DataArray:
    """
    Replace values in a DataArray by a one-dimensional mapping.
    """
    return apply_ufunc(
        _remap,
        ds,
        kwargs=dict(mapping=mapping),
        dask="parallelized",
        output_dtypes=[mapping.dtype],
    )


def assigned_labels(labels: np.ndarray | DataArray) -> np.ndarray:
    """
    Flatten labels and drop the -1 sentinels.

    ``-1`` marks a masked entry in a variable's or constraint's labels, but an
    empty term slot in the ``vars`` field of a constraint or expression.
    Matching labels of one object against another must therefore ignore it,
    otherwise every masked entry compares equal to every empty term slot.
    """
    flat = np.asarray(labels).ravel()
    return flat[flat != -1]


def contains_labels(values: np.ndarray, labels: np.ndarray) -> bool:
    """
    Whether any entry of ``values`` is one of ``labels``.

    ``labels`` must not contain the ``-1`` sentinel, see :func:`assigned_labels`.
    Labels are handed out in ascending blocks, so restricting ``values`` to the
    label range is both a cheap prefilter and, whenever the block is gap-free, the
    complete answer.
    """
    if not labels.size:
        return False
    low, high = labels.min(), labels.max()
    candidates = values[(values >= low) & (values <= high)]
    if not candidates.size:
        return False
    is_gap_free = bool((np.diff(labels) == 1).all())
    if is_gap_free:
        return True
    return bool(np.isin(candidates, labels).any())


def to_path(path: str | Path | None) -> Path | None:
    """
    Convert a string to a Path object.
    """
    return Path(path) if path is not None else None


def best_int(max_value: int) -> type[signedinteger[Any]]:
    """
    Get the minimal int dtype for storing values <= max_value.
    """
    for t in (np.int8, np.int16, np.int32, np.int64):
        if max_value <= np.iinfo(t).max:
            return t
    raise ValueError(f"Value {max_value} is too large for int64.")


def generate_indices_for_printout(
    dim_sizes: Sequence[int], max_lines: int
) -> Generator[tuple[int | np.signedinteger[Any], ...] | None, None, None]:
    total_lines = int(np.prod(dim_sizes))
    lines_to_skip = total_lines - max_lines + 1 if total_lines > max_lines else 0
    if lines_to_skip > 0:
        half_lines = max_lines // 2
        for i in range(half_lines):
            yield np.unravel_index(i, dim_sizes)
        yield None
        for i in range(total_lines - half_lines, total_lines):
            yield tuple(np.unravel_index(i, dim_sizes))
    else:
        for i in range(total_lines):
            yield tuple(np.unravel_index(i, dim_sizes))


def align_lines_by_delimiter(lines: list[str], delimiter: str | list[str]) -> list[str]:
    # Determine the maximum position of the delimiter
    if isinstance(delimiter, str):
        delimiter = [delimiter]
    try:
        max_pos = max(line.index(d) for line in lines for d in delimiter if d in line)
    except ValueError:
        return lines

    # Create the formatted lines
    formatted_lines = []
    for line in lines:
        formatted_line = line
        for d in delimiter:
            if d in line:
                parts = line.split(d)
                formatted_line = f"{parts[0]:<{max_pos}}{d} {parts[1].strip()}"
        formatted_lines.append(formatted_line)
    return formatted_lines


def index_level_coords(ds: Dataset, dim: Hashable) -> list[str]:
    """
    Auxiliary (non-dimension) coords aligned solely to ``dim`` — under v1 the
    levels a flattened ``pd.MultiIndex`` leaves behind, its flat-dim mirror.
    """
    return [
        str(name)
        for name, coord in ds.coords.items()
        if name != dim and coord.dims == (dim,)
    ]


def dim_level_names(ds: Dataset, dim: Hashable) -> list[str]:
    """Level names of ``dim`` — a MultiIndex's own levels, else its aux coords."""
    index = ds.indexes.get(dim)
    if isinstance(index, pd.MultiIndex):
        return [str(name) for name in index.names]
    return index_level_coords(ds, dim)


def get_dims_with_index_levels(
    ds: Dataset, dims: Sequence[Hashable] | None = None
) -> list[str]:
    """
    Get the dimensions of a Dataset with their index levels.

    A multi-indexed 'station' with levels ['country', 'city'] and a flat 'node'
    with aux level coords ['region', 'tech'] both render as "dim (l0, l1)":
    ['time', 'station (country, city)', 'node (region, tech)'].
    """
    if dims is None:
        dims = list(ds.dims)
    return [
        f"{dim} ({', '.join(levels)})"
        if (levels := dim_level_names(ds, dim))
        else str(dim)
        for dim in dims
    ]


def label_coord(obj: Any, dims: Sequence[Hashable], index: Sequence[int]) -> dict:
    """
    Identifying coordinate for a single flat position, per dimension — a
    decomposed MultiIndex identifies the same way a first-class one does:
    several aux levels stack into a tuple, one level is its bare value.
    """
    coord = {}
    for dim, i in zip(dims, index):
        levels = index_level_coords(obj, dim)
        if len(levels) > 1:
            coord[dim] = tuple(obj.coords[level].values[i] for level in levels)
        elif len(levels) == 1:
            coord[dim] = obj.coords[levels[0]].values[i]
        else:
            coord[dim] = obj.indexes[dim][i]
    return coord


def get_printout_labels(ds: Dataset, dims: Sequence[Hashable]) -> list[Any]:
    """
    Per-dim row-label sequences for a repr, indexable by dimension position —
    the vectorised sibling of ``label_coord``: aux levels zipped into tuples,
    one level as its bare values, else the bare dimension index.
    """
    labels: list[Any] = []
    for dim in dims:
        levels = index_level_coords(ds, dim)
        if len(levels) > 1:
            labels.append(list(zip(*(ds[level].values for level in levels))))
        elif len(levels) == 1:
            labels.append(ds[levels[0]].values)
        else:
            labels.append(ds.indexes[dim])
    return labels


class LabelPositionIndex:
    """
    Index for fast O(log n) lookup of label positions using binary search.

    This class builds a sorted index of label ranges and uses binary search
    to find which container (variable/constraint) a label belongs to.

    Parameters
    ----------
    obj : Any
        Container object with items() method returning (name, val) pairs,
        where val has .labels and .range attributes.
    """

    __slots__ = ("_starts", "_names", "_obj", "_built")

    def __init__(self, obj: Any) -> None:
        self._obj = obj
        self._starts: np.ndarray | None = None
        self._names: list[str] | None = None
        self._built = False

    def _build_index(self) -> None:
        """Build the sorted index of label ranges."""
        if self._built:
            return

        ranges = []
        for name, val in self._obj.items():
            start, stop = val.range
            ranges.append((start, name))

        # Sort by start value
        ranges.sort(key=lambda x: x[0])
        self._starts = np.array([r[0] for r in ranges])
        self._names = [r[1] for r in ranges]
        self._built = True

    def invalidate(self) -> None:
        """Invalidate the index (call when items are added/removed)."""
        self._built = False
        self._starts = None
        self._names = None

    def find_single(self, value: int) -> tuple[str, dict] | tuple[None, None]:
        """Find the name and coordinates for a single label value."""
        if value == -1:
            return None, None

        self._build_index()
        starts = self._starts
        names = self._names
        assert starts is not None and names is not None

        # Binary search to find the right range
        idx = int(np.searchsorted(starts, value, side="right")) - 1

        if idx < 0 or idx >= len(starts):
            raise ValueError(f"Label {value} is not existent in the model.")

        name = names[idx]
        val = self._obj[name]
        start, stop = val.range

        # Verify the value is in range
        if value < start or value >= stop:
            raise ValueError(f"Label {value} is not existent in the model.")

        labels = val.labels
        index = np.unravel_index(value - start, labels.shape)
        coord = label_coord(labels, labels.dims, index)
        return name, coord

    def find_single_with_index(
        self, value: int
    ) -> tuple[str, dict, tuple[int, ...]] | tuple[None, None, None]:
        """
        Find name, coordinates, and raw numpy index for a single label value.

        Returns (name, coord, index) where index is a tuple of integers that
        can be used for direct numpy indexing (e.g., arr.values[index]).
        This avoids the overhead of xarray's .sel() method.
        """
        if value == -1:
            return None, None, None

        self._build_index()
        starts = self._starts
        names = self._names
        assert starts is not None and names is not None

        # Binary search to find the right range
        idx = int(np.searchsorted(starts, value, side="right")) - 1

        if idx < 0 or idx >= len(starts):
            raise ValueError(f"Label {value} is not existent in the model.")

        name = names[idx]
        val = self._obj[name]
        start, stop = val.range

        # Verify the value is in range
        if value < start or value >= stop:
            raise ValueError(f"Label {value} is not existent in the model.")

        labels = val.labels
        index = np.unravel_index(value - start, labels.shape)
        coord = label_coord(labels, labels.dims, index)
        return name, coord, index


def _get_label_position_linear(
    obj: Any, values: int | np.ndarray
) -> (
    tuple[str, dict]
    | tuple[None, None]
    | list[tuple[str, dict] | tuple[None, None]]
    | list[list[tuple[str, dict] | tuple[None, None]]]
):
    """
    Get tuple of name and coordinate for variable labels.

    This is the original O(n) implementation that scans through all items.
    Used only for testing/benchmarking comparisons.
    """

    def find_single(value: int) -> tuple[str, dict] | tuple[None, None]:
        if value == -1:
            return None, None
        for name, val in obj.items():
            labels = val.labels
            start, stop = val.range

            if value >= start and value < stop:
                index = np.unravel_index(value - start, labels.shape)

                coord = label_coord(labels, labels.dims, index)
                return name, coord
        raise ValueError(f"Label {value} is not existent in the model.")

    if isinstance(values, int):
        return find_single(values)

    values = np.array(values)
    ndim = values.ndim
    if ndim == 0:
        return find_single(values.item())
    elif ndim == 1:
        return [find_single(v) for v in values]
    elif ndim == 2:
        return [[find_single(v) for v in _] for _ in values.T]
    else:
        raise ValueError("Array's with more than two dimensions is not supported")


class VariableLabelIndex:
    """
    Index for O(1) mapping between variable labels and dense positions.

    Both arrays are computed lazily and cached:
    - ``vlabels``: active variable labels in encounter order, shape (n_active_vars,)
    - ``label_to_pos``: derived from vlabels; size _xCounter, maps label -> position (-1 if masked)

    Invalidated by clearing the instance ``__dict__`` when variables are added or removed.
    """

    def __init__(self, variables: Any) -> None:
        self._variables = variables

    @cached_property
    def vlabels(self) -> np.ndarray:
        """Active variable labels in encounter order, shape (n_active_vars,)."""
        label_lists = []
        for _, var in self._variables.items():
            labels = var.labels.values.ravel()
            mask = labels != -1
            label_lists.append(labels[mask])
        return (
            np.concatenate(label_lists) if label_lists else np.array([], dtype=np.intp)
        )

    @cached_property
    def label_to_pos(self) -> np.ndarray:
        """
        Mapping from variable label to dense position, shape (_xCounter,).

        Positions share the model's label dtype, since they never exceed a label.

        Position i in the active variable array corresponds to label vlabels[i].
        Masked or unused labels map to -1.
        """
        vlabels = self.vlabels
        model = self._variables.model
        dtype = model._dtypes["labels"]
        label_to_pos = np.full(model._xCounter, -1, dtype=dtype)
        label_to_pos[vlabels] = np.arange(len(vlabels), dtype=dtype)
        return label_to_pos

    @property
    def n_active_vars(self) -> int:
        """Number of active (non-masked) variables."""
        return len(self.vlabels)

    def invalidate(self) -> None:
        """Clear cached arrays so they are recomputed on next access."""
        self.__dict__.pop("vlabels", None)
        self.__dict__.pop("label_to_pos", None)


class ConstraintLabelIndex:
    """
    Index for O(1) mapping between constraint labels and dense positions.

    Mirrors VariableLabelIndex on the constraint side, but without building
    the full constraint matrix — only labels and the row mask are computed.
    """

    def __init__(self, constraints: Any) -> None:
        self._constraints = constraints

    @cached_property
    def clabels(self) -> np.ndarray:
        """Active constraint labels in build order, shape (n_active_cons,)."""
        label_lists = [
            c.active_labels()
            for c in self._constraints.data.values()
            if not c.is_indicator
        ]
        dtype = self._constraints.model._dtypes["labels"]
        return np.concatenate([np.array([], dtype=dtype), *label_lists], dtype=dtype)

    @cached_property
    def label_to_pos(self) -> np.ndarray:
        """Mapping from constraint label to dense position, shape (_cCounter,)."""
        clabels = self.clabels
        model = self._constraints.model
        dtype = model._dtypes["labels"]
        label_to_pos = np.full(model._cCounter, -1, dtype=dtype)
        label_to_pos[clabels] = np.arange(len(clabels), dtype=dtype)
        return label_to_pos

    @property
    def n_active_cons(self) -> int:
        return len(self.clabels)

    def invalidate(self) -> None:
        self.__dict__.pop("clabels", None)
        self.__dict__.pop("label_to_pos", None)


def get_label_position(
    obj: Any,
    values: int | np.ndarray,
    index: LabelPositionIndex | None = None,
) -> (
    tuple[str, dict]
    | tuple[None, None]
    | list[tuple[str, dict] | tuple[None, None]]
    | list[list[tuple[str, dict] | tuple[None, None]]]
):
    """
    Get tuple of name and coordinate for variable labels.

    Uses O(log n) binary search with a cached index for fast lookups.

    Parameters
    ----------
    obj : Any
        Container object with items() method (Variables or Constraints).
    values : int or np.ndarray
        Label value(s) to look up.
    index : LabelPositionIndex, optional
        Pre-built index for fast lookups. If None, one will be created.

    Returns
    -------
    tuple or list
        (name, coord) tuple for single values, or list of tuples for arrays.
    """
    if index is None:
        index = LabelPositionIndex(obj)

    if isinstance(values, int):
        return index.find_single(values)

    values = np.array(values)
    ndim = values.ndim
    if ndim == 0:
        return index.find_single(values.item())
    elif ndim == 1:
        return [index.find_single(int(v)) for v in values]
    elif ndim == 2:
        return [[index.find_single(int(v)) for v in col] for col in values.T]
    else:
        raise ValueError("Array's with more than two dimensions is not supported")


def format_coord(coord: dict[str, Any] | Iterable[Any]) -> str:
    """
    Format coordinates into a string representation.

    Args:
        coord: Dictionary or iterable containing coordinate values.
              Values can be numbers, strings, or nested iterables.

    Returns:
        Formatted string representation of coordinates in brackets,
        with nested coordinates grouped in parentheses.

    Examples:
        >>> format_coord({"x": 1, "y": 2})
        '[1, 2]'
        >>> format_coord([1, 2, 3])
        '[1, 2, 3]'
        >>> format_coord([(1, 2), (3, 4)])
        '[(1, 2), (3, 4)]'
    """
    # Handle empty input
    if not coord:
        return ""

    # Extract values if input is dictionary
    values = coord.values() if isinstance(coord, dict) else coord

    # Convert each coordinate component to string
    formatted = []
    for value in values:
        if isinstance(value, list | tuple):
            formatted.append(f"({', '.join(str(x) for x in value)})")
        else:
            formatted.append(str(value))

    return f"[{', '.join(formatted)}]"


def format_single_variable(model: Any, label: int) -> str:
    if label == -1:
        return "None"

    variables = model.variables
    name, coord, index = variables.get_label_position_with_index(label)

    var = variables[name]
    # Use direct numpy indexing instead of .sel() for performance
    lower = var.lower.values[index]
    upper = var.upper.values[index]

    if var.attrs["binary"]:
        bounds = " ∈ {0, 1}"
    elif var.attrs["integer"]:
        bounds = f" ∈ Z ⋂ [{lower:.4g},...,{upper:.4g}]"
    else:
        bounds = f" ∈ [{lower:.4g}, {upper:.4g}]"

    return f"{name}{format_coord(coord)}{bounds}"


def format_single_expression(
    c: np.ndarray,
    v: np.ndarray,
    const: float,
    model: Any,
) -> str:
    """
    Print a single linear expression based on the coefficients and variables.
    """
    c, v = np.atleast_1d(c), np.atleast_1d(v)

    # catch case that to many terms would be printed
    def format_line(
        expr: list[tuple[float, tuple[str, Any] | list[tuple[str, Any]]]], const: float
    ) -> str:
        res = []
        for i, (coeff, var) in enumerate(expr):
            coeff_string = f"{coeff:+.4g}"
            if i:
                # split sign and coefficient
                coeff_string = f"{coeff_string[0]} {coeff_string[1:]}"

            if isinstance(var, list):
                var_string = ""
                for name, coords in var:
                    if name is not None:
                        coord_string = format_coord(coords)
                        var_string += f" {name}{coord_string}"
            else:
                name, coords = var
                coord_string = format_coord(coords)
                var_string = f" {name}{coord_string}"

            res.append(f"{coeff_string}{var_string}")

        if not np.isnan(const) and not (const == 0.0 and len(res) >= 1):
            const_string = f"{const:+.4g}"
            if len(res):
                res.append(f"{const_string[0]} {const_string[1:]}")
            else:
                res.append(const_string)
        return " ".join(res) if len(res) else "None"

    if v.ndim == 1:
        mask = v != -1
        c, v = c[mask], v[mask]
    else:
        # case for quadratic expressions
        mask = (v != -1).any(0)
        c = c[mask]
        v = v[:, mask]

    max_terms = options.get_value("display_max_terms")
    if len(c) > max_terms:
        truncate = max_terms // 2
        positions = model.variables.get_label_position(v[..., :truncate])
        expr = list(zip(c[:truncate], positions))
        res = format_line(expr, const)
        res += " ... "
        expr = list(
            zip(
                c[-truncate:],
                model.variables.get_label_position(v[-truncate:]),
            )
        )
        residual = format_line(expr, const)
        if residual != " None":
            res += residual
        return res
    expr = list(zip(c, model.variables.get_label_position(v)))
    return format_line(expr, const)


def format_single_constraint(model: Any, label: int) -> str:
    constraints = model.constraints
    name, coord = constraints.get_label_position(label)

    coeffs = model.constraints[name].coeffs.sel(coord).values
    vars = model.constraints[name].vars.sel(coord).values
    sign = model.constraints[name].sign.sel(coord).item()
    rhs = model.constraints[name].rhs.sel(coord).item()

    expr = format_single_expression(coeffs, vars, 0, model)
    sign = SIGNS_pretty[sign]

    return f"{name}{format_coord(coord)}: {expr} {sign} {rhs:.12g}"


def has_optimized_model(func: Callable[..., Any]) -> Callable[..., Any]:
    """
    Check if a reference model is set.
    """

    @wraps(func)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self.model is None:
            raise AttributeError("No reference model set.")
        if self.model.status != "ok":
            raise AttributeError("Underlying model not optimized.")
        return func(self, *args, **kwargs)

    return wrapper


def require_constant(func: Callable[..., Any]) -> Callable[..., Any]:
    from linopy import expressions, variables

    @wraps(func)
    def wrapper(self: Any, arg: Any) -> Any:
        if isinstance(
            arg,
            variables.Variable
            | variables.ScalarVariable
            | expressions.LinearExpression
            | expressions.QuadraticExpression,
        ):
            raise TypeError(f"Assigned rhs must be a constant, got {type(arg)}).")
        return func(self, arg)

    return wrapper


def forward_as_properties(**routes: list[str]) -> Callable[[type], type]:
    #
    def add_accessor(cls: Any, item: str, attr: str) -> None:
        def get(self: Any) -> Any:
            return getattr(getattr(self, item), attr)

        setattr(cls, attr, property(get))

    def deco(cls: Any) -> Any:
        for item, attrs in routes.items():
            for attr in attrs:
                add_accessor(cls, item, attr)
        return cls

    return deco


def check_common_keys_values(list_of_dicts: list[dict[str, Any]]) -> bool:
    """
    Check if all common keys among a list of dictionaries have the same value.

    Parameters
    ----------
    list_of_dicts : list of dict
        A list of dictionaries.

    Returns
    -------
    bool
        True if all common keys have the same value across all dictionaries, False otherwise.
    """
    common_keys = set.intersection(*(set(d.keys()) for d in list_of_dicts))
    return all(len({d[k] for d in list_of_dicts if k in d}) == 1 for k in common_keys)


LocT = TypeVar(
    "LocT",
    "Dataset",
    "Variable",
    "LinearExpression",
    "QuadraticExpression",
    "ConstraintBase",
)


class LocIndexer(Generic[LocT]):
    __slots__ = ("object",)
    object: LocT

    def __init__(self, obj: LocT) -> None:
        self.object = obj

    def __getitem__(
        self, key: dict[Hashable, Any] | tuple | slice | int | list
    ) -> LocT:
        if not is_dict_like(key):
            # expand the indexer so we can handle Ellipsis
            labels = indexing.expanded_indexer(key, self.object.ndim)
            key = dict(zip(self.object.dims, labels))
        return self.object.sel(key)  # type: ignore[attr-defined]


class EmptyDeprecationWrapper:
    """
    Temporary wrapper for a smooth transition from .empty() to .empty

    Use `bool(expr.empty)` to explicitly unwrap.

    See Also
    --------
    https://github.com/PyPSA/linopy/pull/425
    """

    __slots__ = ("value",)

    def __init__(self, value: bool):
        self.value = value

    def __bool__(self) -> bool:
        return self.value

    def __repr__(self) -> str:
        return repr(self.value)

    def __call__(self) -> bool:
        warn(
            "Calling `.empty()` is deprecated, use `.empty` property instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.value


def coords_to_dataset_vars(coords: list[pd.Index]) -> dict[str, DataArray]:
    """
    Serialize a list of pd.Index (including MultiIndex) to a DataArray dict.

    Suitable for embedding coordinate metadata as plain data variables in a
    Dataset that has its own unrelated dimensions (e.g. CSR netcdf format).
    The variables are named by position, never by the (possibly dashed)
    dimension or level names, since the netcdf reader splits variable names
    on ``-``; the level names of a MultiIndex are stored as a JSON attribute.
    Reconstruct with :func:`coords_from_dataset`.
    """
    data_vars: dict[str, DataArray] = {}
    for i, c in enumerate(coords):
        if isinstance(c, pd.MultiIndex):
            for j, level_values in enumerate(c.levels):
                data_vars[f"_index{i}_level{j}"] = DataArray(
                    np.array(level_values), dims=[f"_indexdim{i}_level{j}"]
                )
            data_vars[f"_index{i}_codes"] = DataArray(
                np.array(c.codes).T,
                dims=[f"_indexdim{i}", f"_indexdim{i}_nlevels"],
                attrs={"level_names": json.dumps([str(n) for n in c.names])},
            )
        else:
            data_vars[f"_index{i}"] = DataArray(np.array(c), dims=[f"_indexdim{i}"])
    return data_vars


def coords_from_dataset(ds: Dataset, coord_dims: list[str]) -> list[pd.Index]:
    """
    Deserialize a list of pd.Index (including MultiIndex) from a Dataset.

    Reconstructs coordinates previously serialized by :func:`coords_to_dataset_vars`,
    or by its earlier name-keyed format (``_coord_<dim>``).
    """
    coords = []
    for i, d in enumerate(coord_dims):
        if f"_index{i}_codes" in ds:
            codes = ds[f"_index{i}_codes"]
            level_names = json.loads(codes.attrs["level_names"])
            level_keys = [f"_index{i}_level{j}" for j in range(len(level_names))]
            coords.append(_multiindex(ds, codes.values.T, level_keys, level_names, d))
        elif f"_index{i}" in ds:
            coords.append(pd.Index(ds[f"_index{i}"].values, name=d))
        elif f"_coord_{d}_codes" in ds:
            prefix = f"_coord_{d}_level_"
            level_names = [
                str(k)[len(prefix) :] for k in ds if str(k).startswith(prefix)
            ]
            level_keys = [prefix + ln for ln in level_names]
            codes_2d = ds[f"_coord_{d}_codes"].values.T
            coords.append(_multiindex(ds, codes_2d, level_keys, level_names, d))
        else:
            coords.append(pd.Index(ds[f"_coord_{d}"].values, name=d))
    return coords


def _multiindex(
    ds: Dataset,
    codes_2d: np.ndarray,
    level_keys: list[str],
    level_names: list[str],
    name: str,
) -> pd.MultiIndex:
    arrays = [ds[k].values[codes_2d[j]] for j, k in enumerate(level_keys)]
    mi = pd.MultiIndex.from_arrays(arrays, names=level_names)
    mi.name = name
    return mi


def is_constant(x: SideLike) -> bool:
    """
    Check if the given object is a constant type or an expression type without
    any variables.

    Note that an expression such as ``x - x + 1`` will evaluate to ``False`` as
    the expression is not simplified before evaluation.

    Parameters
    ----------
    x : SideLike
        The object to check.

    Returns
    -------
    bool
        True if the object is constant-like, False otherwise.
    """
    from linopy.expressions import (
        LinearExpression,
        QuadraticExpression,
    )
    from linopy.variables import ScalarVariable, Variable

    if isinstance(x, Variable | ScalarVariable):
        return False
    if isinstance(x, LinearExpression | QuadraticExpression):
        return x.is_constant
    if isinstance(x, CONSTANT_TYPES):
        return True
    raise TypeError(
        "Expected a constant, variable, or expression on the constraint side, "
        f"got {type(x)}."
    )


def values_to_lookup_array(
    values: np.ndarray, labels: np.ndarray, size: int | None = None
) -> np.ndarray:
    """
    Build a dense NaN-padded lookup array from values and integer labels.

    Non-negative labels are placed at their corresponding positions; negative
    labels are skipped. Gaps are filled with NaN.

    Parameters
    ----------
    values : np.ndarray
        Values to place into the lookup array.
    labels : np.ndarray
        Integer labels giving the target position for each value.
    size : int, optional
        Length of the returned array. Defaults to ``max(labels) + 1`` if any
        non-negative label is present, otherwise 0.

    Returns
    -------
    np.ndarray
        Dense float lookup array.
    """
    labels = np.asarray(labels, dtype=int)
    mask = labels >= 0
    if size is None:
        size = int(labels[mask].max()) + 1 if mask.any() else 0
    arr = np.full(size, nan, dtype=float)
    arr[labels[mask]] = values[mask]
    return arr


def coords_ascend(coords: np.ndarray) -> bool:
    """Whether ``coords`` are real numbers in strictly ascending order."""
    return bool(coords.dtype.kind in "iuf" and np.all(coords[1:] > coords[:-1]))


def coords_reorder_set(coords: np.ndarray) -> bool:
    """
    Whether ``coords`` order a set differently than the order it is declared in.

    Ascending coords state the declared order and descending ones reverse it,
    which leaves which members are adjacent unchanged. Non-numeric coords state
    no order at all.
    """
    if coords.dtype.kind not in "iuf":
        return False
    return not (coords_ascend(coords) or coords_ascend(coords[::-1]))


def sos_weights(coords: np.ndarray) -> np.ndarray:
    """
    SOS member weights stating the order ``coords`` is declared in.

    Ascending coords already state it and are passed through, which keeps the LP
    file unchanged. Anything else is weighted by position.
    """
    if coords_ascend(coords):
        return coords
    return np.arange(coords.size)
