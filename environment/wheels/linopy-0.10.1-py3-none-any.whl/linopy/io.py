#!/usr/bin/env python3
"""
Module containing all import/export functionalities.
"""

from __future__ import annotations

import copy as _copy
import json
import logging
import shutil
import time
import warnings
from collections.abc import Callable, Iterable
from dataclasses import replace
from importlib.metadata import version
from io import BufferedWriter
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, TypeVar

import numpy as np
import pandas as pd
import polars as pl
import scipy.sparse
import xarray as xr
from tqdm import tqdm

from linopy import solvers
from linopy.common import (
    sos_weights,
    to_polars,
)
from linopy.constants import CONCAT_DIM, FACTOR_DIM, SOS_DIM_ATTR, SOS_TYPE_ATTR
from linopy.objective import Objective, linear_part
from linopy.scaling import constraint_scaling_lookup, variable_scaling_lookup

Buffer = TypeVar("Buffer", np.ndarray, scipy.sparse.sparray)

if TYPE_CHECKING:
    from cuopt.linear_programming import DataModel as cuoptDataModel
    from cupdlpx import Model as cupdlpxModel
    from highspy.highs import Highs

    from linopy.model import Model
    from linopy.variables import Variable


logger = logging.getLogger(__name__)

NETCDF_VERSION_ATTR = "_linopy_version"
EXPR_TYPE_ATTR = "_linopy_expr_type"
CONTAINER_ORDER_ATTR = "_linopy_{}_order"


ufunc_kwargs = dict(vectorize=True)
concat_kwargs = dict(dim=CONCAT_DIM, coords="minimal")

TQDM_COLOR = "#80bfff"


name_sanitizer = str.maketrans("-+*^[] ", "_______")


def clean_name(name: str) -> str:
    return name.translate(name_sanitizer)


coord_sanitizer = str.maketrans("[,]", "(,)", " ")


def _format_and_write(
    df: pl.DataFrame, columns: list[pl.Expr], f: BufferedWriter
) -> None:
    """
    Format columns via concat_str and write to file.

    Uses Polars streaming engine for better memory efficiency.
    """
    df.lazy().select(pl.concat_str(columns, ignore_nulls=True)).collect(
        engine="streaming"
    ).write_csv(
        f, separator=" ", null_value="", quote_style="never", include_header=False
    )


def signed_number(expr: pl.Expr) -> tuple[pl.Expr, pl.Expr]:
    """
    Return polars expressions for a signed number string, handling -0.0 correctly.

    Parameters
    ----------
    expr : pl.Expr
        Numeric value

    Returns
    -------
    tuple[pl.Expr, pl.Expr]
        value_string with sign
    """
    return (
        pl.when(expr >= 0).then(pl.lit("+")).otherwise(pl.lit("")),
        pl.when(expr == 0).then(pl.lit("0.0")).otherwise(expr.cast(pl.String)),
    )


def _lookup_positive_labels(lookup: np.ndarray, labels: np.ndarray) -> np.ndarray:
    """Return lookup values for non-negative labels, using 1 for sentinels/nulls."""
    labels = np.asarray(labels).reshape(-1)
    values = np.ones(len(labels), dtype=float)
    valid = ~pd.isna(labels)
    if not valid.any():
        return values
    valid_labels = labels[valid].astype(np.intp, copy=False)
    positive = valid_labels >= 0
    valid_positions = np.flatnonzero(valid)
    if positive.any():
        values[valid_positions[positive]] = lookup[valid_labels[positive]]
    return values


def _non_identity(lookup: np.ndarray) -> np.ndarray | None:
    """Return the scaling lookup, or None if all factors are 1."""
    return None if (lookup == 1).all() else lookup


def _scale_objective_dataframe(
    df: pl.DataFrame, variable_scaling: np.ndarray | None, objective_scaling: float
) -> pl.DataFrame:
    """Apply column scaling and row-like objective scaling to objective terms."""
    if df.is_empty():
        return df

    if variable_scaling is not None:
        if "vars" in df.columns:
            scales = _lookup_positive_labels(variable_scaling, df["vars"].to_numpy())
        else:
            scale1 = _lookup_positive_labels(variable_scaling, df["vars1"].to_numpy())
            scale2 = _lookup_positive_labels(variable_scaling, df["vars2"].to_numpy())
            scales = scale1 * scale2
        df = df.with_columns(pl.col("coeffs") / pl.Series(scales))

    if objective_scaling != 1:
        df = df.with_columns(pl.col("coeffs") * objective_scaling)
    return df


def _scale_bounds_dataframe(
    df: pl.DataFrame, variable_scaling: np.ndarray
) -> pl.DataFrame:
    """Multiply bounds by solver-side variable scaling factors."""
    if df.is_empty():
        return df
    scales = _lookup_positive_labels(variable_scaling, df["labels"].to_numpy())
    scale_series = pl.Series(scales)
    return df.with_columns(
        (pl.col("lower") * scale_series).alias("lower"),
        (pl.col("upper") * scale_series).alias("upper"),
    )


def _scale_constraint_dataframe(
    df: pl.DataFrame,
    variable_scaling: np.ndarray | None,
    constraint_scaling: np.ndarray | None,
) -> pl.DataFrame:
    """Divide by column scaling and multiply by row scaling."""
    if variable_scaling is not None:
        var_scales = _lookup_positive_labels(variable_scaling, df["vars"].to_numpy())
        df = df.with_columns(pl.col("coeffs") / pl.Series(var_scales))
    if constraint_scaling is not None:
        row_scales = _lookup_positive_labels(
            constraint_scaling, df["labels"].to_numpy()
        )
        row_scale_series = pl.Series(row_scales)
        df = df.with_columns(
            pl.col("coeffs") * row_scale_series, pl.col("rhs") * row_scale_series
        )
    return df


def format_coord(coord: str) -> str:
    from linopy.common import format_coord

    coord = format_coord(coord).translate(coord_sanitizer)
    return coord


def get_printers_scalar(
    m: Model, explicit_coordinate_names: bool = False
) -> tuple[Callable, Callable]:
    """
    Get batch printer functions for numpy label arrays (non-polars).

    Returns two callables that take an int64 numpy array of labels and return
    a list of name strings.
    """
    if explicit_coordinate_names:

        def _fmt_var(var: Any) -> str:
            name, coord = m.variables.get_label_position(var)
            name = clean_name(name)
            return f"{name}{format_coord(coord)}#{var}"

        def _fmt_con(cons: Any) -> str:
            name, coord = m.constraints.get_label_position(cons)
            name = clean_name(name)  # type: ignore
            return f"{name}{format_coord(coord)}#{cons}"  # type: ignore

        def print_variables(labels: np.ndarray) -> list[str]:
            return np.vectorize(_fmt_var)(labels).tolist()

        def print_constraints(labels: np.ndarray) -> list[str]:
            return np.vectorize(_fmt_con)(labels).tolist()

        return print_variables, print_constraints
    else:

        def print_variables(labels: np.ndarray) -> list[str]:
            return ("x" + pl.Series(labels).cast(pl.String)).to_list()

        def print_constraints(labels: np.ndarray) -> list[str]:
            return ("c" + pl.Series(labels).cast(pl.String)).to_list()

        return print_variables, print_constraints


def get_printers(
    m: Model, explicit_coordinate_names: bool = False
) -> tuple[Callable, Callable]:
    """Get printer functions for polars dataframes."""
    if explicit_coordinate_names:

        def print_variable(var: Any) -> str:
            name, coord = m.variables.get_label_position(var)
            name = clean_name(name)
            return f"{name}{format_coord(coord)}#{var}"

        def print_constraint(cons: Any) -> str:
            name, coord = m.constraints.get_label_position(cons)
            name = clean_name(name)  # type: ignore
            return f"{name}{format_coord(coord)}#{cons}"  # type: ignore

        def print_variable_series(series: pl.Series) -> tuple[pl.Expr, pl.Series]:
            return pl.lit(" "), series.map_elements(
                print_variable, return_dtype=pl.String
            )

        def print_constraint_series(series: pl.Series) -> tuple[pl.Expr, pl.Series]:
            return pl.lit(None), series.map_elements(
                print_constraint, return_dtype=pl.String
            )

        return print_variable_series, print_constraint_series

    else:

        def print_variable_series(series: pl.Series) -> tuple[pl.Expr, pl.Series]:
            return pl.lit(" x").alias("x"), series.cast(pl.String)

        def print_constraint_series(series: pl.Series) -> tuple[pl.Expr, pl.Series]:
            return pl.lit("c").alias("c"), series.cast(pl.String)

        return print_variable_series, print_constraint_series


def objective_write_linear_terms(
    f: BufferedWriter, df: pl.DataFrame, print_variable: Callable
) -> None:
    cols = [
        *signed_number(pl.col("coeffs")),
        *print_variable(pl.col("vars")),
    ]
    _format_and_write(df, cols, f)


def objective_write_quadratic_terms(
    f: BufferedWriter, df: pl.DataFrame, print_variable: Callable
) -> None:
    cols = [
        *signed_number(pl.col("coeffs").mul(2)),
        *print_variable(pl.col("vars1")),
        pl.lit(" *"),
        *print_variable(pl.col("vars2")),
    ]
    f.write(b"+ [\n")
    _format_and_write(df, cols, f)
    f.write(b"] / 2\n")


def objective_to_file(
    m: Model,
    f: BufferedWriter,
    variable_scaling: np.ndarray | None,
    progress: bool = False,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write out the objective of a model to a lp file.
    """
    if progress:
        logger.info("Writing objective.")

    print_variable, _ = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    sense = m.objective.sense
    f.write(f"{sense}\n\nobj:\n\n".encode())
    df = m.objective.to_polars()

    if m.is_linear:
        df = _scale_objective_dataframe(df, variable_scaling, m.objective.scaling)
        objective_write_linear_terms(f, df, print_variable)

    elif m.is_quadratic:
        df = _scale_objective_dataframe(df, variable_scaling, m.objective.scaling)
        objective_write_linear_terms(f, linear_part(df), print_variable)

        quads = df.filter(pl.col("vars1").ne(-1) & pl.col("vars2").ne(-1))
        objective_write_quadratic_terms(f, quads, print_variable)


def _binary_has_nondefault_bounds(var: Variable) -> bool:
    """
    Whether a binary variable carries bounds other than the implied (0, 1).

    Scans the raw bound values (a single vectorised pass each), so masked
    slots are tolerated: a false positive only routes the variable through
    the bounds loop, where masked labels are dropped before writing.
    """
    return bool((var.lower.values != 0).any() or (var.upper.values != 1).any())


def bounds_to_file(
    m: Model,
    f: BufferedWriter,
    variable_scaling: np.ndarray | None,
    progress: bool = False,
    slice_size: int = 2_000_000,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write out variables of a model to a lp file.
    """
    names = (
        list(m.variables.continuous)
        + list(m.variables.integers)
        + list(m.variables.semi_continuous)
        + [
            n
            for n in m.variables.binaries
            if _binary_has_nondefault_bounds(m.variables[n])
        ]
    )
    if not len(list(names)):
        return

    print_variable, _ = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    f.write(b"\n\nbounds\n\n")
    if progress:
        names = tqdm(
            list(names),
            desc="Writing continuous variables.",
            colour=TQDM_COLOR,
        )

    for name in names:
        var = m.variables[name]
        for var_slice in var.iterate_slices(slice_size):
            df = var_slice.to_polars()
            if variable_scaling is not None:
                df = _scale_bounds_dataframe(df, variable_scaling)

            columns = [
                *signed_number(pl.col("lower")),
                pl.lit(" <= "),
                *print_variable(pl.col("labels")),
                pl.lit(" <= "),
                *signed_number(pl.col("upper")),
            ]

            _format_and_write(df, columns, f)


def binaries_to_file(
    m: Model,
    f: BufferedWriter,
    progress: bool = False,
    slice_size: int = 2_000_000,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write out binaries of a model to a lp file.
    """
    names = m.variables.binaries
    if not len(list(names)):
        return

    print_variable, _ = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    f.write(b"\n\nbinary\n\n")
    if progress:
        names = tqdm(
            list(names),
            desc="Writing binary variables.",
            colour=TQDM_COLOR,
        )

    for name in names:
        var = m.variables[name]
        for var_slice in var.iterate_slices(slice_size):
            df = var_slice.to_polars()

            columns = [
                *print_variable(pl.col("labels")),
            ]

            _format_and_write(df, columns, f)


def semi_continuous_to_file(
    m: Model,
    f: BufferedWriter,
    progress: bool = False,
    slice_size: int = 2_000_000,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write out semi-continuous variables of a model to a lp file.
    """
    names = m.variables.semi_continuous
    if not len(list(names)):
        return

    print_variable, _ = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    f.write(b"\n\nsemi-continuous\n\n")
    if progress:
        names = tqdm(
            list(names),
            desc="Writing semi-continuous variables.",
            colour=TQDM_COLOR,
        )

    for name in names:
        var = m.variables[name]
        for var_slice in var.iterate_slices(slice_size):
            df = var_slice.to_polars()

            columns = [
                *print_variable(pl.col("labels")),
            ]

            _format_and_write(df, columns, f)


def integers_to_file(
    m: Model,
    f: BufferedWriter,
    progress: bool = False,
    integer_label: str = "general",
    slice_size: int = 2_000_000,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write out integers of a model to a lp file.
    """
    names = m.variables.integers
    if not len(list(names)):
        return

    print_variable, _ = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    f.write(f"\n\n{integer_label}\n\n".encode())
    if progress:
        names = tqdm(
            list(names),
            desc="Writing integer variables.",
            colour=TQDM_COLOR,
        )

    for name in names:
        var = m.variables[name]
        for var_slice in var.iterate_slices(slice_size):
            df = var_slice.to_polars()

            columns = [
                *print_variable(pl.col("labels")),
            ]

            _format_and_write(df, columns, f)


def sos_to_file(
    m: Model,
    f: BufferedWriter,
    progress: bool = False,
    slice_size: int = 2_000_000,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write out SOS constraints of a model to an LP file.
    """
    names = m.variables.sos
    if not len(list(names)):
        return

    print_variable, _ = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    f.write(b"\n\nsos\n\n")
    if progress:
        names = tqdm(
            list(names),
            desc="Writing sos constraints.",
            colour=TQDM_COLOR,
        )

    for name in names:
        var = m.variables[name]
        sos_type = int(var.attrs[SOS_TYPE_ATTR])  # type: ignore[call-overload]
        sos_dim = str(var.attrs[SOS_DIM_ATTR])

        other_dims = [dim for dim in var.labels.dims if dim != sos_dim]
        weights = sos_weights(var.coords[sos_dim].values)
        for var_slice in var.iterate_slices(slice_size, other_dims):
            ds = var_slice.labels.to_dataset()
            # Per-set id = max member label: unique per set (labels are globally
            # unique); a fully-masked set reduces to -1 and is dropped below.
            ds["sos_labels"] = ds["labels"].max(sos_dim)
            ds["weights"] = ((sos_dim,), weights)
            df = to_polars(ds)

            # Drop masked members
            df = df.filter((pl.col("labels") != -1) & (pl.col("sos_labels") != -1))
            if df.is_empty():
                continue

            df = df.group_by("sos_labels").agg(
                pl.concat_str(
                    *print_variable(pl.col("labels")), pl.lit(":"), pl.col("weights")
                )
                .str.join(" ")
                .alias("var_weights")
            )

            columns = [
                pl.lit("s"),
                pl.col("sos_labels"),
                pl.lit(f": S{sos_type} :: "),
                pl.col("var_weights"),
            ]

            _format_and_write(df, columns, f)


def indicator_constraints_to_file(
    m: Model,
    f: BufferedWriter,
    variable_scaling: np.ndarray,
    explicit_coordinate_names: bool = False,
) -> None:
    """
    Write indicator constraints to the s.t. section of an LP file.

    Indicator constraints appear in the Subject To section with the format:
    ``ic0: x0 = 1 -> +1.0 x1 <= 5.0``
    """
    if not len(m.constraints.indicator):
        return

    if not len(m.constraints.regular):
        f.write(b"\n\ns.t.\n\n")

    print_variable_scalar, _ = get_printers_scalar(
        m, explicit_coordinate_names=explicit_coordinate_names
    )

    for con in m.constraints.indicator.data.values():
        ic_data = con.data
        labels_flat = ic_data.labels.values.flatten()
        binary_var_flat = ic_data.binary_var.values.flatten()
        binary_val_flat = np.broadcast_to(
            ic_data.binary_val.values, labels_flat.shape
        ).flatten()
        coeffs_flat = ic_data.coeffs.values.reshape(len(labels_flat), -1)
        vars_flat = ic_data.vars.values.reshape(len(labels_flat), -1)
        sign_flat = np.broadcast_to(ic_data.sign.values, labels_flat.shape).flatten()
        rhs_flat = np.broadcast_to(ic_data.rhs.values, labels_flat.shape).flatten()
        scaling_flat = np.broadcast_to(
            ic_data.scaling.values, labels_flat.shape
        ).flatten()

        for i in range(len(labels_flat)):
            if labels_flat[i] == -1:
                continue

            row_scale = float(scaling_flat[i])
            bvar_name = print_variable_scalar(binary_var_flat[i : i + 1])[0]
            valid = vars_flat[i] != -1
            var_names = print_variable_scalar(vars_flat[i][valid])

            terms = []
            for coeff, var_label, var_name in zip(
                coeffs_flat[i][valid], vars_flat[i][valid], var_names
            ):
                coeff = float(coeff) / variable_scaling[int(var_label)] * row_scale
                prefix = "+" if coeff >= 0 else ""
                terms.append(f"{prefix}{coeff} {var_name}")

            lhs_str = " ".join(terms)
            line = (
                f"ic{labels_flat[i]}: {bvar_name} = {int(binary_val_flat[i])} -> "
                f"{lhs_str} {sign_flat[i]} {float(rhs_flat[i]) * row_scale}\n"
            )
            f.write(line.encode())


def constraints_to_file(
    m: Model,
    f: BufferedWriter,
    variable_scaling: np.ndarray | None,
    constraint_scaling: np.ndarray | None,
    progress: bool = False,
    lazy: bool = False,
    slice_size: int = 2_000_000,
    explicit_coordinate_names: bool = False,
) -> None:
    regular = m.constraints.regular
    if not len(regular):
        return

    print_variable, print_constraint = get_printers(
        m, explicit_coordinate_names=explicit_coordinate_names
    )
    scaled = variable_scaling is not None or constraint_scaling is not None

    f.write(b"\n\ns.t.\n\n")
    names = list(regular)
    if progress:
        names = tqdm(
            names,
            desc="Writing constraints.",
            colour=TQDM_COLOR,
        )

    for name in names:
        con = regular[name]
        for con_slice in con.iterate_slices(slice_size):
            df = con_slice.to_polars()
            if df.height == 0:
                continue
            if scaled:
                df = _scale_constraint_dataframe(
                    df, variable_scaling, constraint_scaling
                )
            if not df["labels"].is_sorted():
                df = df.sort("labels", maintain_order=True)
            _write_constraint_rows(df, f, print_constraint, print_variable)


def _write_constraint_rows(
    df: pl.DataFrame,
    f: BufferedWriter,
    print_constraint: Callable,
    print_variable: Callable,
) -> None:
    labels = df["labels"].to_numpy()
    first = np.empty(len(labels), dtype=bool)
    first[0] = True
    np.not_equal(labels[1:], labels[:-1], out=first[1:])
    last = np.append(first[1:], True)
    columns = [
        pl.when(pl.Series(first)).then(
            pl.concat_str(
                [*print_constraint(pl.col("labels")), pl.lit(":\n")],
                ignore_nulls=True,
            )
        ),
        *signed_number(pl.col("coeffs")),
        *print_variable(pl.col("vars")),
        pl.when(pl.Series(last)).then(
            pl.concat_str(
                [
                    pl.lit("\n"),
                    pl.col("sign"),
                    pl.lit(" "),
                    pl.col("rhs").cast(pl.String),
                ]
            )
        ),
    ]
    _format_and_write(df, columns, f)


def to_lp_file(
    m: Model,
    fn: Path,
    integer_label: str = "general",
    slice_size: int = 2_000_000,
    progress: bool = True,
    explicit_coordinate_names: bool = False,
) -> None:
    with open(fn, mode="wb") as f:
        start = time.time()
        variable_scaling = variable_scaling_lookup(m)
        active_variable_scaling = _non_identity(variable_scaling)

        objective_to_file(
            m,
            f,
            active_variable_scaling,
            progress=progress,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        constraints_to_file(
            m,
            f=f,
            variable_scaling=active_variable_scaling,
            constraint_scaling=_non_identity(constraint_scaling_lookup(m)),
            progress=progress,
            slice_size=slice_size,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        indicator_constraints_to_file(
            m,
            f=f,
            variable_scaling=variable_scaling,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        bounds_to_file(
            m,
            f=f,
            variable_scaling=active_variable_scaling,
            progress=progress,
            slice_size=slice_size,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        binaries_to_file(
            m,
            f=f,
            progress=progress,
            slice_size=slice_size,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        integers_to_file(
            m,
            integer_label=integer_label,
            f=f,
            progress=progress,
            slice_size=slice_size,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        semi_continuous_to_file(
            m,
            f=f,
            progress=progress,
            slice_size=slice_size,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        sos_to_file(
            m,
            f=f,
            progress=progress,
            slice_size=slice_size,
            explicit_coordinate_names=explicit_coordinate_names,
        )
        f.write(b"end\n")

        logger.info(f" Writing time: {round(time.time() - start, 2)}s")


def to_file(
    m: Model,
    fn: Path | str | None,
    io_api: str | None = None,
    integer_label: str = "general",
    slice_size: int = 2_000_000,
    progress: bool | None = None,
    explicit_coordinate_names: bool = False,
) -> Path:
    """
    Write out a model to a lp or mps file.
    """
    if fn is None:
        fn = Path(m.get_problem_file())
    if isinstance(fn, str):
        fn = Path(fn)
    if fn.exists():
        fn.unlink()

    if io_api is None:
        io_api = fn.suffix[1:]

    if progress is None:
        progress = m._xCounter > 10_000

    if io_api == "lp" or io_api == "lp-polars":
        to_lp_file(
            m,
            fn,
            integer_label,
            slice_size=slice_size,
            progress=progress,
            explicit_coordinate_names=explicit_coordinate_names,
        )

    elif io_api == "mps":
        if "highs" not in solvers.available_solvers:
            raise RuntimeError(
                "Package highspy not installed. This is required to exporting to MPS file."
            )

        # Use very fast highspy implementation
        # Might be replaced by custom writer, however needs C/Rust bindings for performance
        h = solvers.Highs._build_solver_model(
            m, explicit_coordinate_names=explicit_coordinate_names, set_names=True
        )
        h.writeModel(str(fn))
    else:
        raise ValueError(
            f"Invalid io_api '{io_api}'. Choose from 'lp', 'lp-polars' or 'mps'."
        )

    return fn


def to_mosek(
    m: Model,
    task: Any | None = None,
    explicit_coordinate_names: bool = False,
    set_names: bool | None = None,
) -> Any:
    """Build the MOSEK task for `m`."""
    import mosek

    solver = solvers.Mosek.from_model(
        m,
        io_api="direct",
        explicit_coordinate_names=explicit_coordinate_names,
        set_names=set_names,
        task=mosek.Task() if task is None else task,
    )
    return solver._detach_solver_model()


def to_gurobipy(
    m: Model,
    env: Any | None = None,
    explicit_coordinate_names: bool = False,
    set_names: bool | None = None,
) -> Any:
    """Build the gurobipy.Model for `m`."""
    solver = solvers.Gurobi.from_model(
        m,
        io_api="direct",
        explicit_coordinate_names=explicit_coordinate_names,
        set_names=set_names,
        env=env,
    )
    return solver._detach_solver_model()


def to_highspy(
    m: Model,
    explicit_coordinate_names: bool = False,
    set_names: bool | None = None,
) -> Highs:
    """Build the highspy.Highs instance for `m`."""
    solver = solvers.Highs.from_model(
        m,
        io_api="direct",
        explicit_coordinate_names=explicit_coordinate_names,
        set_names=set_names,
    )
    return solver.solver_model


def to_xpress(
    m: Model,
    explicit_coordinate_names: bool = False,
    set_names: bool | None = None,
) -> Any:
    """Build the xpress.problem instance for `m`."""
    solver = solvers.Xpress.from_model(
        m,
        io_api="direct",
        explicit_coordinate_names=explicit_coordinate_names,
        set_names=set_names,
    )
    return solver._detach_solver_model()


def to_cupdlpx(m: Model) -> cupdlpxModel:
    """Build the cupdlpx.Model for `m`."""
    solver = solvers.cuPDLPx.from_model(m, io_api="direct")
    return solver.solver_model


def to_cuopt(m: Model) -> cuoptDataModel:
    """
    Build the cuopt DataModel for `m`.

    For a maximisation model the returned DataModel is the equivalent
    minimisation (negated objective coefficients, `maximize` unset); see
    :class:`linopy.solvers.cuOpt`.
    """
    solver = solvers.cuOpt.from_model(m, io_api="direct")
    return solver.solver_model


def to_block_files(m: Model, fn: Path) -> None:
    """
    Write out the linopy model to a block structured output.

    Experimental: This function does not support grouping duplicated variables
    in one constraint row yet!
    """
    if fn is None:
        fn = Path(TemporaryDirectory(prefix="linopy-problem-", dir=m.solver_dir).name)

    path = Path(fn)
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(exist_ok=True)

    m.calculate_block_maps()

    if m.blocks is None:
        raise ValueError("Model does not have blocks defined.")

    N = int(m.blocks.max())
    for n in range(N + 2):
        (path / f"block{n}").mkdir()

    raise NotImplementedError("This function is not yet implemented fully.")

    # # Write out variables
    # blocks = vars.ravel("blocks", filter_missings=True)
    # for key, suffix in zip(["labels", "lower", "upper"], ["x", "xl", "xu"]):
    #     arr = vars.ravel(key, filter_missings=True)
    #     for n in tqdm(range(N + 1), desc=f"Write variable {key}"):
    #         arr[blocks == n].tofile(path / f"block{n}" / suffix, sep="\n")

    # # Write out objective (uses variable blocks from above)
    # coeffs = np.zeros(m._xCounter)
    # coeffs[np.asarray(m.objective.vars)] = np.asarray(m.objective.coeffs)
    # # reorder like non-missing variables
    # coeffs = coeffs[vars.ravel("labels", filter_missings=True)]
    # for n in tqdm(range(N + 1), desc="Write objective"):
    #     coeffs[blocks == n].tofile(path / f"block{n}" / "c", sep="\n")

    # # Write out rhs
    # blocks = cons.ravel("blocks", filter_missings=True)
    # rhs = cons.ravel("rhs", filter_missings=True)
    # is_equality = cons.ravel(cons.sign == EQUAL, filter_missings=True)
    # is_lower_bound = cons.ravel(cons.sign == GREATER_EQUAL, filter_missings=True)

    # for n in tqdm(range(N + 2), desc="Write RHS"):
    #     is_blockn = blocks == n

    #     rhs[is_blockn & is_equality].tofile(path / f"block{n}" / "b", sep="\n")

    #     not_equality = is_blockn & ~is_equality
    #     is_lower_bound_sub = is_lower_bound[not_equality]
    #     rhs_sub = rhs[not_equality]

    #     lower_bound = np.where(is_lower_bound_sub, rhs_sub, -np.inf)
    #     lower_bound.tofile(path / f"block{n}" / "dl", sep="\n")

    #     upper_bound = np.where(~is_lower_bound_sub, rhs_sub, np.inf)
    #     upper_bound.tofile(path / f"block{n}" / "du", sep="\n")

    # # Write out constraints
    # conblocks = cons.ravel("blocks", "vars", filter_missings=True)
    # varblocks = cons.ravel("var_blocks", "vars", filter_missings=True)
    # is_equality = cons.ravel(cons.sign == EQUAL, "vars", filter_missings=True)

    # is_varblock_0 = varblocks == 0
    # is_conblock_L = conblocks == N + 1

    # keys = ["labels", "coeffs", "vars"]

    # def filtered(arr, mask, key):
    #     """
    #     Set coefficients to zero where mask is False, keep others unchanged.

    #     PIPS requires this information to set the shape of sub-matrices.
    #     """
    #     assert key in keys
    #     return np.where(mask, arr, 0) if key == "coeffs" else arr

    # for key, suffix in zip(keys, ["row", "data", "col"]):
    #     arr = cons.ravel(key, "vars", filter_missings=True)
    #     for n in tqdm(range(N + 1), desc=f"Write constraint {key}"):
    #         is_conblock_n = conblocks == n
    #         is_varblock_n = varblocks == n

    #         mask = is_conblock_n & is_equality
    #         filtered(arr[mask], is_varblock_0[mask], key).tofile(
    #             path / f"block{n}" / f"A_{suffix}", sep="\n"
    #         )
    #         mask = is_conblock_n & ~is_equality
    #         filtered(arr[mask], is_varblock_0[mask], key).tofile(
    #             path / f"block{n}" / f"C_{suffix}", sep="\n"
    #         )

    #         mask = is_conblock_L & is_equality
    #         filtered(arr[mask], is_varblock_n[mask], key).tofile(
    #             path / f"block{n}" / f"BL_{suffix}", sep="\n"
    #         )
    #         mask = is_conblock_L & ~is_equality
    #         filtered(arr[mask], is_varblock_n[mask], key).tofile(
    #             path / f"block{n}" / f"DL_{suffix}", sep="\n"
    #         )

    #         if n:
    #             mask = is_conblock_n & is_equality
    #             filtered(arr[mask], is_varblock_n[mask], key).tofile(
    #                 path / f"block{n}" / f"B_{suffix}", sep="\n"
    #             )
    #             mask = is_conblock_n & ~is_equality
    #             filtered(arr[mask], is_varblock_n[mask], key).tofile(
    #                 path / f"block{n}" / f"D_{suffix}", sep="\n"
    #             )


def non_bool_dict(
    d: dict[str, tuple[int, int] | str | bool | list[str] | int],
) -> dict[str, tuple[int, int] | str | int | list[str]]:
    """
    Convert bool to int for netCDF4 storing.
    """
    return {k: int(v) if isinstance(v, bool) else v for k, v in d.items()}


DEFAULT_NETCDF_COMPRESSION: dict[str, Any] = {"zlib": True, "complevel": 3}


def to_netcdf(
    m: Model, *args: Any, compression: dict[str, Any] | bool = True, **kwargs: Any
) -> None:
    """
    Write out the model to a netcdf file.

    Parameters
    ----------
    m : linopy.Model
        Model to write out.
    *args
        Arguments passed to ``xarray.Dataset.to_netcdf``.
    compression : dict or bool, default True
        Encoding applied to every array in the file. ``True`` applies
        ``{"zlib": True, "complevel": 3}``, ``False`` disables
        compression. It is set as a fallback in each array's
        ``.encoding``.
    **kwargs : TYPE
        Keyword arguments passed to ``xarray.Dataset.to_netcdf``.

    Notes
    -----
    Variables, constraints, the objective, parameters and named
    expressions (``Model.expressions``, including their linear/quadratic
    type) are all persisted and fully restored by
    :func:`linopy.io.read_netcdf`. The insertion order of each container
    is stored as a JSON list in the ``_linopy_<kind>_order`` attribute.

    The SOS reformulation lifecycle token lives only on the in-memory
    Model and is not persisted. If the model has an active SOS
    reformulation at serialization time, the netcdf contains the
    reformulated MILP form (aux binaries and cardinality constraints)
    and a :class:`UserWarning` is emitted to flag that the deserialized
    copy will not be able to undo the reformulation.

    ``Model.solve(remote=...)`` invokes ``to_netcdf`` internally on the
    reformulated model and suppresses this warning.
    """
    if m._sos_reformulation_state is not None:
        warnings.warn(
            "Serializing a model with an active SOS reformulation. The "
            "netcdf will contain the reformulated MILP form; the "
            "reformulation lifecycle token is not persisted, so a "
            "reader cannot undo it. Call `model.undo_sos_reformulation()` "
            "first if you want the original SOS form on disk.",
            UserWarning,
            stacklevel=2,
        )

    def with_prefix(ds: xr.Dataset, prefix: str) -> xr.Dataset:
        to_rename = set([*ds.dims, *ds.coords, *ds])
        ds = ds.rename({d: f"{prefix}-{d}" for d in to_rename})
        ds.attrs = {f"{prefix}-{k}": v for k, v in ds.attrs.items()}

        # Flatten multiindexes
        for dim in ds.dims:
            if isinstance(ds[dim].to_index(), pd.MultiIndex):
                prefix_len = len(prefix) + 1  # leave original index level name
                names = [n[prefix_len:] for n in ds[dim].to_index().names]
                ds = ds.reset_index(dim)
                # scipy netCDF3 backend cannot write unicode-array attrs.
                ds.attrs[f"{dim}_multiindex"] = json.dumps(list(names))

        return ds

    vars = [
        with_prefix(var.data, f"variables-{name}") for name, var in m.variables.items()
    ]
    cons = [
        with_prefix(con.to_netcdf_ds(), f"constraints-{name}")
        for name, con in m.constraints.items()
    ]
    exprs = [
        with_prefix(
            expr.data.assign_attrs(name=name, **{EXPR_TYPE_ATTR: expr.type}),
            f"expressions-{name}",
        )
        for name, expr in m.expressions.items()
    ]
    objective = m.objective.to_netcdf_ds().assign_attrs(
        sense=m.objective.sense,
        scaling=m.objective.scaling,
        **{EXPR_TYPE_ATTR: m.objective.expression.type},
    )
    if m.objective.value is not None:
        objective = objective.assign_attrs(value=m.objective.value)
    obj = [with_prefix(objective, "objective")]
    params = [with_prefix(m.parameters, "parameters")]

    scalars = {k: getattr(m, k) for k in m.scalar_attrs}
    scalars |= {"sparse": m.sparse, "freeze_constraints": m._freeze_constraints}
    ds = xr.merge(vars + cons + exprs + obj + params, combine_attrs="drop_conflicts")
    ds = ds.assign_attrs(scalars)
    ds.attrs[NETCDF_VERSION_ATTR] = version("linopy")
    for kind, container in (
        ("variables", m.variables),
        ("expressions", m.expressions),
        ("constraints", m.constraints),
    ):
        ds.attrs[CONTAINER_ORDER_ATTR.format(kind)] = json.dumps(list(container))
    if m._relaxed_registry:
        ds.attrs["_relaxed_registry"] = json.dumps(m._relaxed_registry)
    if m._piecewise_formulations:
        ds.attrs["_piecewise_formulations"] = json.dumps(
            {
                name: {
                    "method": pwl.method,
                    "variable_names": pwl.variable_names,
                    "constraint_names": pwl.constraint_names,
                    "convexity": pwl.convexity,
                }
                for name, pwl in m._piecewise_formulations.items()
            }
        )
    ds.attrs = non_bool_dict(ds.attrs)

    for k in ds:
        ds[k].attrs = non_bool_dict(ds[k].attrs)

    if compression is True:
        compression = DEFAULT_NETCDF_COMPRESSION
    if compression:
        for v in ds.variables.values():
            v.encoding = compression | v.encoding

    ds.to_netcdf(*args, **kwargs)


def read_netcdf(path: Path | str, **kwargs: Any) -> Model:
    """
    Read in a model from a netcdf file.

    Parameters
    ----------
    path : path_like
        Path of the stored model.
    **kwargs
        Keyword arguments passed to ``xarray.load_dataset``.

    Returns
    -------
    m : linopy.Model

    Notes
    -----
    Variables, expressions and constraints are restored in the insertion
    order stored by :func:`to_netcdf`. Files written by earlier versions
    carry no order and are loaded in sorted name order.

    The SOS reformulation lifecycle token is not persisted by
    :func:`to_netcdf`. If the saved model was in reformulated form,
    the deserialized Model is too, but
    :meth:`Model.undo_sos_reformulation` is a no-op on it.
    """
    from linopy.constraints import (
        Constraint,
        ConstraintBase,
        Constraints,
        CSRConstraint,
    )
    from linopy.expressions import Expressions, LinearExpression, QuadraticExpression
    from linopy.model import Model
    from linopy.variables import Variable, Variables

    if isinstance(path, str):
        path = Path(path)

    ds = xr.load_dataset(path, **kwargs)
    m = Model(sparse=bool(ds.attrs.get("sparse", False)))

    def remove_prefix(k: str, prefix: str) -> str:
        return k[len(prefix) + 1 :]

    def parse_multiindex_attr(value: str | Iterable[str]) -> list[str]:
        # str = JSON (new); iterable = legacy list from older linopy.
        if isinstance(value, str):
            return [str(n) for n in json.loads(value)]
        return [str(n) for n in value]

    def get_prefix(ds: xr.Dataset, prefix: str) -> xr.Dataset:
        ds = ds[[k for k in ds if owners[str(k)] == prefix]]
        ds = ds.drop_vars(
            [c for c in ds.coords if ds[c].ndim == 0 and owners[str(c)] != prefix]
        )
        to_rename = set([*ds.dims, *ds.coords, *ds])
        ds = ds.rename({d: remove_prefix(d, prefix) for d in to_rename})
        ds.attrs = {
            remove_prefix(k, prefix): v
            for k, v in ds.attrs.items()
            if owners[k] == prefix
        }

        for dim in ds.dims:
            if f"{dim}_multiindex" in ds.attrs:
                names = parse_multiindex_attr(ds.attrs.pop(f"{dim}_multiindex"))
                ds = ds.set_index({dim: names})  # type: ignore[dict-item]

        return ds

    def container_names(kind: str) -> list[str]:
        found = {str(k).rsplit("-", 1)[0] for k in ds if str(k).startswith(kind)}
        order_attr = ds.attrs.get(CONTAINER_ORDER_ATTR.format(kind))
        if order_attr is None:
            return sorted(found)
        ordered = [f"{kind}-{name}" for name in json.loads(order_attr)]
        if len(ordered) != len(found) or set(ordered) != found:
            mismatch = sorted(set(ordered) ^ found)
            raise ValueError(
                f"Stored {kind} order does not match the {kind} found in the "
                f"file; mismatching names: {mismatch}."
            )
        return ordered

    containers = {
        kind: container_names(kind)
        for kind in ("variables", "expressions", "constraints")
    }
    prefixes = {"objective", "parameters"}.union(*containers.values())

    def owner(k: str) -> str | None:
        while "-" in k:
            k = k.rsplit("-", 1)[0]
            if k in prefixes:
                return k
        return None

    owners = {k: owner(k) for k in [*map(str, ds.variables), *ds.attrs]}

    variables = {}
    for k in containers["variables"]:
        name = remove_prefix(k, "variables")
        variables[name] = Variable(get_prefix(ds, k), m, name)

    m._variables = Variables(variables, m)

    expressions: dict[str, LinearExpression | QuadraticExpression] = {}
    for k in containers["expressions"]:
        name = remove_prefix(k, "expressions")
        expr_ds = get_prefix(ds, k)
        expr_type = expr_ds.attrs.pop(EXPR_TYPE_ATTR, None)
        expr_ds.attrs.pop("name", None)  # re-attached below, after construction
        expr: LinearExpression | QuadraticExpression
        if expr_type == "QuadraticExpression" or (
            expr_type is None and FACTOR_DIM in expr_ds.dims
        ):
            expr = QuadraticExpression(expr_ds, m)
        else:
            expr = LinearExpression(expr_ds, m)
        expr.attrs["name"] = name
        expressions[name] = expr

    m._expressions = Expressions(expressions, m)

    constraints: dict[str, ConstraintBase] = {}
    for k in containers["constraints"]:
        name = remove_prefix(k, "constraints")
        con_ds = get_prefix(ds, k)
        if con_ds.attrs.get("_linopy_format") == "csr":
            constraints[name] = CSRConstraint.from_netcdf_ds(con_ds, m, name)
        else:
            constraints[name] = Constraint(con_ds, m, name)
    m._constraints = Constraints(constraints, m)

    objective = get_prefix(ds, "objective")
    obj_type = objective.attrs.pop(EXPR_TYPE_ATTR, None)
    obj_cls: type[LinearExpression] | type[QuadraticExpression] = (
        QuadraticExpression
        if obj_type == "QuadraticExpression"
        or (obj_type is None and FACTOR_DIM in objective.dims)
        else LinearExpression
    )
    m.objective = Objective(
        obj_cls(objective, m),
        m,
        objective.attrs.pop("sense"),
        objective.attrs.pop("scaling", 1),
    )
    m.objective._value = objective.attrs.pop("value", None)

    m.parameters = get_prefix(ds, "parameters")

    for k in m.scalar_attrs:
        if k in ds.attrs:
            setattr(m, k, ds.attrs[k])
    m._freeze_constraints = bool(ds.attrs.get("freeze_constraints", False))

    if max(m._xCounter, m._cCounter) > np.iinfo(np.int32).max:
        m._dtypes["labels"] = np.int64

    if "_relaxed_registry" in ds.attrs:
        m._relaxed_registry = json.loads(ds.attrs["_relaxed_registry"])

    if "_piecewise_formulations" in ds.attrs:
        from linopy.piecewise import PiecewiseFormulation

        for name, d in json.loads(ds.attrs["_piecewise_formulations"]).items():
            m._piecewise_formulations[name] = PiecewiseFormulation(
                name=name,
                method=d["method"],
                variable_names=d["variable_names"],
                constraint_names=d["constraint_names"],
                model=m,
                convexity=d["convexity"],
            )

    return m


def copy(m: Model, include_solution: bool = False, deep: bool = True) -> Model:
    """
    Return a copy of this model.

    With ``deep=True`` (default), variables, constraints, objective,
    parameters, blocks, and scalar attributes are copied to a fully
    independent model. With ``deep=False``, returns a shallow copy.

    :meth:`Model.copy` defaults to deep copy for workflow safety.
    In contrast, ``copy.copy(model)`` is shallow via ``__copy__``, and
    ``copy.deepcopy(model)`` is deep via ``__deepcopy__``.

    Solver runtime metadata (for example, ``solver_name`` and
    ``solver_model``) is intentionally not copied. Solver backend state
    is recreated on ``solve()``.

    Parameters
    ----------
    m : Model
        The model to copy.
    include_solution : bool, optional
        Whether to include solution and dual values in the copy.
        If False (default), solve artifacts are excluded: solution/dual data,
        objective value, and solve status are reset to initialized state.
        If True, these values are copied when present. For unsolved models,
        this has no additional effect.
    deep : bool, optional
        Whether to return a deep copy (default) or shallow copy. If False,
        the returned model uses independent wrapper objects that share
        underlying data buffers with the source model.

    Returns
    -------
    Model
        A deep or shallow copy of the model.
    """
    from linopy.constraints import (
        Constraint,
        ConstraintBase,
        Constraints,
        CSRConstraint,
    )
    from linopy.expressions import Expressions, LinearExpression, QuadraticExpression
    from linopy.model import Model, Objective
    from linopy.variables import Variable, Variables

    SOLVE_STATE_ATTRS = {"status", "termination_condition"}

    new_model = Model(
        chunk=m._chunk,
        force_dim_names=m._force_dim_names,
        auto_mask=m._auto_mask,
        set_names_in_solver_io=m.set_names_in_solver_io,
        solver_dir=str(m._solver_dir),
        sparse=m.sparse,
    )

    new_model._variables = Variables(
        {
            name: Variable(
                var.data.copy(deep=deep)
                if include_solution
                else var.data[m.variables.dataset_attrs].copy(deep=deep),
                new_model,
                name,
            )
            for name, var in m.variables.items()
        },
        new_model,
    )

    def _copy_expr(
        name: str, expr: LinearExpression | QuadraticExpression
    ) -> LinearExpression | QuadraticExpression:
        # Expressions hold no solve artifacts, so include_solution is irrelevant.
        new_expr = type(expr)(expr.data.copy(deep=deep), new_model)
        new_expr.attrs["name"] = name  # __init__ resets the name to None
        return new_expr

    new_model._expressions = Expressions(
        {name: _copy_expr(name, expr) for name, expr in m.expressions.items()},
        new_model,
    )

    def _buffer(value: Buffer) -> Buffer:
        return value.copy() if deep else value

    def _copy_con(name: str, con: ConstraintBase) -> ConstraintBase:
        if isinstance(con, CSRConstraint):
            buffer_types = (np.ndarray, scipy.sparse.sparray)
            changes: dict[str, Any] = {"model": new_model}
            if deep:
                kwargs = con._init_kwargs().items()
                changes |= {
                    k: v.copy() for k, v in kwargs if isinstance(v, buffer_types)
                }
            if not include_solution:
                changes["dual"] = None
            return con._replace(**changes)
        d = con.data
        if not include_solution:
            d = d[con.data_attrs]
        return Constraint(d.copy(deep=deep), new_model, name)

    new_model._constraints = Constraints(
        {name: _copy_con(name, con) for name, con in m.constraints.items()},
        new_model,
    )

    expr = m.objective.expression
    csr = expr._csr if isinstance(expr, LinearExpression) else None
    obj_expr = (
        type(expr)(expr.data.copy(deep=deep), new_model)
        if csr is None
        else LinearExpression._from_csr(
            replace(
                csr, csr=_buffer(csr.csr), const=_buffer(csr.const), model=new_model
            ),
            new_model,
        )
    )
    new_model._objective = Objective(
        obj_expr, new_model, m.objective.sense, m.objective.scaling
    )
    new_model._objective._value = (
        float(m.objective.value)
        if (include_solution and m.objective.value is not None)
        else None
    )

    new_model._parameters = m._parameters.copy(deep=deep)
    new_model._blocks = m._blocks.copy(deep=deep) if m._blocks is not None else None

    for attr in m.scalar_attrs:
        if include_solution or attr not in SOLVE_STATE_ATTRS:
            setattr(new_model, attr, getattr(m, attr))
    new_model._freeze_constraints = m._freeze_constraints

    if m._sos_reformulation_state is not None:
        new_model._sos_reformulation_state = _copy.deepcopy(m._sos_reformulation_state)

    return new_model


def shallowcopy(m: Model) -> Model:
    """
    Support Python's ``copy.copy`` protocol for ``Model``.

    Returns a shallow copy with independent wrapper objects that share
    underlying array buffers with ``m``. Solve artifacts are excluded,
    matching :meth:`Model.copy` defaults.
    """
    return copy(m, include_solution=False, deep=False)


def deepcopy(m: Model, memo: dict[int, Any]) -> Model:
    """
    Support Python's ``copy.deepcopy`` protocol for ``Model``.

    Returns a deep, structurally independent copy and records it in ``memo``
    as required by Python's copy protocol. Solve artifacts are excluded,
    matching :meth:`Model.copy` defaults.
    """
    new_model = copy(m, include_solution=False, deep=True)
    memo[id(m)] = new_model
    return new_model
